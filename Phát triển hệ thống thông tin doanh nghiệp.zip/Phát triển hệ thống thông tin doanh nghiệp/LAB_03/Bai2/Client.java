package Bai2;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Scanner; 

public class Client {
    public static void main (String[] args) throws Exception {
        try{
            Scanner scanner = new Scanner(System.in);

            String host = "localhost";
            int port = 1099;

            Registry registry = LocateRegistry.getRegistry(host, port);
            Calculator stub = (Calculator) registry.lookup("Calculator");

            System.out.println("Enter first number: ");
            double num1 = scanner.nextDouble();
            System.out.println("Enter second number: ");
            double num2 = scanner.nextDouble();

            System.out.println("Addtion: " + stub.add(num1, num2));
            System.out.println("Subtraction: " + stub.subtract(num1,num2));
            System.out.println("Multiplication: "+ stub.multiply(num1,num2));
            System.out.println("Division: "+ stub.divide(num1,num2));

            System.out.println("Remove method invoked!");

        }catch (Exception e){
            System.err.println("Client exception: " + e.toString());
        }
    }
}
