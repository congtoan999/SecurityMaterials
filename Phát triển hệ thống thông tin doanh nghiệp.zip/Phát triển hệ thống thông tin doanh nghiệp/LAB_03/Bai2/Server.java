package Bai2;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

public class Server extends ImplCalculator {
    public Server() {}

    public static void main(String[] args) throws Exception {
        try {
            int port = 1099;  
            ImplCalculator obj = new ImplCalculator();

            Calculator skeleton = (Calculator) UnicastRemoteObject.exportObject(obj, 0);

            Registry registry = LocateRegistry.createRegistry(port);
            registry.rebind("Calculator",skeleton);

            System.err.println("Calculator Server is ready..");
        }catch (Exception e){
            System.err.println("Server exception: " + e.toString());
        }
    }
}