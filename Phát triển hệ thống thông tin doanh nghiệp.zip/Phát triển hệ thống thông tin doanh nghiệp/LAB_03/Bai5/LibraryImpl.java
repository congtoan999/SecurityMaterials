package Bai5;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.*;

public class LibraryImpl extends UnicastRemoteObject implements Library {
    private Map<String, Integer> books; // Lưu danh sách sách với số lượng

    protected LibraryImpl() throws RemoteException {
        super();
        books = new HashMap<>();
        books.put("Java Programming", 3);
        books.put("Data Science", 2);
        books.put("Artificial Intelligence", 1);
    }

    @Override
    public List<String> searchBook(String title) throws RemoteException {
        List<String> results = new ArrayList<>();
        for (String book : books.keySet()) {
            if (book.toLowerCase().contains(title.toLowerCase())) {
                results.add(book + " (Available: " + books.get(book) + ")");
            }
        }
        return results;
    }

    @Override
    public boolean checkoutBook(String title) throws RemoteException {
        if (books.containsKey(title) && books.get(title) > 0) {
            books.put(title, books.get(title) - 1);
            return true;
        }
        return false;
    }

    @Override
    public boolean returnBook(String title) throws RemoteException {
        if (books.containsKey(title)) {
            books.put(title, books.get(title) + 1);
            return true;
        }
        return false;
    }
}
