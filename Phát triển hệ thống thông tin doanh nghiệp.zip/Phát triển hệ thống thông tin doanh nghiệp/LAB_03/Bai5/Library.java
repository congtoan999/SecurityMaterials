package Bai5;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

public interface Library extends Remote{
    List<String> searchBook(String title) throws RemoteException;
    boolean checkoutBook(String title) throws RemoteException;
    boolean returnBook(String title) throws RemoteException;
}