package Bai5;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.List;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {
        try {
            Registry registry = LocateRegistry.getRegistry("localhost", 1099);
            Library library = (Library) registry.lookup("LibraryService");
            Scanner scanner = new Scanner(System.in);
            
            while (true) {
                System.out.println("\n1. Search Book\n2. Checkout Book\n3. Return Book\n4. Exit");
                System.out.print("Choose an option: ");
                int choice = scanner.nextInt();
                scanner.nextLine(); // Consume newline
                
                switch (choice) {
                    case 1:
                        System.out.print("Enter book title to search: ");
                        String title = scanner.nextLine();
                        List<String> books = library.searchBook(title);
                        if (books.isEmpty()) {
                            System.out.println("No books found.");
                        } else {
                            books.forEach(System.out::println);
                        }
                        break;
                    
                    case 2:
                        System.out.print("Enter book title to checkout: ");
                        String checkoutTitle = scanner.nextLine();
                        boolean success = library.checkoutBook(checkoutTitle);
                        System.out.println(success ? "Book checked out successfully." : "Book not available.");
                        break;
                    
                    case 3:
                        System.out.print("Enter book title to return: ");
                        String returnTitle = scanner.nextLine();
                        boolean returned = library.returnBook(returnTitle);
                        System.out.println(returned ? "Book returned successfully." : "Invalid book title.");
                        break;

                    case 4:
                        System.out.println("Exiting...");
                        scanner.close();
                        return;
                    
                    default:
                        System.out.println("Invalid option, try again.");
                }
            }
        } catch (Exception e) {
            System.err.println("Client exception: " + e.getMessage());
        }
    }
}
