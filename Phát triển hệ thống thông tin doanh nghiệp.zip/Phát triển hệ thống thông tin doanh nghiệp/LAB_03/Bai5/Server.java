package Bai5;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class Server {
    public static void main(String[] args) {
        try {
            Library library = new LibraryImpl();
            Registry registry = LocateRegistry.createRegistry(1099);
            registry.rebind("LibraryService", library);
            System.out.println("Library Service is running...");
        } catch (Exception e) {
            System.err.println("Server exception: " + e.getMessage());
        }
    }
}
