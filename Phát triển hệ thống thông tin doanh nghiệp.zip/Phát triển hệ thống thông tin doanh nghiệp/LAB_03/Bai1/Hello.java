package Bai1;
import java.rmi.*;

public interface Hello extends Remote {
    public void printMsg(String name) throws RemoteException;
    public void printAge(int age) throws RemoteException;
}
