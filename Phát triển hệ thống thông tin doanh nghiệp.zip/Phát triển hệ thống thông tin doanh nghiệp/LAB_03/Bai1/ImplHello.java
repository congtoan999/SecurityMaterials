package Bai1;
import java.rmi.RemoteException;

public class ImplHello implements Hello {
    public ImplHello() {}

    @Override
    public void printMsg(String name) throws RemoteException {
        System.out.println(name + " is trying to contact!");
    }

    @Override
    public void printAge(int age) throws RemoteException {
        System.out.println("User's age is: " + age);
    }
}
