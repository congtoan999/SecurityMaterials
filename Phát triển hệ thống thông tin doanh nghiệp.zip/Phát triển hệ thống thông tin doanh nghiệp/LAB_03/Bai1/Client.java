package Bai1;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class Client {
    public Client() {}

    public static void main(String[] args) {
        try {
            String host = "localhost"; 
            int port = 1099;

            Registry registry = LocateRegistry.getRegistry(host, port);
            Hello stub = (Hello) registry.lookup("Hello");

            stub.printMsg("Alice");
            stub.printAge(25);

            System.err.println("Remote method invoked!");
        } catch (Exception e) {
            System.err.println("Client exception: " + e.toString());
        }
    }
}
