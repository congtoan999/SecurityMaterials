package Bai1;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

public class Server extends ImplHello {
    public Server() {}

    public static void main(String[] args) {
        try {
            int port = 1099;  // Port RMI

            // Tạo đối tượng thực thi
            ImplHello obj = new ImplHello();

            // Export Remote Object
            Hello skeleton = (Hello) UnicastRemoteObject.exportObject(obj, 0);

            Registry registry = LocateRegistry.createRegistry(port);
            registry.rebind("Hello", skeleton);

            System.err.println("Server is ready...");
        } catch (Exception e) {
            System.err.println("Server exception: " + e.toString());
        }
    }
}
