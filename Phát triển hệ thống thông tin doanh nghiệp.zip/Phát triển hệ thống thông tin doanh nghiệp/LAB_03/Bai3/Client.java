package Bai3;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class Client{
    public static void main(String[] args){
        try{
            Registry registry = LocateRegistry.getRegistry("localhost",1099);
            FileService fileService = (FileService) registry.lookup("FileService");

            String writeResult = fileService.writeFile("test.txt","Hello, this is a remote file!");
            System.out.println(writeResult);

            String fileContent = fileService.readFile("test.txt");
            System.out.println("File Content:\n");
        } catch (Exception e){
            System.err.println("Client exception: " + e.getMessage());
        }
    }
}