package Bai3;
import java.rmi.Remote;
import java.rmi.RemoteException;

public interface FileService extends Remote{
    String readFile(String fileName) throws RemoteException;
    String writeFile(String fileName, String content) throws RemoteException;
}