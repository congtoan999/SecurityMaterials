package Bai3;

import java.io.*;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class FileServiceImpl extends UnicastRemoteObject implements FileService {
    protected FileServiceImpl() throws RemoteException {
        super();
    }

    @Override
    public String readFile(String fileName) throws RemoteException {
        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            StringBuilder content = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                content.append(line).append("\n");
            }
            return content.toString();
        } catch (IOException e) {
            return "Error reading file: " + e.getMessage();
        }
    }

    @Override
    public String writeFile(String fileName, String content) throws RemoteException {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(fileName))) {
            bw.write(content);
            return "File written successfully: " + fileName;
        } catch (IOException e) {
            return "Error writing file: " + e.getMessage();
        }
    }
}
