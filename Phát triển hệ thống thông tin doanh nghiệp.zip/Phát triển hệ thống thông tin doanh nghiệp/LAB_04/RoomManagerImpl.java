import java.rmi.server.UnicastRemoteObject;
import java.rmi.RemoteException;
import java.util.*;

public class RoomManagerImpl extends UnicastRemoteObject implements RoomManager{
    private Map<Integer, Integer> rooms;
    private Map<Integer, Integer> roomPrices;
    private List<String> guests;
    private Map<String, String> users;
    private List<String> loginHistory;

    protected RoomManagerImpl() throws RemoteException{
        rooms = new HashMap<>();
        rooms.put(0,10);
        rooms.put(1,20);
        rooms.put(2,5);
        rooms.put(3,3);
        rooms.put(4,2);

        roomPrices = new HashMap<>();
        roomPrices.put(0,55);
        roomPrices.put(1,75);
        roomPrices.put(2,80);
        roomPrices.put(3,150);
        roomPrices.put(4,230);

        guests = new ArrayList<>();
        users = new HashMap<>();
        users.put("manager","1234");
        users.put("receptionist","5678");

        loginHistory = new ArrayList<>();
    }    

    public boolean logIn(String username, String password) throws RemoteException{
        boolean success = users.containsKey(username) && users.get(username).equals(password);
        if(success){
            loginHistory.add(username + "logged in at" + new Date());
        }
        return success;
    } 

    public void logOut(String username) throws RemoteException{
        System.out.println(username + "has logged out.");
    }

    public List<String> listRooms() throws RemoteException {
        List<String> result = new ArrayList<>();
        for(Map.Entry<Integer, Integer> entry : rooms.entrySet()){
            result.add(entry.getValue() + " room of type " + entry.getKey() + " available for " + roomPrices.get(entry.getKey()));
        }
        return result;
    }

    public String bookRoom(int roomType, String guestName, String guestSSN) throws RemoteException{
        if (rooms.get(roomType) > 0){
            rooms.put(roomType, rooms.get(roomType) - 1);
            String ssnInfo = (guestSSN == null || guestSSN.isEmpty()) ? UUID.randomUUID().toString() : guestSSN;
            guests.add(guestName + " (SSN: " + ssnInfo + ") booked room type " + roomType);
            return "Room booked secessfully for " + guestName;
        }
        return "No rooms available of type" + roomType;
    }

    public List<String> listGuests(String username) throws RemoteException{
        if("manager".equals(username)){
            return guests;
        }
        return Collections.singletonList("Access denied");
    }
}