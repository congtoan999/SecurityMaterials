import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Scanner;

public class Client{
    public static void main(String[] args){
        try{
            Registry registry = LocateRegistry.getRegistry("localhost",1099);
            RoomManager roomManager = (RoomManager) registry.lookup("HotelService");
            Scanner scanner = new Scanner(System.in);

            while(true){
                System.out.println("1. Login\n2.List Rooms\n3. Book Room\n4. List Guest\n5. Logout\n0. Exit");
                int choice = scanner.nextInt();
                scanner.nextInt();
                switch (choice){
                    case 1:
                        System.out.print("Username: ");
                        String user =  scanner.nextLine();
                        System.out.print("Password: ");
                        String pass = scanner.nextLine();
                        if(roomManager.logIn(user,pass)){
                            System.out.println("Login successful");
                        }else{
                            System.out.println("Login failed");
                        }
                        break;
                    case 2:
                        System.out.println(roomManager.listRooms());
                        break;
                    case 3:
                        System.out.print("Room Type: ");
                        int type = scanner.nextInt();
                        scanner.nextLine();
                        System.out.print("GuestName: ");
                        String name = scanner.nextLine();
                        System.out.println("Guest SSN (optional): ");
                        String ssn = scanner.nextLine();
                        System.out.println(roomManager.bookRoom(type,name, ssn));
                        break;
                    case 4:
                        System.out.print("Username (manager only): ");
                        String uname = scanner.nextLine();
                        System.out.println(roomManager.listGuests(uname));
                        break;
                    case 5:
                        System.out.println("Username: ");
                        String logoutUser = scanner.nextLine();
                        roomManager.logOut(logoutUser);
                        break;
                    case 0:
                        scanner.close();
                        return;
                    default:
                        System.out.println("Invalid option, try again.");
                }
            }
        }catch (Exception e){
            System.err.println("Client exception: " + e.getMessage());
        }
    }
}