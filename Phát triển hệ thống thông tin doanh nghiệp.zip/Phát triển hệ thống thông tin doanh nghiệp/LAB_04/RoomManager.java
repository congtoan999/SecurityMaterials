import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

public interface RoomManager extends Remote{
    boolean logIn(String username, String password) throws RemoteException;
    void logOut(String username) throws RemoteException;
    List<String> listRooms() throws RemoteException;
    String bookRoom(int roomType, String guestName, String guestSSN) throws RemoteException;
    List<String> listGuests(String username) throws RemoteException;
}