package bai49;

//Lớp Circle
public class Circle {
 // Thuộc tính riêng tư (Private Instance Variables)
 private double radius = 1.0; // Giá trị mặc định
 private String color = "red"; // Giá trị mặc định

 // Constructor mặc định (không tham số)
 public Circle() {
     // Mặc định đã có giá trị 1.0 cho radius và "red" cho color
 }

 // Constructor có tham số radius
 public Circle(double r) {
     this.radius = r; // Gán giá trị radius mới
 }

 // Phương thức getRadius() - Trả về bán kính của hình tròn
 public double getRadius() {
     return radius;
 }

 // Phương thức getArea() - Tính diện tích hình tròn
 public double getArea() {
     return Math.PI * radius * radius; // Công thức diện tích
 }
}
