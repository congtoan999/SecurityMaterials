package bai49;

public class TestCircle {
    public static void main(String[] args) {
        // Tạo một đối tượng Circle với constructor mặc định
        Circle c1 = new Circle();
        System.out.println("Circle 1:");
        System.out.println("Radius: " + c1.getRadius());
        System.out.println("Area: " + c1.getArea());

        // Tạo một đối tượng Circle với bán kính cụ thể
        Circle c2 = new Circle(5.0);
        System.out.println("\nCircle 2:");
        System.out.println("Radius: " + c2.getRadius());
        System.out.println("Area: " + c2.getArea());
    }
}

