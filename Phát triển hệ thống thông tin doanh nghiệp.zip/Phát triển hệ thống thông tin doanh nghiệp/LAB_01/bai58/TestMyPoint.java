package bai58;

public class TestMyPoint {
    public static void main(String[] args) {
        // Tạo điểm mặc định (0,0)
        MyPoint p1 = new MyPoint();
        System.out.println("Điểm p1: " + p1);

        // Tạo điểm (3,4)
        MyPoint p2 = new MyPoint(3, 4);
        System.out.println("Điểm p2: " + p2);

        // Kiểm tra khoảng cách
        System.out.println("Khoảng cách từ " + p1 + " đến " + p2 + ": " + p1.distance(p2));
        System.out.println("Khoảng cách từ " + p2 + " đến gốc tọa độ: " + p2.distance());
        System.out.println("Khoảng cách từ " + p1 + " đến (5,5): " + p1.distance(5, 5));

        // Thay đổi tọa độ p1
        p1.setXY(7, 1);
        System.out.println("Sau khi thay đổi p1: " + p1);
    }
}
