package bai59;

public class TestMyCircle {
    public static void main(String[] args) {
        // Tạo hình tròn mặc định
        MyCircle c1 = new MyCircle();
        System.out.println("Hình tròn c1: " + c1);
        System.out.println("Diện tích c1: " + c1.getArea());
        System.out.println("Chu vi c1: " + c1.getCircumference());

        // Tạo hình tròn tại (3,4) với bán kính 5
        MyCircle c2 = new MyCircle(3, 4, 5);
        System.out.println("\nHình tròn c2: " + c2);
        System.out.println("Diện tích c2: " + c2.getArea());
        System.out.println("Chu vi c2: " + c2.getCircumference());

        // Tính khoảng cách giữa hai hình tròn
        System.out.println("\nKhoảng cách giữa tâm c1 và c2: " + c1.distance(c2));

        // Thay đổi tọa độ tâm c1
        c1.setCenterXY(7, 1);
        System.out.println("\nSau khi thay đổi c1: " + c1);
    }
}
