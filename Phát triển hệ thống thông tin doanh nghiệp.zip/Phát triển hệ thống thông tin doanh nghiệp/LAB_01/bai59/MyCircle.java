package bai59;

public class MyCircle {
    private MyPoint center;
    private int radius;

    // Constructor mặc định (0,0), radius = 1
    public MyCircle() {
        this.center = new MyPoint(0, 0);
        this.radius = 1;
    }

    // Constructor với (x, y) và radius
    public MyCircle(int x, int y, int radius) {
        this.center = new MyPoint(x, y);
        this.radius = radius;
    }

    // Constructor với MyPoint làm center
    public MyCircle(MyPoint center, int radius) {
        this.center = center;
        this.radius = radius;
    }

    // Getter & Setter cho radius
    public int getRadius() { return radius; }
    public void setRadius(int radius) { this.radius = radius; }

    // Getter & Setter cho center
    public MyPoint getCenter() { return center; }
    public void setCenter(MyPoint center) { this.center = center; }

    // Getter & Setter cho centerX, centerY
    public int getCenterX() { return center.getX(); }
    public void setCenterX(int x) { center.setX(x); }
    public int getCenterY() { return center.getY(); }
    public void setCenterY(int y) { center.setY(y); }

    // Đặt lại cả x, y của tâm
    public void setCenterXY(int x, int y) {
        center.setXY(x, y);
    }

    // Phương thức trả về diện tích hình tròn
    public double getArea() {
        return Math.PI * radius * radius;
    }

    // Phương thức trả về chu vi hình tròn
    public double getCircumference() {
        return 2 * Math.PI * radius;
    }

    // Tính khoảng cách giữa hai tâm hình tròn
    public double distance(MyCircle another) {
        return this.center.distance(another.getCenter());
    }

    // Phương thức toString()
    @Override
    public String toString() {
        return "MyCircle[radius=" + radius + ", center=" + center + "]";
    }
}

