package bai59;

public class MyPoint {
    private int x, y;

    // Constructor mặc định (0,0)
    public MyPoint() {
        this.x = 0;
        this.y = 0;
    }

    // Constructor có tham số
    public MyPoint(int x, int y) {
        this.x = x;
        this.y = y;
    }

    // Getter & Setter
    public int getX() { return x; }
    public int getY() { return y; }
    public void setX(int x) { this.x = x; }
    public void setY(int y) { this.y = y; }
    public void setXY(int x, int y) {
        this.x = x;
        this.y = y;
    }

    // Tính khoảng cách giữa hai điểm
    public double distance(MyPoint another) {
        int dx = this.x - another.x;
        int dy = this.y - another.y;
        return Math.sqrt(dx * dx + dy * dy);
    }

    @Override
    public String toString() {
        return "(" + x + ", " + y + ")";
    }
}
