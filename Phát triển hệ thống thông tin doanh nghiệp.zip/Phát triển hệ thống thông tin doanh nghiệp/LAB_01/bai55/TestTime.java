package bai55;

public class TestTime {
    public static void main(String[] args) {
        // Tạo một đối tượng Time
        Time time = new Time(23, 33, 59);

        // Hiển thị thời gian ban đầu
        System.out.println("Current Time: " + time);

        // Tăng 1 giây và hiển thị kết quả
        time.nextSecond();
        System.out.println("After next second: " + time);

        // Giảm 1 giây và hiển thị kết quả
        time.previousSecond();
        System.out.println("After previous second: " + time);
    }
}
