package bai63;

public class TestShape {
    public static void main(String[] args) {
        // Tạo hình chữ nhật với length = 5, width = 4
        Shape rect = new Rectangle(5, 4);
        System.out.println(rect);

        // Tạo tam giác với base = 6, height = 3
        Shape tri = new Triangle(6, 3);
        System.out.println(tri);
    }
}
