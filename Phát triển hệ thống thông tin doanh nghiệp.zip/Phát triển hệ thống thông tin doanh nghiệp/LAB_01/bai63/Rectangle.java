package bai63;

//Lớp Rectangle kế thừa từ Shape
public class Rectangle implements Shape {
 private double length;
 private double width;

 // Constructor
 public Rectangle(double length, double width) {
     this.length = length;
     this.width = width;
 }

 // Triển khai phương thức getArea() của Shape
 @Override
 public double getArea() {
     return length * width;
 }

 // Phương thức toString()
 @Override
 public String toString() {
     return "Rectangle[length=" + length + ", width=" + width + ", area=" + getArea() + "]";
 }
}
