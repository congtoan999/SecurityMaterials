package bai63;

//Interface Shape
public interface Shape {
 double getArea();  // Phương thức trừu tượng để tính diện tích
}
