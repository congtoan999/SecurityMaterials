package bai63;

//Lớp Triangle kế thừa từ Shape
public class Triangle implements Shape {
 private double base;
 private double height;

 // Constructor
 public Triangle(double base, double height) {
     this.base = base;
     this.height = height;
 }

 // Triển khai phương thức getArea() của Shape
 @Override
 public double getArea() {
     return 0.5 * base * height;
 }

 // Phương thức toString()
 @Override
 public String toString() {
     return "Triangle[base=" + base + ", height=" + height + ", area=" + getArea() + "]";
 }
}
