package bai51;

public class TestEmployee {
    public static void main(String[] args) {
        // Tạo một đối tượng Employee
        Employee emp1 = new Employee(1, "John", "Doe", 5000);

        System.out.println("Employee Information:");
        System.out.println(emp1);
        System.out.println("Annual Salary: " + emp1.getAnnualSalary());

        // Tăng lương 10%
        System.out.println("\nAfter 10% raise:");
        System.out.println("New Salary: " + emp1.raiseSalary(10));
        System.out.println(emp1);
    }
}
