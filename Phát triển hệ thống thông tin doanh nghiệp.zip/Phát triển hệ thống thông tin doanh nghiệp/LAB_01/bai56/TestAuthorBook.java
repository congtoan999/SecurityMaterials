package bai56;

public class TestAuthorBook {
    public static void main(String[] args) {
        // Tạo một tác giả
        Author author1 = new Author("J.K. Rowling", "jk.rowling@email.com", 'f');

        // Hiển thị thông tin tác giả
        System.out.println(author1);

        // Tạo một quyển sách với 3 tham số (không có qty)
        Book book1 = new Book("Harry Potter", author1, 29.99);

        // Hiển thị thông tin sách
        System.out.println(book1);

        // Tạo một quyển sách với 4 tham số (có qty)
        Book book2 = new Book("Fantastic Beasts", author1, 35.50, 100);

        // Hiển thị thông tin sách
        System.out.println(book2);

        // Cập nhật giá sách và số lượng
        book1.setPrice(25.99);
        book2.setQty(120);

        // Hiển thị thông tin sau khi cập nhật
        System.out.println("After updates:");
        System.out.println(book1);
        System.out.println(book2);
    }
}
