package bai56;

public class Book {
    // Thuộc tính riêng tư
    private String name;
    private Author author; // Đối tượng Author
    private double price;
    private int qty = 0; // Mặc định là 0

    // Constructor có 3 tham số (không có qty)
    public Book(String name, Author author, double price) {
        this.name = name;
        this.author = author;
        this.price = price;
    }

    // Constructor có đầy đủ 4 tham số
    public Book(String name, Author author, double price, int qty) {
        this.name = name;
        this.author = author;
        this.price = price;
        this.qty = qty;
    }

    // Getter cho name
    public String getName() {
        return name;
    }

    // Getter cho author
    public Author getAuthor() {
        return author;
    }

    // Getter cho price
    public double getPrice() {
        return price;
    }

    // Setter cho price
    public void setPrice(double price) {
        this.price = price;
    }

    // Getter cho qty
    public int getQty() {
        return qty;
    }

    // Setter cho qty
    public void setQty(int qty) {
        this.qty = qty;
    }

    // Phương thức toString()
    @Override
    public String toString() {
        return "Book[name=" + name + ", " + author.toString() + ", price=" + price + ", qty=" + qty + "]";
    }
}
