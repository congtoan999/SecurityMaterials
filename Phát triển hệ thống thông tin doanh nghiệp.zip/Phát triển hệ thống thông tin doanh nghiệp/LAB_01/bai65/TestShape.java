package bai65;

//Chương trình kiểm tra hoạt động của các lớp
public class TestShape {
 public static void main(String[] args) {
     // Kiểm tra lớp Circle
     Circle circle = new Circle(5.0, "blue", true);
     System.out.println(circle);
     System.out.println("Diện tích: " + circle.getArea());
     System.out.println("Chu vi: " + circle.getPerimeter());

     System.out.println("\n--------------------\n");

     // Kiểm tra lớp Rectangle
     Rectangle rectangle = new Rectangle(4.0, 7.0, "green", false);
     System.out.println(rectangle);
     System.out.println("Diện tích: " + rectangle.getArea());
     System.out.println("Chu vi: " + rectangle.getPerimeter());

     System.out.println("\n--------------------\n");

     // Kiểm tra lớp Square
     Square square = new Square(6.0, "red", true);
     System.out.println(square);
     System.out.println("Diện tích: " + square.getArea());
     System.out.println("Chu vi: " + square.getPerimeter());
 }
}
