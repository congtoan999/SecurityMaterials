package bai65;

//Lớp Rectangle kế thừa Shape
public class Rectangle extends Shape {
 protected double width;
 protected double length;

 // Constructor mặc định
 public Rectangle() {
     this.width = 1.0;
     this.length = 1.0;
 }

 // Constructor có tham số
 public Rectangle(double width, double length) {
     this.width = width;
     this.length = length;
 }

 // Constructor đầy đủ
 public Rectangle(double width, double length, String color, boolean filled) {
     super(color, filled);
     this.width = width;
     this.length = length;
 }

 // Getter & Setter
 public double getWidth() { return width; }
 public void setWidth(double width) { this.width = width; }

 public double getLength() { return length; }
 public void setLength(double length) { this.length = length; }

 // Triển khai phương thức trừu tượng
 @Override
 public double getArea() { return width * length; }

 @Override
 public double getPerimeter() { return 2 * (width + length); }

 // Phương thức toString()
 @Override
 public String toString() {
     return "Rectangle[width=" + width + ", length=" + length + ", " + super.toString() + "]";
 }
}
