package bai65;

//Lớp Circle kế thừa Shape
public class Circle extends Shape {
 private double radius;

 // Constructor mặc định
 public Circle() {
     this.radius = 1.0;
 }

 // Constructor có tham số
 public Circle(double radius) {
     this.radius = radius;
 }

 // Constructor đầy đủ
 public Circle(double radius, String color, boolean filled) {
     super(color, filled);
     this.radius = radius;
 }

 // Getter & Setter
 public double getRadius() { return radius; }
 public void setRadius(double radius) { this.radius = radius; }

 // Triển khai phương thức trừu tượng
 @Override
 public double getArea() { return Math.PI * radius * radius; }

 @Override
 public double getPerimeter() { return 2 * Math.PI * radius; }

 // Phương thức toString()
 @Override
 public String toString() {
     return "Circle[radius=" + radius + ", " + super.toString() + "]";
 }
}
