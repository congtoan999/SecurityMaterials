package bai65;

//Lớp Square kế thừa Rectangle
public class Square extends Rectangle {

 // Constructor mặc định
 public Square() {
     super(1.0, 1.0);
 }

 // Constructor có tham số
 public Square(double side) {
     super(side, side);
 }

 // Constructor đầy đủ
 public Square(double side, String color, boolean filled) {
     super(side, side, color, filled);
 }

 // Getter & Setter
 public double getSide() { return width; }
 public void setSide(double side) { this.width = this.length = side; }

 // Phương thức toString()
 @Override
 public String toString() {
     return "Square[side=" + width + ", " + super.toString() + "]";
 }
}
