package bai64;

import java.util.ArrayList;

public class TestPerson {
    public static void main(String[] args) {
        // Tạo danh sách Person
        ArrayList<Person> people = new ArrayList<>();

        // Thêm Student
        people.add(new Student("Nguyen Van A", "Ho Chi Minh", "Computer Science", 2, 3000.0));
        people.add(new Student("Le Thi B", "Hanoi", "Business", 1, 2500.0));

        // Thêm Staff
        people.add(new Staff("Tran Van C", "Da Nang", "TDT University", 5000.0));
        people.add(new Staff("Pham Thi D", "Can Tho", "HCM University", 4500.0));

        // In danh sách
        for (Person person : people) {
            System.out.println(person);
        }
    }
}
