package Bai_2;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class DeserializeVehicle {
    public static void main(String[] args) {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("vehicles.ser"))) {
            Vehicle car = (Vehicle) ois.readObject();
            Vehicle truck = (Vehicle) ois.readObject();
            Vehicle motorcycle = (Vehicle) ois.readObject();

            car.display();
            truck.display();
            motorcycle.display();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}

