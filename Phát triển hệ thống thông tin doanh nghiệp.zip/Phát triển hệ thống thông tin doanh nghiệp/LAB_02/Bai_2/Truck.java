package Bai_2;

class Truck extends Vehicle {
    private static final long serialVersionUID = 1L;
    private double loadCapacity;

    public Truck(String make, String model, int year, double loadCapacity) {
        super(make, model, year);
        this.loadCapacity = loadCapacity;
    }

    @Override
    public void display() {
        super.display();
        System.out.println("Tải trọng: " + loadCapacity + " tấn");
    }
}