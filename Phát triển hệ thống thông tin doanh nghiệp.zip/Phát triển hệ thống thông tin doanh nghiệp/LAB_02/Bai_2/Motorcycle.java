package Bai_2;


class Motorcycle extends Vehicle {
    private static final long serialVersionUID = 1L;
    private boolean hasSideCar;

    public Motorcycle(String make, String model, int year, boolean hasSideCar) {
        super(make, model, year);
        this.hasSideCar = hasSideCar;
    }

    @Override
    public void display() {
        super.display();
        System.out.println("Có sidecar: " + (hasSideCar ? "Có" : "Không"));
    }
}

