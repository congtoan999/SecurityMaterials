package Bai_2;

import java.io.Serializable;

class Vehicle implements Serializable {
    private static final long serialVersionUID = 1L;
    protected String make;
    protected String model;
    protected int year;

    public Vehicle(String make, String model, int year) {
        this.make = make;
        this.model = model;
        this.year = year;
    }

    public void display() {
        System.out.println("Hãng: " + make + ", Mẫu: " + model + ", Năm: " + year);
    }
}

