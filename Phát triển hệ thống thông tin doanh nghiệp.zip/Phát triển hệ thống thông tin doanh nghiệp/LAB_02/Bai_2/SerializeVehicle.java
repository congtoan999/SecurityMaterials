package Bai_2;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class SerializeVehicle {
    public static void main(String[] args) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("vehicles.ser"))) {
            Car car = new Car("Toyota", "Camry", 2022, 4);
            Truck truck = new Truck("Ford", "F-150", 2021, 3.5);
            Motorcycle motorcycle = new Motorcycle("Honda", "CBR500R", 2023, false);

            oos.writeObject(car);
            oos.writeObject(truck);
            oos.writeObject(motorcycle);

            System.out.println("Đã tuần tự hóa các phương tiện.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
