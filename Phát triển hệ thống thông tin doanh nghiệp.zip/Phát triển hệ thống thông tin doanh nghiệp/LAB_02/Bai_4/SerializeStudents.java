package Bai_4;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class SerializeStudents {
    public static void main(String[] args) {
        Student[] students = {
            new Student("Nguyễn Văn A", 101, new int[]{90, 85, 88}),
            new Student("Trần Thị B", 102, new int[]{78, 80, 82}),
            new Student("Lê Văn C", 103, new int[]{95, 92, 90})
        };

        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("students.ser"))) {
            oos.writeObject(students);
            System.out.println("Đã tuần tự hóa mảng sinh viên.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

