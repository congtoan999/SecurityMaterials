package Bai_4;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class DeserializeStudents {
    public static void main(String[] args) {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("students.ser"))) {
            Student[] students = (Student[]) ois.readObject();

            System.out.println("Danh sách sinh viên:");
            for (Student student : students) {
                student.display();
            }
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}

