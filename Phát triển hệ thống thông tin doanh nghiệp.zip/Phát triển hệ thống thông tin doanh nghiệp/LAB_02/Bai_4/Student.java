package Bai_4;

import java.io.Serializable;
import java.util.Arrays;

class Student implements Serializable {
    private static final long serialVersionUID = 1L;
    private String name;
    private int id;
    private int[] scores;

    public Student(String name, int id, int[] scores) {
        this.name = name;
        this.id = id;
        this.scores = scores;
    }

    public void display() {
        System.out.println("Tên: " + name + ", ID: " + id + ", Điểm: " + Arrays.toString(scores));
    }
}
