package Bai_1;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;


public class SerializePerson {
    public static void main(String[] args) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("person.ser"))) {
            Person p = new Person("John Doe", 30, "123 Street");
            oos.writeObject(p);
            System.out.println("Serialization completed.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
