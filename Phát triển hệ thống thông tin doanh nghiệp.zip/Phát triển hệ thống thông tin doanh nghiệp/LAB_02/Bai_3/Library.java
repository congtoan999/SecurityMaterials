package Bai_3;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

class Library implements Serializable {
    private static final long serialVersionUID = 1L;
    private List<Book> books;

    public Library() {
        this.books = new ArrayList<>();
    }

    public void addBook(Book book) {
        books.add(book);
    }

    public void displayBooks() {
        if (books.isEmpty()) {
            System.out.println("Thư viện không có sách nào.");
        } else {
            System.out.println("Danh sách sách trong thư viện:");
            for (Book book : books) {
                System.out.println(book);
            }
        }
    }
}
