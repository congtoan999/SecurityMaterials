package Bai_3;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class SerializeLibrary {
    public static void main(String[] args) {
        Library library = new Library();
        library.addBook(new Book("Lập trình Java", "Nguyễn Văn A", 2020));
        library.addBook(new Book("Học Python", "Trần Văn B", 2019));
        library.addBook(new Book("Trí tuệ nhân tạo", "Phạm Thị C", 2021));

        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("library.ser"))) {
            oos.writeObject(library);
            System.out.println("Đã tuần tự hóa thư viện.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
