package Bai_5;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

class Team implements Serializable {
    private static final long serialVersionUID = 1L;
    private String teamName;
    private List<Player> players;

    public Team(String teamName) {
        this.teamName = teamName;
        this.players = new ArrayList<>();
    }

    public void addPlayer(Player player) {
        players.add(player);
    }

    public void displayTeam() {
        System.out.println("Đội: " + teamName);
        if (players.isEmpty()) {
            System.out.println("Không có cầu thủ nào.");
        } else {
            System.out.println("Danh sách cầu thủ:");
            for (Player player : players) {
                System.out.println(player);
            }
        }
    }
}
