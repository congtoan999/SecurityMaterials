package Bai_5;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class SerializeTeam {
    public static void main(String[] args) {
        Team team = new Team("FC Dream Team");
        team.addPlayer(new Player("Lionel Messi", "Tiền đạo"));
        team.addPlayer(new Player("Cristiano Ronaldo", "Tiền đạo"));
        team.addPlayer(new Player("Kevin De Bruyne", "Tiền vệ"));

        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("team.ser"))) {
            oos.writeObject(team);
            System.out.println("Đã tuần tự hóa đội bóng.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

