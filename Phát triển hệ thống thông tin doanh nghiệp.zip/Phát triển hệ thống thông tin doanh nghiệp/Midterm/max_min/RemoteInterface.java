import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

public interface RemoteInterface extends Remote {
    int findMax(List<Integer> numbers) throws RemoteException;
    int findMin(List<Integer> numbers) throws RemoteException;
    List<Integer> sortList(List<Integer> numbers) throws RemoteException;
}
