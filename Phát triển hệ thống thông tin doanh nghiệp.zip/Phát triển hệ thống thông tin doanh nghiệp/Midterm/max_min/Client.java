import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Client {
    public static void main(String[] args) {
        try {
            Registry registry = LocateRegistry.getRegistry("localhost", 1099);
            RemoteInterface remoteObject = (RemoteInterface) registry.lookup("RemoteService");

            Scanner scanner = new Scanner(System.in);
            System.out.print("Nhập danh sách số nguyên (cách nhau bởi dấu cách): ");
            String input = scanner.nextLine();
            List<Integer> numbers = Arrays.stream(input.split(" "))
                                          .map(Integer::parseInt)
                                          .collect(Collectors.toList());

            int max = remoteObject.findMax(numbers);
            int min = remoteObject.findMin(numbers);
            List<Integer> sortedList = remoteObject.sortList(numbers);

            System.out.println("Gia tri lon nhat: " + max);
            System.out.println("Gia tri nho nhat: " + min);
            System.out.println("Danh sách sau khi sắp xếp: " + sortedList);

            scanner.close();
        } catch (Exception e) {
            System.err.println("Client exception: " + e.getMessage());
        }
    }
}
