import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.Collections;
import java.util.List;

public class RemoteImpl extends UnicastRemoteObject implements RemoteInterface {

    protected RemoteImpl() throws RemoteException {
        super();
    }

    @Override
    public int findMax(List<Integer> numbers) throws RemoteException {
        return Collections.max(numbers);
    }

    @Override
    public int findMin(List<Integer> numbers) throws RemoteException {
        return Collections.min(numbers);
    }

    @Override
    public List<Integer> sortList(List<Integer> numbers) throws RemoteException {
        Collections.sort(numbers);
        return numbers;
    }
}
