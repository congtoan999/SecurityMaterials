// DO NOT USE PACKAGE

import java.io.*;
import java.rmi.RemoteException;
import java.util.ArrayList;

public class StudentManagementImpl implements StudentManagement {
    
    ArrayList<Student> students;

    public StudentManagementImpl()
    {
        this.students = new ArrayList<>();
    }

    public StudentManagementImpl(String dataPath)
    {
        this.students = new ArrayList<>();
        readData(dataPath);
    }

    private void readData(String filePath)
    {
        try
        {
            File file = new File(filePath);
            BufferedReader br = new BufferedReader(new FileReader(file));
            
            String readLine = "";
            while ((readLine = br.readLine()) != null)
            {
                // Insert your code here ...
                String[] parts = readLine.trim().split("\\s+");
                if(parts.length >= 5){
                    try{
                        String id = parts[0];
                    int genderIndex = 0;
                    for(int i = 0 ;i<parts.length; i++){
                        if(parts[i].equalsIgnoreCase("female") || parts[i].equalsIgnoreCase("male")){
                            genderIndex = i;
                            break;
                        }
                    }
                    String gender=parts[genderIndex];
                    StringBuilder nameBuilder = new StringBuilder();
                    for(int i = 1;i<genderIndex;i++){
                        nameBuilder.append(parts[i]).append(" ");
                    }
                    String name = nameBuilder.toString().trim();

                    double gpa = Double.parseDouble(parts[genderIndex+1]);

                    StringBuilder majorBuilder = new StringBuilder();
                    for(int i = genderIndex + 2; i<parts.length;i++){
                        majorBuilder.append(parts[i]).append(" ");
                    }
                    String major = majorBuilder.toString().trim();

                    students.add(new Student(id,name,gender,gpa,major));
                    }
                    catch(NumberFormatException e){
                        System.err.println("loi dong: "+ readLine);
                    }
                }
                // Insert your code here ...
            }
            
            br.close();
        } catch (IOException ex)
        {
            System.err.println(ex.getMessage());
        }
    }

    @Override
    public int getNoOfStudent() throws RemoteException
    {
        // Insert your code here ...
        return students.size();
        // Insert your code here ...
    }

    @Override
    public int getNoOfStudent_byGender(String gender) throws RemoteException
    {
        // Insert your code here ...
        int count = 0;
        for(Student s : students){
            if(s.getGender().equalsIgnoreCase((gender))){
                count++;
            }
        }
        return count;
        // Insert your code here ...
    }

    @Override
    public int getNoOfStudent_byMajor(String major) throws RemoteException
    {
        // Insert your code here ...
        int count = 0;
        for (Student s : students){
            if(s.getMajor().equalsIgnoreCase(major)){
                count++;
            }
        }
        return count;
        // Insert your code here ...
    }

    @Override
    public int getNoOfStudent_byGPA(double gpa) throws RemoteException
    {
        // Insert your code here ...
        int count = 0;
        for(Student s : students){
            if(s.getGpa() < gpa){
                count++;
            }
        }
        return count;
        // Insert your code here ...
    }

    @Override
    public Student findStudent_byName(String name) throws RemoteException
    {
        // Insert your code here ...
        for(Student s : students){
            if(s.getName().equalsIgnoreCase(name)){
                return s;
            }
        }
        // Insert your code here ...
        return null;
    }

    @Override
    public Student findStudent_byID(String id) throws RemoteException
    {
        // Insert your code here ...
        for(Student s : students){
            if(s.getId().equalsIgnoreCase(id)){
                return s;
            }
        }
        // Insert your code here ...
        return null;
    }

    @Override
    public ArrayList<Student> findStudent_byMajor(String major) throws RemoteException
    {
        // Insert your code here ...
        ArrayList<Student> st = new ArrayList<>();
        for(Student s : students){
            if(s.getMajor().equalsIgnoreCase(major)){
                st.add(s);
            }
        }
        return st;
        // Insert your code here ...
    }

    @Override
    public ArrayList<Student> findStudent_byGPA(double GPA) throws RemoteException
    {
        // Insert your code here ...
        ArrayList<Student> st = new ArrayList<>();
        for(Student s : students){
            if(s.getGpa() < GPA){
                st.add(s);
            }
        }
        // Insert your code here ...
        return st;
    }

    @Override
    public double getAvgGPA() throws RemoteException
    {
        
        // Insert your code here ...
        double count = 0.0;
        for(Student s : students){
            if(s.getGpa()>0.0){
                count += s.getGpa();
            }
        }
        return count/students.size();
        // Insert your code here ...
    }

    @Override
    public Student getHighestGPA_byGender(String gender) throws RemoteException
    {
        // Insert your code here ...
        double gpa_cao_nhat = 0.0;
        Student hs_cao_nhat_gpa = null;
        for(Student s : students){
            if(s.getGender().equalsIgnoreCase(gender) && s.getGpa()>gpa_cao_nhat){
                gpa_cao_nhat = s.getGpa();
                hs_cao_nhat_gpa = s;
            }
        }
        return hs_cao_nhat_gpa;
        // Insert your code here ...
    }

    @Override
    public Student getHighestGPA_byFName(String fname) throws RemoteException
    {
        // Insert your code here ...
        double gpa_cao_nhat = 0;
        Student first_cao_nhat = null;

        for(Student s : students){
            String firstName = s.getName().split(" ")[0];
            if(s.getGpa() > gpa_cao_nhat && firstName.equalsIgnoreCase(fname)){
                gpa_cao_nhat = s.getGpa();
                first_cao_nhat = s;
            }
        }
        // Insert your code here ...
        return first_cao_nhat;
    }

    @Override
    public Student getHighestGPA_byLName(String lname) throws RemoteException
    {
        // Insert your code here ...
        double gpa_cao_nhat = 0.0;
        Student hs_cao_nhat_gpa = null;

        for(Student s : students){
            String[] lastName = s.getName().trim().split(" ");
            if(lastName[1].equalsIgnoreCase(lname) || s.getGpa() > gpa_cao_nhat){
                gpa_cao_nhat = s.getGpa();
                hs_cao_nhat_gpa = s;
            }
        }
        return hs_cao_nhat_gpa;
        // Insert your code here ...
    }

    @Override
    public Student getHighestGPA_byMajor(String major) throws RemoteException
    {
        // Insert your code here ...
        double gpa_cao_nhat = 0.0;
        Student nganh_cao_nhat = null;
        for(Student s : students){
            if(s.getGpa() > gpa_cao_nhat && s.getMajor().equalsIgnoreCase(major)){
                gpa_cao_nhat = s.getGpa();
                nganh_cao_nhat = s;
            }
        }
        // Insert your code here ...
        return nganh_cao_nhat;
    }

    @Override
    public Student getLowestGPA_byMajor(String major) throws RemoteException
    {
        // Insert your code here ...
        double gpa_thap_nhat = 10.0;
        Student nganh_thap_nhap = null;
        for(Student s : students){
            if(s.getGpa() < gpa_thap_nhat && s.getMajor().equalsIgnoreCase(major)){
                gpa_thap_nhat = s.getGpa();
                nganh_thap_nhap = s;
            }
        }
        // Insert your code here ...
        return nganh_thap_nhap;
    } 

    @Override
	public ArrayList<Student> getTop10_byGPA() throws RemoteException
	{
		// Insert your code here ...
        ArrayList<Student> st = new ArrayList<>(students);
        for(int i = 0 ; i<st.size()-1;i++){
            for(int j = 0;j < st.size() - i -1;j++){
                if(st.get(j).getGpa() <st.get(j+1).getGpa()){
                    Student temp = st.get(j);
                    st.set(j,st.get(j+1));
                    st.set(j+1,temp);
                }
            }
        }

        ArrayList<Student> top10 = new ArrayList<>();
        for(int i = 0 ;i < Math.min(10, st.size());i++){
            top10.add(st.get(i));
        }
        return top10;
        // Insert your code here ...
	}

	@Override
	public ArrayList<Student> getTop10GPA_byGender(String gender) throws RemoteException
	{
    	// Insert your code here ...
        ArrayList<Student> st = new ArrayList<>();
        for(Student s : students){
            if(s.getGender().equalsIgnoreCase(gender)){
                st.add(s);
            }
        }

        for(int i = 0 ; i < st.size() - 1;i++){
            for(int j = i + 1; j< st.size();j++ ){
                if(st.get(i).getGpa() < st.get(j).getGpa() ){
                    Student temp = st.get(i);
                    st.set(i,st.get(j));
                    st.set(j,temp);
                }
            }
        } 

        ArrayList<Student> top10 = new ArrayList<>();
        for(int i = 0; i < Math.min(10,st.size()); i++){
            top10.add(st.get(i));
        }
        // Insert your code here ...
        return top10;
	}

	@Override
	public ArrayList<Student> getTop10GPA_byMajor(String major) throws RemoteException
	{
		// Insert your code here ...
        ArrayList<Student> st = new ArrayList<>();
        for(Student s : students){
            if(s.getMajor().equalsIgnoreCase(major)){
                st.add(s);
            }
        }

        for(int i = 0; i<st.size() - 1;i++){
            for(int j = 0; j<st.size() - i - 1;j++){
                if(st.get(j).getGpa() < st.get(j+1).getGpa()){
                    Student temp = st.get(j);
                    st.set(j,st.get(j+1));
                    st.set(j+1,temp);
                }
            }
        }

        ArrayList<Student> top10 = new ArrayList<>();
        for(int i = 0;i < Math.min(10,st.size());i++){
            top10.add(st.get(i));
        }
        // Insert your code here ...
        return top10;
	}

	@Override
	public ArrayList<Student> getLast10GPA_byGender(String gender) throws RemoteException
	{
		// Insert your code here ...
        ArrayList<Student> st = new ArrayList<>();
        for(Student s : students){
            if(s.getGender().equalsIgnoreCase(gender)){
                st.add(s);
            }
        }

        for(int i = 0 ; i< st.size() - 1; i++){
            for(int j = 0; j < st.size()-i-1;j++){
                if(st.get(j).getGpa() > st.get(j+1).getGpa()){
                    Student temp = st.get(j);
                    st.set(j,st.get(j+1));
                    st.set(j+1, temp);
                }
            }
        }

        ArrayList<Student> top10 = new ArrayList<>();
        for(int i = 0 ; i < Math.min(10,st.size());i++){
            top10.add(st.get(i));
        }
        // Insert your code here ...
        return top10;
	}

	@Override
	public ArrayList<Student> getLast10GPA_byMajor(String major) throws RemoteException
	{
		// Insert your code here ...
        ArrayList<Student> st = new ArrayList<>();
        for(Student s : students){
            if(s.getMajor().equalsIgnoreCase(major)){
                st.add(s);
            }
        }

        for(int i = 0; i< st.size() - 1;i++){
            for(int j = 0; j<st.size() - i - 1;j++){
                if(st.get(j).getGpa() > st.get(j+1).getGpa()){
                    Student temp = st.get(j);
                    st.set(j,st.get(j+1));
                    st.set(j+1,temp);
                }
            }
        }

        ArrayList<Student> top10 = new ArrayList<>();
        for(int i = 0 ; i<Math.min(10,st.size());i++){
            top10.add(st.get(i));
        }

        return top10;
        // Insert your code here ...
	}

    @Override
    public ArrayList<String> getMajors() throws RemoteException
    {
        // Insert your code here ...
        ArrayList<String> uniqueMajors = new ArrayList<>();
        for(Student s : students){
            if(!uniqueMajors.contains(s.getMajor())){
                uniqueMajors.add(s.getMajor());
            }
        }
        return uniqueMajors;
        // Insert your code here ...
    }
    
}
