import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class Client {
    public static void main(String[] args) {
        try {
            Registry registry = LocateRegistry.getRegistry("localhost", 1099);
            RemoteInterface remoteObject = (RemoteInterface) registry.lookup("RemoteService");

            int max = remoteObject.findMax();
            int min = remoteObject.findMin();

            System.out.println("Day so tren Server: [5, 10, 3, 20, 7, 15, 1, 8]");
            System.out.println("Gia tri lon nhat : " + max);
            System.out.println("Gia tri nho nhat : " + min);

        } catch (Exception e) {
            System.err.println("Client exception: " + e.getMessage());
        }
    }
}
