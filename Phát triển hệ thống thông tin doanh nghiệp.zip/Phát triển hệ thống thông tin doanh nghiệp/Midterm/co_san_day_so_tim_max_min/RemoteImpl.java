import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.Arrays;
import java.util.List;
import java.util.Collections;

public class RemoteImpl extends UnicastRemoteObject implements RemoteInterface {
    private final List<Integer> numbers = Arrays.asList(5, 10, 3, 20, 7, 15, 1, 8);

    protected RemoteImpl() throws RemoteException {
        super();
    }

    @Override
    public int findMax() throws RemoteException {
        return Collections.max(numbers);
    }

    @Override
    public int findMin() throws RemoteException {
        return Collections.min(numbers);
    }
}
