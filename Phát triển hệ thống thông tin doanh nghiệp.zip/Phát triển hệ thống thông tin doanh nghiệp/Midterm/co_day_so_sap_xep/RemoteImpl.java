import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class RemoteImpl extends UnicastRemoteObject implements RemoteInterface {
    private final List<Integer> numbers = Arrays.asList(5, 10, 3, 20, 7, 15, 1, 8);

    protected RemoteImpl() throws RemoteException {
        super();
    }

    @Override
    public List<Integer> sortList(boolean ascending) throws RemoteException {
        List<Integer> sortedNumbers = numbers;
        if (ascending) {
            Collections.sort(sortedNumbers); // tang 
        } else {
            sortedNumbers.sort(Collections.reverseOrder()); 
        }
        return sortedNumbers;
    }
}
