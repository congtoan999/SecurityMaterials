import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

public interface RemoteInterface extends Remote {
    List<Integer> sortList(boolean ascending) throws RemoteException;
}
