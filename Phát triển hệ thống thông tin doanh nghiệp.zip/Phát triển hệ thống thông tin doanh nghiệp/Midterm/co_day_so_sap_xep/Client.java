import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.List;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {
        try {
            Registry registry = LocateRegistry.getRegistry("localhost", 1099);
            RemoteInterface remoteObject = (RemoteInterface) registry.lookup("RemoteService");

            Scanner scanner = new Scanner(System.in);
            System.out.print("Nhập 1 để sắp xếp tăng dần, 0 để sắp xếp giảm dần: ");
            boolean ascending = scanner.nextInt() == 1;

            List<Integer> sortedList = remoteObject.sortList(ascending);

            System.out.println("Dãy số trên Server: [5, 10, 3, 20, 7, 15, 1, 8]");
            System.out.println("Danh sách sau khi sắp xếp: " + sortedList);

            scanner.close();
        } catch (Exception e) {
            System.err.println("Client exception: " + e.getMessage());
        }
    }
}
