import os
import webbrowser
import requests

CLIENT_ID = os.getenv("GITHUB_CLIENT_ID")
CLIENT_SECRET = os.getenv("GITHUB_CLIENT_SECRET")

AUTH_ENDPOINT = f"https://github.com/login/oauth/authorize?client_id={CLIENT_ID}&scope=user"
TOKEN_ENDPOINT = "https://github.com/login/oauth/access_token"
USER_ENDPOINT = "https://api.github.com/user"


webbrowser.open(AUTH_ENDPOINT, new=2)
print(f"If browser doesn't open, use: {AUTH_ENDPOINT}")
auth_code = input("Enter the auth code: ")

headers = {'Accept': 'application/json'}
response = requests.post(TOKEN_ENDPOINT, headers=headers, data={
    'client_id': CLIENT_ID,
    'client_secret': CLIENT_SECRET,
    'code': auth_code
})
token_data = response.json()

if 'access_token' not in token_data:
    print("❌ Không nhận được access token. Đáp ứng trả về:")
    print(token_data)
    exit()

token = token_data['access_token']

user_data = requests.get(USER_ENDPOINT, headers={
    "Authorization": f"token {token}"
}).json()


print("Username:", user_data.get("login", ""))
print("Name:", user_data.get("name", ""))
print("Email:", user_data.get("email", ""))
print("Company:", user_data.get("company", ""))
print("Bio:", user_data.get("bio", ""))
