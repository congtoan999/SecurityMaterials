import os
from flask import Flask, redirect, url_for
from flask_dance.contrib.github import make_github_blueprint, github

# Cho phép dùng HTTP thay vì HTTPS (chỉ dùng để demo/local test)
os.environ['OAUTHLIB_INSECURE_TRANSPORT'] = '1'

app = Flask(__name__)
app.secret_key = "supersecretkey"

github_bp = make_github_blueprint(
    client_id="Ov23liEdpmsimrP65RYR",
    client_secret="c4e3f6f3b2eb22ef2e7f1a3ee85a4708d4d3f668"
)
app.register_blueprint(github_bp, url_prefix="/login")

os.environ['OAUTHLIB_INSECURE_TRANSPORT'] = '1'

@app.route("/")
def index():
    if not github.authorized:
        return redirect(url_for("github.login"))
    resp = github.get("/user")
    user = resp.json()
    return f"👤 Logged in as: {user['login']}"

if __name__ == "__main__":
    app.run(debug=True)
