﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using ESDCProject.Models;

namespace ESDCProject.Controllers
{
    public class LoginController : Controller
    {
        private ESDCProjectDbContext db = new ESDCProjectDbContext();

        // GET: Login
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Tenant_Login()
        {
            if (Session["UserId"] != null && Session["UserRole"] != null)
            {
                int userRole = (int)Session["UserRole"];
                if (userRole == 2)
                {
                    // Redirect 302 (Moved Temporarily)
                    Response.StatusCode = 302;
                    Response.RedirectLocation = Url.Action("Index", "Profile", new { area = "Tenant" });
                    return new EmptyResult();
                }
            }

            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Tenant_Login(string email, string password)
        {
            if (Session["UserId"] != null && Session["UserRole"] != null && (int)Session["UserRole"] == 2)
            {
                // Redirect 302 (Moved Temporarily)
                Response.StatusCode = 302;
                Response.RedirectLocation = Url.Action("Index", "Profile", new { area = "Tenant" });
                return new EmptyResult();
            }

            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
            {
                ViewBag.ErrorMessage = "Vui lòng nhập tài khoản và mật khẩu";
                return View();
            }

            var user = db.Users.FirstOrDefault(u => u.Email == email && u.Password == password && u.Role == 2);
            if (user != null)
            {
                if (!user.IsActive)
                {
                    ViewBag.ErrorMessage = "Tài khoản đã bị vô hiệu hóa";
                    return View();
                }
                user.LastLogin = DateTime.Now;
                db.SaveChanges();
                FormsAuthentication.SetAuthCookie(user.Id.ToString(), false);
                Session["UserId"] = user.Id;
                Session["UserName"] = user.Name;
                Session["UserRole"] = user.Role;
                Session["UserEmail"] = user.Email;
                return RedirectToAction("Index", "Profile", new { area = "Tenant" });
            }
            else
            {
                ViewBag.ErrorMessage = "Tài khoản hoặc mật khẩu không chính xác";
                return View();
            }
        }

        public ActionResult Manager_Login()
        {
            if (Session["UserId"] != null && Session["UserRole"] != null)
            {
                int userRole = (int)Session["UserRole"];
                if (userRole == 0)
                {
                    // Redirect 302 (Moved Temporarily)
                    Response.StatusCode = 302;
                    Response.RedirectLocation = Url.Action("Index", "Default", new { area = "Admin" });
                    return new EmptyResult();
                }
                else if (userRole == 1)
                {
                    // Redirect 302 (Moved Temporarily)
                    Response.StatusCode = 302;
                    Response.RedirectLocation = Url.Action("Index", "Default", new { area = "Manager" });
                    return new EmptyResult();
                }
            }

            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Manager_Login(string email, string password)
        {
            if (Session["UserId"] != null && Session["UserRole"] != null)
            {
                int userRole = (int)Session["UserRole"];
                if (userRole == 0)
                {
                    // Redirect 302 (Moved Temporarily)
                    Response.StatusCode = 302;
                    Response.RedirectLocation = Url.Action("Index", "Default", new { area = "Admin" });
                    return new EmptyResult();
                }
                else if (userRole == 1)
                {
                    // Redirect 302 (Moved Temporarily)
                    Response.StatusCode = 302;
                    Response.RedirectLocation = Url.Action("Index", "Default", new { area = "Manager" });
                    return new EmptyResult();
                }
            }

            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
            {
                ViewBag.ErrorMessage = "Vui lòng nhập tài khoản và mật khẩu";
                return View();
            }
            var user = db.Users.FirstOrDefault(u => u.Email == email &&
                                                   u.Password == password &&
                                                   (u.Role == 0 || u.Role == 1));
            if (user != null)
            {
                if (!user.IsActive)
                {
                    ViewBag.ErrorMessage = "Tài khoản đã bị vô hiệu hóa";
                    return View();
                }
                user.LastLogin = DateTime.Now;
                db.SaveChanges();
                FormsAuthentication.SetAuthCookie(user.Id.ToString(), false);
                Session["UserId"] = user.Id;
                Session["UserName"] = user.Name;
                Session["UserRole"] = user.Role;
                Session["UserEmail"] = user.Email;
                if (user.Role == 0) // Admin
                {
                    return RedirectToAction("Index", "Default", new { area = "Admin" });
                }
                else // Manager (Role = 1)
                {
                    return RedirectToAction("Index", "Default", new { area = "Manager" });
                }
            }
            else
            {
                ViewBag.ErrorMessage = "Tài khoản hoặc mật khẩu không chính xác";
                return View();
            }
        }

        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            Session.Clear();
            Session.Abandon();

            return RedirectToAction("Index");
        }
    }
}