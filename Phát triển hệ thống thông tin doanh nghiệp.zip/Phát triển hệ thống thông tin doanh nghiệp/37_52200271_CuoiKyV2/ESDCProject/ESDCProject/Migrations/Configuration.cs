﻿namespace ESDCProject.Migrations
{
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;
    using ESDCProject.Models;

    internal sealed class Configuration : DbMigrationsConfiguration<ESDCProject.Models.ESDCProjectDbContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = true;
            AutomaticMigrationDataLossAllowed = true;
        }

        protected override void Seed(ESDCProject.Models.ESDCProjectDbContext context)
        {
            // Seed Users
            SeedUsers(context);

            // Seed Rooms
            SeedRooms(context);

            // Seed Contracts
            SeedContracts(context);

            // Seed Bills
            SeedBills(context);

            // Seed Payments
            SeedPayments(context);

            // Seed Vehicles
            SeedVehicles(context);

            // Seed Requests
            SeedRequests(context);

            // Seed Fixed Prices
            SeedFixedPrices(context);

            // Seed Temporary Residences
            SeedTemporaryResidences(context);
        }

        private void SeedUsers(ESDCProjectDbContext context)
        {
            if (context.Users.Any(u => u.Email == "admin@gmail.com"))
                return;

            var users = new List<User>
            {
                new User
                {
                    Email = "admin@gmail.com",
                    Name = "Admin",
                    Password = "Admin@123",
                    Role = 0, // Admin
                    Phone = "0900000000",
                    IdentityNumber = "082200000000",
                    IsActive = true,
                    CreatedAt = DateTime.Now,
                    Avatar = "default-avatar.jpg"
                },
                new User
                {
                    Email = "manager1@gmail.com",
                    Name = "Nguyễn Văn An",
                    Password = "Manager@123",
                    Role = 1, // Manager
                    Phone = "0910000001",
                    IdentityNumber = "082210000001",
                    Address = "123 Lê Lợi, Quận 1, TP. HCM",
                    IsActive = true,
                    CreatedAt = DateTime.Now,
                    Avatar = "default-avatar.jpg"
                },
                new User
                {
                    Email = "manager2@gmail.com",
                    Name = "Trần Thị Bình",
                    Password = "Manager@123",
                    Role = 1, // Manager
                    Phone = "0910000002",
                    IdentityNumber = "082210000002",
                    Address = "456 Nguyễn Huệ, Quận 1, TP. HCM",
                    IsActive = true,
                    CreatedAt = DateTime.Now,
                    Avatar = "default-avatar.jpg"
                },
                new User
                {
                    Email = "tenant1@gmail.com",
                    Name = "Lê Văn Cường",
                    Password = "Tenant@123",
                    Role = 2, // Tenant
                    IsFemale = false,
                    DateOfBirth = new DateTime(1998, 5, 15),
                    Phone = "0920000001",
                    IdentityNumber = "082220000001",
                    Address = "789 Trần Hưng Đạo, Quận 5, TP. HCM",
                    IsActive = true,
                    CreatedAt = DateTime.Now,
                    Avatar = "default-avatar.jpg"
                },
                new User
                {
                    Email = "tenant2@gmail.com",
                    Name = "Phạm Thị Duyên",
                    Password = "Tenant@123",
                    Role = 2, // Tenant
                    IsFemale = true,
                    DateOfBirth = new DateTime(1999, 3, 20),
                    Phone = "0920000002",
                    IdentityNumber = "082220000002",
                    Address = "101 Nguyễn Trãi, Quận 5, TP. HCM",
                    IsActive = true,
                    CreatedAt = DateTime.Now,
                    Avatar = "default-avatar.jpg"
                },
                new User
                {
                    Email = "tenant3@gmail.com",
                    Name = "Ngô Văn Em",
                    Password = "Tenant@123",
                    Role = 2, // Tenant
                    IsFemale = false,
                    DateOfBirth = new DateTime(1997, 12, 10),
                    Phone = "0920000003",
                    IdentityNumber = "082220000003",
                    Address = "202 Phạm Văn Đồng, Quận Thủ Đức, TP. HCM",
                    IsActive = true,
                    CreatedAt = DateTime.Now,
                    Avatar = "default-avatar.jpg"
                },
                new User
                {
                    Email = "tenant4@gmail.com",
                    Name = "Đỗ Thị Phượng",
                    Password = "Tenant@123",
                    Role = 2, // Tenant
                    IsFemale = true,
                    DateOfBirth = new DateTime(2000, 7, 25),
                    Phone = "0920000004",
                    IdentityNumber = "082220000004",
                    Address = "303 Võ Văn Tần, Quận 3, TP. HCM",
                    IsActive = true,
                    CreatedAt = DateTime.Now,
                    Avatar = "default-avatar.jpg"
                },
                new User
                {
                    Email = "tenant5@gmail.com",
                    Name = "Hoàng Văn Giang",
                    Password = "Tenant@123",
                    Role = 2, // Tenant
                    IsFemale = false,
                    DateOfBirth = new DateTime(1996, 9, 12),
                    Phone = "0920000005",
                    IdentityNumber = "082220000005",
                    Address = "404 Cách Mạng Tháng Tám, Quận 10, TP. HCM",
                    IsActive = true,
                    CreatedAt = DateTime.Now,
                    Avatar = "default-avatar.jpg"
                },
                new User
                {
                    Email = "tenant6@gmail.com",
                    Name = "Bùi Thị Hồng",
                    Password = "Tenant@123",
                    Role = 2, // Tenant
                    IsFemale = true,
                    DateOfBirth = new DateTime(2001, 11, 18),
                    Phone = "0920000006",
                    IdentityNumber = "082220000006",
                    Address = "505 Lý Thường Kiệt, Quận Tân Bình, TP. HCM",
                    IsActive = true,
                    CreatedAt = DateTime.Now,
                    Avatar = "default-avatar.jpg"
                },
                new User
                {
                    Email = "tenant7@gmail.com",
                    Name = "Vũ Văn Linh",
                    Password = "Tenant@123",
                    Role = 2, // Tenant
                    IsFemale = false,
                    DateOfBirth = new DateTime(1995, 8, 20),
                    Phone = "0920000007",
                    IdentityNumber = "082220000007",
                    Address = "606 Nguyễn Văn Cừ, Quận 5, TP. HCM",
                    IsActive = true,
                    CreatedAt = DateTime.Now,
                    Avatar = "default-avatar.jpg"
                }
            };

            context.Users.AddOrUpdate(u => u.Email, users.ToArray());
            context.SaveChanges();
        }

        private void SeedRooms(ESDCProjectDbContext context)
        {
            if (context.Rooms.Any(r => r.RoomNumber == "A101"))
                return;

            var rooms = new List<Room>
            {
                new Room
                {
                    RoomNumber = "A101",
                    Area = "A1",
                    BasePrice = 3200000,
                    MaxOccupants = 2,
                    Description = "Phòng đơn, máy lạnh, có ban công",
                    Status = 0, // Available
                    CreatedAt = DateTime.Now
                },
                new Room
                {
                    RoomNumber = "A102",
                    Area = "A1",
                    BasePrice = 3500000,
                    MaxOccupants = 3,
                    Description = "Phòng đôi, máy lạnh, gần cửa sổ",
                    Status = 0,
                    CreatedAt = DateTime.Now
                },
                new Room
                {
                    RoomNumber = "A103",
                    Area = "A1",
                    BasePrice = 3000000,
                    MaxOccupants = 2,
                    Description = "Phòng đơn, không máy lạnh",
                    Status = 0,
                    CreatedAt = DateTime.Now
                },
                new Room
                {
                    RoomNumber = "B201",
                    Area = "B2",
                    BasePrice = 4000000,
                    MaxOccupants = 4,
                    Description = "Phòng gia đình, máy lạnh, có bếp nhỏ",
                    Status = 0,
                    CreatedAt = DateTime.Now
                },
                new Room
                {
                    RoomNumber = "B202",
                    Area = "B2",
                    BasePrice = 3800000,
                    MaxOccupants = 3,
                    Description = "Phòng đôi, máy lạnh, có ban công",
                    Status = 0,
                    CreatedAt = DateTime.Now
                },
                new Room
                {
                    RoomNumber = "B203",
                    Area = "B2",
                    BasePrice = 3100000,
                    MaxOccupants = 2,
                    Description = "Phòng đơn, không máy lạnh",
                    Status = 0,
                    CreatedAt = DateTime.Now
                },
                new Room
                {
                    RoomNumber = "C301",
                    Area = "C3",
                    BasePrice = 4500000,
                    MaxOccupants = 5,
                    Description = "Phòng lớn, máy lạnh, có bếp",
                    Status = 0,
                    CreatedAt = DateTime.Now
                },
                new Room
                {
                    RoomNumber = "C302",
                    Area = "C3",
                    BasePrice = 4200000,
                    MaxOccupants = 4,
                    Description = "Phòng gia đình, máy lạnh",
                    Status = 0,
                    CreatedAt = DateTime.Now
                }
            };

            context.Rooms.AddOrUpdate(r => r.RoomNumber, rooms.ToArray());
            context.SaveChanges();
        }

        private void SeedContracts(ESDCProjectDbContext context)
        {
            if (context.Contracts.Any(c => c.ContractNumber == "HD001"))
                return;

            var tenants = context.Users.Where(u => u.Role == 2).Take(6).ToList(); // 6 tenants
            var rooms = context.Rooms.Take(6).ToList(); // 6 rooms

            if (tenants.Count < 6 || rooms.Count < 6)
                return;

            var contracts = new List<Contract>();
            for (int i = 0; i < 6; i++)
            {
                bool isTerminated = i % 2 == 0; // Alternate terminated status
                contracts.Add(new Contract
                {
                    ContractNumber = $"HD00{i + 1}",
                    UserId = tenants[i].Id,
                    RoomId = rooms[i].Id,
                    Price = rooms[i].BasePrice,
                    Deposit = rooms[i].BasePrice * 2,
                    StartDate = DateTime.Now.AddMonths(-6 + i),
                    EndDate = DateTime.Now.AddMonths(6 + i),
                    IsTerminated = isTerminated,
                    PaymentDayOfMonth = 5
                });

                // Update room status and assign room to tenant
                rooms[i].Status = isTerminated ? 0 : 1; // Occupied if not terminated
                tenants[i].RoomId = rooms[i].Id;
            }

            context.Contracts.AddOrUpdate(c => c.ContractNumber, contracts.ToArray());
            context.SaveChanges();
        }

        private void SeedBills(ESDCProjectDbContext context)
        {
            var contracts = context.Contracts.Take(6).ToList();
            int firstContractId = contracts[0].Id;
            if (contracts.Count < 6 || context.Bills.Any(b => b.ContractId == firstContractId && b.BillingPeriodStart == new DateTime(2025, 3, 1)))
                return;

            var bills = new List<Bill>();
            for (int i = 0; i < 6; i++)
            {
                int month = 3 - i; // March 2025 down to October 2024
                int year = 2025;
                if (month < 1)
                {
                    month += 12;
                    year--;
                }

                bills.Add(new Bill
                {
                    PreviousElectricity = 100 + (i * 10),
                    CurrentElectricity = 150 + (i * 10),
                    ElectricityQuantity = 50,
                    PreviousWater = 20 + (i * 2),
                    CurrentWater = 30 + (i * 2),
                    WaterQuantity = 10,
                    ElectricityFee = 50 * 3200, // FixedPrice for electricity
                    WaterFee = 10 * 20000, // FixedPrice for water
                    VehicleFee = 100000 + (i * 20000),
                    RentFee = contracts[i].Price,
                    BillingPeriodStart = new DateTime(year, month, 1),
                    BillingPeriodEnd = new DateTime(year, month, DateTime.DaysInMonth(year, month)),
                    Status = i % 2, // 0: Unpaid, 1: Paid
                    ContractId = contracts[i].Id,
                    UserId = contracts[i].UserId,
                    DateOfBill = new DateTime(year, month, 10),
                    IsPaid = i % 2 == 1
                });
            }

            context.Bills.AddOrUpdate(b => new { b.ContractId, b.BillingPeriodStart }, bills.ToArray());
            context.SaveChanges();
        }

        private void SeedPayments(ESDCProjectDbContext context)
        {
            var bills = context.Bills.Where(b => b.IsPaid).Take(3).ToList(); // Only paid bills

            var firstBillId = bills[0].Id;
            if (bills.Count < 3 || context.Payments.Any(p => p.BillId == firstBillId))
                return;


            var payments = new List<Payment>();
            for (int i = 0; i < bills.Count; i++)
            {
                payments.Add(new Payment
                {
                    Amount = bills[i].RentFee + bills[i].ElectricityFee + bills[i].WaterFee + bills[i].VehicleFee,
                    Description = $"Thanh toán hóa đơn tháng {bills[i].BillingPeriodStart:MM/yyyy}",
                    PaymentDate = bills[i].DateOfBill.AddDays(5),
                    Method = i % 3, // 0: Cash, 1: Bank Transfer, 2: Card
                    TransactionReference = $"TRANS{bills[i].Id}{i + 1}",
                    BillId = bills[i].Id,
                    UserId = bills[i].UserId
                });
            }

            context.Payments.AddOrUpdate(p => new { p.BillId, p.PaymentDate }, payments.ToArray());
            context.SaveChanges();
        }

        private void SeedVehicles(ESDCProjectDbContext context)
        {
            var rooms = context.Rooms.Take(6).ToList();
            if (rooms.Count < 6 || context.Vehicles.Any(v => v.Number == "59A1-123.45"))
                return;

            var vehicles = new List<Vehicle>
            {
                new Vehicle
                {
                    Name = "Xe máy Honda Vision",
                    Number = "59A1-123.45",
                    Price = 120000,
                    Category = 0, // Motorcycle
                    RoomId = rooms[0].Id
                },
                new Vehicle
                {
                    Name = "Xe máy Yamaha Sirius",
                    Number = "59A1-234.56",
                    Price = 100000,
                    Category = 0,
                    RoomId = rooms[1].Id
                },
                new Vehicle
                {
                    Name = "Xe đạp điện Pega",
                    Number = "59A1-345.67",
                    Price = 60000,
                    Category = 2, // Bicycle
                    RoomId = rooms[2].Id
                },
                new Vehicle
                {
                    Name = "Xe máy Honda Wave",
                    Number = "59A1-456.78",
                    Price = 100000,
                    Category = 0,
                    RoomId = rooms[3].Id
                },
                new Vehicle
                {
                    Name = "Xe ô tô Toyota Vios",
                    Number = "51H-123.45",
                    Price = 300000,
                    Category = 1, // Car
                    RoomId = rooms[4].Id
                },
                new Vehicle
                {
                    Name = "Xe máy Honda Air Blade",
                    Number = "59A1-567.89",
                    Price = 130000,
                    Category = 0,
                    RoomId = rooms[5].Id
                }
            };

            context.Vehicles.AddOrUpdate(v => v.Number, vehicles.ToArray());
            context.SaveChanges();
        }

        private void SeedRequests(ESDCProjectDbContext context)
        {
            var tenants = context.Users.Where(u => u.Role == 2).Take(6).ToList();
            int tenantId = tenants[0].Id;
            if (tenants.Count < 6 || context.Requests.Any(r => r.UserId == tenantId && r.Des == "Sửa hệ thống điện phòng A101"))
                return;

            var requests = new List<Request>
            {
                new Request
                {
                    UserId = tenants[0].Id,
                    Des = "Sửa hệ thống điện phòng A101",
                    Status = 0, // Pending
                    CreatedAt = DateTime.Now
                },
                new Request
                {
                    UserId = tenants[1].Id,
                    Des = "Kiểm tra rò rỉ nước phòng A102",
                    Status = 1, // In Progress
                    CreatedAt = DateTime.Now.AddDays(-2)
                },
                new Request
                {
                    UserId = tenants[2].Id,
                    Des = "Dọn vệ sinh phòng A103",
                    Status = 2, // Completed
                    CreatedAt = DateTime.Now.AddDays(-4)
                },
                new Request
                {
                    UserId = tenants[3].Id,
                    Des = "Lắp thêm ổ điện phòng B201",
                    Status = 0,
                    CreatedAt = DateTime.Now.AddDays(-6)
                },
                new Request
                {
                    UserId = tenants[4].Id,
                    Des = "Sửa cửa chính phòng B202",
                    Status = 1,
                    CreatedAt = DateTime.Now.AddDays(-8)
                },
                new Request
                {
                    UserId = tenants[5].Id,
                    Des = "Kiểm tra máy lạnh phòng B203",
                    Status = 2,
                    CreatedAt = DateTime.Now.AddDays(-10)
                }
            };

            context.Requests.AddOrUpdate(r => new { r.UserId, r.Des }, requests.ToArray());
            context.SaveChanges();
        }

        private void SeedFixedPrices(ESDCProjectDbContext context)
        {
            if (context.FixedPrices.Any())
                return;

            var fixedPrices = new List<FixedPrice>
            {
                new FixedPrice { Type = FixedPriceType.Water, Price = 20000 },
                new FixedPrice { Type = FixedPriceType.Electricity, Price = 3200 }
            };

            context.FixedPrices.AddOrUpdate(fp => fp.Type, fixedPrices.ToArray());
            context.SaveChanges();
        }

        private void SeedTemporaryResidences(ESDCProjectDbContext context)
        {
            var tenants = context.Users.Where(u => u.Role == 2).Take(6).ToList();
            var firstTenantId = tenants[0].Id;
            var firstTenantName = tenants[0].Name;
            if (tenants.Count < 6 || context.TemporaryResidences.Any(tr => tr.UserId == firstTenantId && tr.FullName == firstTenantName))
                return;

            var tempResidences = new List<TemporaryResidence>();
            for (int i = 0; i < 6; i++)
            {
                tempResidences.Add(new TemporaryResidence
                {
                    UserId = tenants[i].Id,
                    FullName = tenants[i].Name,
                    DateOfBirth = tenants[i].DateOfBirth,
                    IdentityNumber = tenants[i].IdentityNumber,
                    IdentityIssueDate = DateTime.Now.AddYears(-2),
                    IdentityIssuePlace = "CA TP.HCM",
                    PermanentAddress = $"Phường {i + 1}, Quận {i + 1}, TP.HCM",
                    TemporaryAddress = tenants[i].Address,
                    NameOfLocalPolice = $"CA Phường {(i % 2 == 0 ? "Tân Phong" : "Bến Nghé")}",
                    StayReason = "Thuê trọ",
                    CurrentDate = DateTime.Now,
                    CreatedAt = DateTime.Now,
                    Status = i % 2 // 0: Pending, 1: Approved
                });
            }

            context.TemporaryResidences.AddOrUpdate(tr => new { tr.UserId, tr.FullName }, tempResidences.ToArray());
            context.SaveChanges();
        }
    }
}