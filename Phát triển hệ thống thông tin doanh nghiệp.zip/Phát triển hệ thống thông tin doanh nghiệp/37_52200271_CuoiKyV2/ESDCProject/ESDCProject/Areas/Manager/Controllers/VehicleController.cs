﻿using ESDCProject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ESDCProject.Areas.Manager.Controllers
{
    public class VehicleController : Controller
    {
        private ESDCProjectDbContext db = new ESDCProjectDbContext();

        // GET: Admin/Vehicle
        public ActionResult Index(int page = 1, int pageSize = 10, string sort = "", string search = "")
        {
            ViewBag.SelectedSort = sort;
            ViewBag.Search = search;

            var vehicles = db.Vehicles.AsQueryable();

            // Apply searching
            if (!string.IsNullOrEmpty(search))
            {
                search = search.ToLower();
                vehicles = vehicles.Where(v =>
                    v.Name.ToLower().Contains(search) ||
                    v.Number.ToLower().Contains(search) ||
                    v.Room.RoomNumber.ToLower().Contains(search)
                );
            }

            // Apply sorting
            switch (sort)
            {
                case "name_asc":
                    vehicles = vehicles.OrderBy(v => v.Name);
                    break;
                case "name_desc":
                    vehicles = vehicles.OrderByDescending(v => v.Name);
                    break;
                case "number_asc":
                    vehicles = vehicles.OrderBy(v => v.Number);
                    break;
                case "number_desc":
                    vehicles = vehicles.OrderByDescending(v => v.Number);
                    break;
                case "price_asc":
                    vehicles = vehicles.OrderBy(v => v.Price);
                    break;
                case "price_desc":
                    vehicles = vehicles.OrderByDescending(v => v.Price);
                    break;
                case "category_asc":
                    vehicles = vehicles.OrderBy(v => v.Category);
                    break;
                case "category_desc":
                    vehicles = vehicles.OrderByDescending(v => v.Category);
                    break;
                case "room_asc":
                    vehicles = vehicles.OrderBy(v => v.Room.RoomNumber);
                    break;
                case "room_desc":
                    vehicles = vehicles.OrderByDescending(v => v.Room.RoomNumber);
                    break;
                default:
                    vehicles = vehicles.OrderBy(v => v.Name);
                    break;
            }

            // Apply pagination
            int totalItems = vehicles.Count();
            var pagedVehicles = vehicles
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToList();

            ViewBag.RoomId = new SelectList(db.Rooms, "Id", "RoomNumber");
            ViewBag.CurrentPage = page;
            ViewBag.PageSize = pageSize;
            ViewBag.TotalItems = totalItems;
            ViewBag.TotalPages = (int)Math.Ceiling((double)totalItems / pageSize);

            return View(pagedVehicles);
        }

        // GET: Admin/Vehicle/Details/5
        public ActionResult Details(int id)
        {
            Vehicle vehicle = db.Vehicles.Find(id);
            if (vehicle == null)
            {
                return HttpNotFound();
            }
            return View(vehicle);
        }

        // GET: Admin/Vehicle/Create
        public ActionResult Create()
        {
            ViewBag.RoomId = new SelectList(db.Rooms, "Id", "RoomNumber");
            Vehicle vehicle = new Vehicle
            {
                Price = 100000,
                Category = 0
            };
            return View(vehicle);
        }

        // POST: Admin/Vehicle/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Vehicle vehicle)
        {
            if (ModelState.IsValid)
            {
                db.Vehicles.Add(vehicle);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.RoomId = new SelectList(db.Rooms, "Id", "RoomNumber", vehicle.RoomId);
            return View(vehicle);
        }

        // GET: Admin/Vehicle/Details/5
        public ActionResult Detail(int id)
        {
            try
            {
                var vehicle = db.Vehicles.Include("Room").FirstOrDefault(v => v.Id == id);
                if (vehicle == null)
                {
                    Response.StatusCode = 404;
                    return Json(new { error = "Vehicle not found" }, JsonRequestBehavior.AllowGet);
                }

                if (Request.Headers["X-Requested-With"] == "XMLHttpRequest")
                {
                    return Json(new
                    {
                        Id = vehicle.Id,
                        Name = vehicle.Name ?? "",
                        Number = vehicle.Number ?? "",
                        Category = vehicle.Category,
                        Price = vehicle.Price,
                        RoomId = vehicle.RoomId,
                        Room = vehicle.Room != null ? new { RoomNumber = vehicle.Room.RoomNumber } : null
                    }, JsonRequestBehavior.AllowGet);
                }

                return View(vehicle);
            }
            catch (Exception ex)
            {
                Response.StatusCode = 500;
                return Json(new { error = "Server error: " + ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult Edit(int id)
        {
            try
            {
                var vehicle = db.Vehicles.Find(id);
                if (vehicle == null)
                {
                    Response.StatusCode = 404;
                    return Json(new { error = "Vehicle not found" }, JsonRequestBehavior.AllowGet);
                }

                return Json(new
                {
                    Id = vehicle.Id,
                    Name = vehicle.Name ?? "",
                    Number = vehicle.Number ?? "",
                    Category = vehicle.Category,
                    Price = vehicle.Price,
                    RoomId = vehicle.RoomId
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                Response.StatusCode = 500;
                return Json(new { error = "Server error: " + ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        // POST: Admin/Vehicle/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Vehicle vehicle, int page = 1, string sort = "", string search = "")
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var existingVehicle = db.Vehicles.Find(vehicle.Id);
                    if (existingVehicle == null)
                    {
                        if (Request.IsAjaxRequest())
                        {
                            Response.StatusCode = 404;
                            return Json(new { success = false, message = "Vehicle not found" });
                        }
                        return HttpNotFound();
                    }

                    existingVehicle.Name = vehicle.Name;
                    existingVehicle.Number = vehicle.Number;
                    existingVehicle.Category = vehicle.Category;
                    existingVehicle.Price = vehicle.Price;
                    existingVehicle.RoomId = vehicle.RoomId;

                    db.SaveChanges();

                    if (Request.IsAjaxRequest())
                    {
                        return Json(new { success = true });
                    }
                    return RedirectToAction("Index", "Vehicle", new { area = "Admin", page, sort, search });
                }

                if (Request.IsAjaxRequest())
                {
                    Response.StatusCode = 400;
                    return Json(new { success = false, message = "Invalid data" });
                }

                ViewBag.RoomId = new SelectList(db.Rooms, "Id", "RoomNumber", vehicle.RoomId);
                return View(vehicle);
            }
            catch (Exception ex)
            {
                if (Request.IsAjaxRequest())
                {
                    Response.StatusCode = 500;
                    return Json(new { success = false, message = ex.Message });
                }
                ModelState.AddModelError("", "Error updating vehicle: " + ex.Message);
                ViewBag.RoomId = new SelectList(db.Rooms, "Id", "RoomNumber", vehicle.RoomId);
                return View(vehicle);
            }
        }

        // GET: Admin/Vehicle/Delete/5
        public ActionResult Delete(int id)
        {
            Vehicle vehicle = db.Vehicles.Find(id);
            if (vehicle == null)
            {
                return HttpNotFound();
            }
            return View(vehicle);
        }

        // POST: Admin/Vehicle/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id, int page = 1, string sort = "", string search = "")
        {
            try
            {
                Vehicle vehicle = db.Vehicles.Find(id);
                if (vehicle == null)
                {
                    return HttpNotFound();
                }

                db.Vehicles.Remove(vehicle);
                db.SaveChanges();

                if (Request.IsAjaxRequest())
                {
                    return Json(new { success = true });
                }

                return RedirectToAction("Index", new { page, sort, search });
            }
            catch (Exception ex)
            {
                if (Request.IsAjaxRequest())
                {
                    Response.StatusCode = 500;
                    return Json(new { success = false, message = ex.Message });
                }

                ModelState.AddModelError("", "Lỗi khi xóa phương tiện: " + ex.Message);
                return RedirectToAction("Index");
            }
        }

        private string GetCategoryName(int categoryCode)
        {
            switch (categoryCode)
            {
                case 0:
                    return "Xe máy";
                case 1:
                    return "Ô tô";
                case 2:
                    return "Xe đạp";
                default:
                    return "Khác";
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}