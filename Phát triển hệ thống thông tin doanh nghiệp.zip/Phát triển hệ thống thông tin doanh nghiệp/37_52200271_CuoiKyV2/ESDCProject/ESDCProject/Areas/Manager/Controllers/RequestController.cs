﻿using ESDCProject.Models;
using System;
using System.Data.Entity;
using System.Linq;
using System.Web.Mvc;

namespace ESDCProject.Areas.Manager.Controllers
{
    public class RequestController : Controller
    {
        private ESDCProjectDbContext db = new ESDCProjectDbContext();

        // GET: Admin/Request
        public ActionResult Index(int page = 1, int pageSize = 10, string sort = "", string search = "", string searchStatus = "")
        {
            ViewBag.SelectedSort = sort;
            ViewBag.Search = search;
            ViewBag.SearchStatus = searchStatus;

            var requests = db.Requests
                .Include(r => r.User)
                .Include(r => r.User.Room)
                .AsQueryable();

            // Apply Searching
            if (!string.IsNullOrEmpty(search))
            {
                search = search.ToLower();
                requests = requests.Where(r =>
                    (r.User != null && r.User.Name.ToLower().Contains(search)) ||
                    (r.User != null && r.User.Room != null && r.User.Room.RoomNumber.ToLower().Contains(search)) ||
                    (r.Des != null && r.Des.ToLower().Contains(search))
                );
            }

            // Apply Status Filter
            if (!string.IsNullOrEmpty(searchStatus) && int.TryParse(searchStatus, out int status) && status >= 0 && status <= 2)
            {
                requests = requests.Where(r => r.Status == status);
            }

            // Apply Sorting
            switch (sort)
            {
                case "user_asc":
                    requests = requests.OrderBy(r => r.User.Name);
                    break;
                case "user_desc":
                    requests = requests.OrderByDescending(r => r.User.Name);
                    break;
                case "status_asc":
                    requests = requests.OrderBy(r => r.Status);
                    break;
                case "status_desc":
                    requests = requests.OrderByDescending(r => r.Status);
                    break;
                case "date_asc":
                    requests = requests.OrderBy(r => r.CreatedAt);
                    break;
                case "date_desc":
                    requests = requests.OrderByDescending(r => r.CreatedAt);
                    break;
                case "room_asc":
                    requests = requests.OrderBy(r => r.User.Room.RoomNumber);
                    break;
                case "room_desc":
                    requests = requests.OrderByDescending(r => r.User.Room.RoomNumber);
                    break;
                default:
                    requests = requests.OrderByDescending(r => r.CreatedAt);
                    break;
            }

            // Apply Pagination
            int totalItems = requests.Count();
            var pagedRequests = requests
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToList();

            ViewBag.CurrentPage = page;
            ViewBag.PageSize = pageSize;
            ViewBag.TotalItems = totalItems;
            ViewBag.TotalPages = (int)Math.Ceiling((double)totalItems / pageSize);

            return View(pagedRequests);
        }

        // GET: Admin/Request/Approve/5
        public ActionResult Approve(int id, int page = 1, string sort = "", string search = "", string searchStatus = "")
        {
            try
            {
                var request = db.Requests.Find(id);
                if (request == null)
                {
                    if (Request.IsAjaxRequest())
                    {
                        Response.StatusCode = 404;
                        return Json(new { success = false, message = "Yêu cầu không tồn tại" }, JsonRequestBehavior.AllowGet);
                    }
                    TempData["Error"] = "Yêu cầu không tồn tại";
                    return RedirectToAction("Index", new { page, sort, search, searchStatus });
                }

                request.Status = 1; // Đã duyệt
                db.SaveChanges();
                TempData["Message"] = "Duyệt yêu cầu thành công!";

                if (Request.IsAjaxRequest())
                {
                    return Json(new { success = true, message = "Duyệt yêu cầu thành công!" }, JsonRequestBehavior.AllowGet);
                }

                return RedirectToAction("Index", new { page, sort, search, searchStatus });
            }
            catch (Exception ex)
            {
                if (Request.IsAjaxRequest())
                {
                    Response.StatusCode = 500;
                    return Json(new { success = false, message = $"Lỗi server: {ex.Message}" }, JsonRequestBehavior.AllowGet);
                }
                TempData["Error"] = $"Lỗi khi duyệt yêu cầu: {ex.Message}";
                return RedirectToAction("Index", new { page, sort, search, searchStatus });
            }
        }

        // GET: Admin/Request/Reject/5
        public ActionResult Reject(int id, int page = 1, string sort = "", string search = "", string searchStatus = "")
        {
            try
            {
                var request = db.Requests.Find(id);
                if (request == null)
                {
                    if (Request.IsAjaxRequest())
                    {
                        Response.StatusCode = 404;
                        return Json(new { success = false, message = "Yêu cầu không tồn tại" }, JsonRequestBehavior.AllowGet);
                    }
                    TempData["Error"] = "Yêu cầu không tồn tại";
                    return RedirectToAction("Index", new { page, sort, search, searchStatus });
                }

                request.Status = 2; // Bị từ chối
                db.SaveChanges();
                TempData["Message"] = "Từ chối yêu cầu thành công!";

                if (Request.IsAjaxRequest())
                {
                    return Json(new { success = true, message = "Từ chối yêu cầu thành công!" }, JsonRequestBehavior.AllowGet);
                }

                return RedirectToAction("Index", new { page, sort, search, searchStatus });
            }
            catch (Exception ex)
            {
                if (Request.IsAjaxRequest())
                {
                    Response.StatusCode = 500;
                    return Json(new { success = false, message = $"Lỗi server: {ex.Message}" }, JsonRequestBehavior.AllowGet);
                }
                TempData["Error"] = $"Lỗi khi từ chối yêu cầu: {ex.Message}";
                return RedirectToAction("Index", new { page, sort, search, searchStatus });
            }
        }

        // GET: Admin/Request/Delete/5
        public ActionResult Delete(int id)
        {
            try
            {
                var request = db.Requests
                    .Include(r => r.User)
                    .Include(r => r.User.Room)
                    .FirstOrDefault(r => r.Id == id);
                if (request == null)
                {
                    if (Request.IsAjaxRequest())
                    {
                        Response.StatusCode = 404;
                        return Json(new { error = "Yêu cầu không tồn tại" }, JsonRequestBehavior.AllowGet);
                    }
                    return HttpNotFound();
                }

                if (Request.IsAjaxRequest())
                {
                    string statusText;
                    switch (request.Status)
                    {
                        case 0:
                            statusText = "Đang chờ";
                            break;
                        case 1:
                            statusText = "Đã duyệt";
                            break;
                        case 2:
                            statusText = "Bị từ chối";
                            break;
                        default:
                            statusText = "Không xác định";
                            break;
                    }

                    return Json(new
                    {
                        Id = request.Id,
                        UserName = request.User?.Name ?? "N/A",
                        RoomNumber = request.User?.Room?.RoomNumber ?? "N/A",
                        Description = request.Des ?? "N/A",
                        Status = statusText,
                        CreatedAt = request.CreatedAt.ToString("dd/MM/yyyy HH:mm")
                    }, JsonRequestBehavior.AllowGet);
                }

                return View(request);
            }
            catch (Exception ex)
            {
                if (Request.IsAjaxRequest())
                {
                    Response.StatusCode = 500;
                    return Json(new { error = $"Lỗi server: {ex.Message}" }, JsonRequestBehavior.AllowGet);
                }
                TempData["Error"] = $"Lỗi khi lấy dữ liệu xóa: {ex.Message}";
                return RedirectToAction("Index");
            }
        }

        // POST: Admin/Request/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id, int page = 1, string sort = "", string search = "", string searchStatus = "")
        {
            try
            {
                var request = db.Requests.Find(id);
                if (request == null)
                {
                    if (Request.IsAjaxRequest())
                    {
                        Response.StatusCode = 404;
                        return Json(new { success = false, message = "Yêu cầu không tồn tại!" }, JsonRequestBehavior.AllowGet);
                    }
                    TempData["Error"] = "Yêu cầu không tồn tại!";
                    return RedirectToAction("Index", new { page, sort, search, searchStatus });
                }

                db.Requests.Remove(request);
                db.SaveChanges();
                TempData["Message"] = "Xóa yêu cầu thành công!";

                if (Request.IsAjaxRequest())
                {
                    return Json(new { success = true, message = "Xóa yêu cầu thành công!" }, JsonRequestBehavior.AllowGet);
                }

                return RedirectToAction("Index", new { page, sort, search, searchStatus });
            }
            catch (Exception ex)
            {
                if (Request.IsAjaxRequest())
                {
                    Response.StatusCode = 500;
                    return Json(new { success = false, message = $"Lỗi server: {ex.Message}" }, JsonRequestBehavior.AllowGet);
                }
                TempData["Error"] = $"Lỗi khi xóa yêu cầu: {ex.Message}";
                return RedirectToAction("Index", new { page, sort, search, searchStatus });
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}