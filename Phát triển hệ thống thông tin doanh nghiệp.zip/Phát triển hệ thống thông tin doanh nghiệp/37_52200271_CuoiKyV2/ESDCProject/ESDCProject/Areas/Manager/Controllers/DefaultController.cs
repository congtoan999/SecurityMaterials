﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ESDCProject.Models;

namespace ESDCProject.Areas.Manager.Controllers
{
    public class DefaultController : Controller
    {
        private ESDCProjectDbContext db = new ESDCProjectDbContext();

        // GET: Manager/Default
        public ActionResult Index()
        {
            var totalRooms = db.Rooms.Count();
            var totalTenants = db.Users.Count(u => u.Role == 2);
            var totalRequests = db.Requests.Count();
            var unpaidRooms = db.Bills
                .Where(b => !b.IsPaid)
                .Select(b => b.User.RoomId)
                .Distinct()
                .Count();

            ViewBag.TotalRooms = totalRooms;
            ViewBag.TotalTenants = totalTenants;
            ViewBag.TotalRequests = totalRequests;
            ViewBag.UnpaidRooms = unpaidRooms;

            return View();
        }
    }
}