﻿using ESDCProject.Areas.Admin.ViewModels;
using ESDCProject.Models;
using System;
using System.Linq;
using System.Web.Mvc;

namespace ESDCProject.Areas.Manager.Controllers
{
    public class FixedPriceController : Controller
    {
        private ESDCProjectDbContext db = new ESDCProjectDbContext();

        // GET: Manager/FixedPrice
        public ActionResult Index(int page = 1, int pageSize = 10, string sort = "")
        {
            ViewBag.SelectedSort = sort;

            var fixedPrices = db.FixedPrices.AsQueryable();

            // Apply sorting
            switch (sort)
            {
                case "type_asc":
                    fixedPrices = fixedPrices.OrderBy(fp => fp.Type);
                    break;
                case "type_desc":
                    fixedPrices = fixedPrices.OrderByDescending(fp => fp.Type);
                    break;
                case "price_asc":
                    fixedPrices = fixedPrices.OrderBy(fp => fp.Price);
                    break;
                case "price_desc":
                    fixedPrices = fixedPrices.OrderByDescending(fp => fp.Price);
                    break;
                default:
                    fixedPrices = fixedPrices.OrderBy(fp => fp.Type);
                    break;
            }

            int totalItems = fixedPrices.Count();
            var pagedFixedPrices = fixedPrices
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToList();

            ViewBag.CurrentPage = page;
            ViewBag.PageSize = pageSize;
            ViewBag.TotalItems = totalItems;
            ViewBag.TotalPages = (int)Math.Ceiling((double)totalItems / pageSize);

            return View(pagedFixedPrices);
        }

        // GET: Manager/FixedPrice/Edit/5
        public ActionResult Edit(int id)
        {
            try
            {
                var fixedPrice = db.FixedPrices.Find(id);
                if (fixedPrice == null)
                {
                    if (Request.IsAjaxRequest())
                    {
                        Response.StatusCode = 404;
                        return Json(new { error = "Chi phí cố định không tồn tại" }, JsonRequestBehavior.AllowGet);
                    }
                    return HttpNotFound();
                }

                if (Request.IsAjaxRequest())
                {
                    return Json(new
                    {
                        Id = fixedPrice.Id,
                        Type = fixedPrice.Type.ToString(),
                        Price = fixedPrice.Price
                    }, JsonRequestBehavior.AllowGet);
                }
                return View(fixedPrice);
            }
            catch (Exception ex)
            {
                if (Request.IsAjaxRequest())
                {
                    Response.StatusCode = 500;
                    return Json(new { error = $"Lỗi server: {ex.Message}" }, JsonRequestBehavior.AllowGet);
                }
                TempData["Error"] = $"Lỗi khi lấy dữ liệu chỉnh sửa: {ex.Message}";
                return RedirectToAction("Index");
            }
        }

        // POST: Manager/FixedPrice/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(FixedPrice fixedPrice, int page = 1, string sort = "")
        {
            try
            {
                if (fixedPrice.Price < 0)
                {
                    ModelState.AddModelError("Price", "Giá không được âm.");
                }

                if (ModelState.IsValid)
                {
                    var existingFixedPrice = db.FixedPrices.Find(fixedPrice.Id);
                    if (existingFixedPrice == null)
                    {
                        if (Request.IsAjaxRequest())
                        {
                            Response.StatusCode = 404;
                            return Json(new { success = false, message = "Chi phí cố định không tồn tại" });
                        }
                        return HttpNotFound();
                    }

                    existingFixedPrice.Type = fixedPrice.Type;
                    existingFixedPrice.Price = fixedPrice.Price;
                    db.SaveChanges();
                    TempData["Message"] = "Cập nhật chi phí cố định thành công!";

                    if (Request.IsAjaxRequest())
                    {
                        return Json(new { success = true, message = "Cập nhật chi phí cố định thành công!" });
                    }
                    return RedirectToAction("Index", new { page, sort });
                }

                if (Request.IsAjaxRequest())
                {
                    Response.StatusCode = 400;
                    return Json(new { success = false, message = "Dữ liệu không hợp lệ: " + string.Join("; ", ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage)) });
                }
                return View(fixedPrice);
            }
            catch (Exception ex)
            {
                if (Request.IsAjaxRequest())
                {
                    Response.StatusCode = 500;
                    return Json(new { success = false, message = $"Lỗi server: {ex.Message}" });
                }
                TempData["Error"] = $"Lỗi khi cập nhật chi phí cố định: {ex.Message}";
                return View(fixedPrice);
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}