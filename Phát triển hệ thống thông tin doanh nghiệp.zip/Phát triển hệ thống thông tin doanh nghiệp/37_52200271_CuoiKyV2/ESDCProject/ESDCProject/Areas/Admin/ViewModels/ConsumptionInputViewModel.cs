﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ESDCProject.Areas.Admin.ViewModels
{
    public class ConsumptionInputViewModel
    {
        public int RoomId { get; set; }
        public string RoomNumber { get; set; }
        public int ElectricityQuantity { get; set; }
        public int WaterQuantity { get; set; }
    }
}