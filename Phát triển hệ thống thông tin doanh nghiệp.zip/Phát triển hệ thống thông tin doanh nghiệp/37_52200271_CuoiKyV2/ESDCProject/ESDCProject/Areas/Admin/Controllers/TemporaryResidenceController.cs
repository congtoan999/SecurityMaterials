﻿using ESDCProject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Aspose.Words;
using Aspose.Words.Saving;
using System.Data.Entity;
using System.IO;
using System.Data.Entity.Infrastructure;

namespace ESDCProject.Areas.Admin.Controllers
{
    public class TemporaryResidenceController : Controller
    {
        private ESDCProjectDbContext db = new ESDCProjectDbContext();

        // GET: Admin/TemporaryResidence
        public ActionResult Index(int page = 1, int pageSize = 10, string sort = "", string search = "")
        {
            ViewBag.SelectedSort = sort;
            ViewBag.Search = search;

            var temporaryResidences = db.TemporaryResidences
                .Include(tr => tr.User)
                .Include(tr => tr.User.Contracts)
                .Include(tr => tr.User.Contracts.Select(c => c.Room))
                .AsQueryable();

            // Apply searching
            if (!string.IsNullOrEmpty(search))
            {
                search = search.ToLower();

                // UserID have contract with RoomNumber
                var matchingUserIds = db.Users
                    .Where(u => u.Contracts.Any(c =>
                        !c.IsTerminated &&
                        c.EndDate >= DateTime.Now &&
                        c.Room != null &&
                        c.Room.RoomNumber != null &&
                        c.Room.RoomNumber.ToLower().Contains(search)))
                    .Select(u => u.Id)
                    .ToList();

                temporaryResidences = temporaryResidences.Where(tr =>
                    (tr.FullName != null && tr.FullName.ToLower().Contains(search)) ||
                    (tr.IdentityNumber != null && tr.IdentityNumber.ToLower().Contains(search)) ||
                    (tr.User != null && tr.User.Name != null && tr.User.Name.ToLower().Contains(search)) ||
                    (tr.User != null && matchingUserIds.Contains(tr.UserId))
                );
            }

            var temporaryResidencesList = temporaryResidences.ToList();

            // Apply sorting
            IEnumerable<TemporaryResidence> orderedTemporaryResidences;
            switch (sort)
            {
                case "room_asc":
                    orderedTemporaryResidences = temporaryResidencesList
                        .OrderBy(tr =>
                            tr.User != null && tr.User.Contracts != null
                            ? tr.User.Contracts
                                .Where(c => !c.IsTerminated && c.EndDate >= DateTime.Now)
                                .OrderBy(c => c.EndDate)
                                .Select(c => c.Room != null ? c.Room.RoomNumber : null)
                                .FirstOrDefault() ?? "N/A"
                            : "N/A");
                    break;
                case "room_desc":
                    orderedTemporaryResidences = temporaryResidencesList
                        .OrderByDescending(tr =>
                            tr.User != null && tr.User.Contracts != null
                            ? tr.User.Contracts
                                .Where(c => !c.IsTerminated && c.EndDate >= DateTime.Now)
                                .OrderBy(c => c.EndDate)
                                .Select(c => c.Room != null ? c.Room.RoomNumber : null)
                                .FirstOrDefault() ?? "N/A"
                            : "N/A");
                    break;
                case "name_asc":
                    orderedTemporaryResidences = temporaryResidencesList.OrderBy(tr => tr.FullName);
                    break;
                case "name_desc":
                    orderedTemporaryResidences = temporaryResidencesList.OrderByDescending(tr => tr.FullName);
                    break;
                case "identity_asc":
                    orderedTemporaryResidences = temporaryResidencesList.OrderBy(tr => tr.IdentityNumber);
                    break;
                case "identity_desc":
                    orderedTemporaryResidences = temporaryResidencesList.OrderByDescending(tr => tr.IdentityNumber);
                    break;
                case "status_0":
                    orderedTemporaryResidences = temporaryResidencesList
                        .Where(tr => tr.Status == 0)
                        .OrderBy(tr => tr.FullName);
                    break;
                case "status_1":
                    orderedTemporaryResidences = temporaryResidencesList
                        .Where(tr => tr.Status == 1)
                        .OrderBy(tr => tr.FullName);
                    break;
                default:
                    orderedTemporaryResidences = temporaryResidencesList
                        .OrderBy(tr =>
                            tr.User != null && tr.User.Contracts != null
                            ? tr.User.Contracts
                                .Where(c => !c.IsTerminated && c.EndDate >= DateTime.Now)
                                .OrderBy(c => c.EndDate)
                                .Select(c => c.Room != null ? c.Room.RoomNumber : null)
                                .FirstOrDefault() ?? "N/A"
                            : "N/A");
                    break;
            }

            // Apply pagination
            int totalItems = orderedTemporaryResidences.Count();
            var pagedTemporaryResidences = orderedTemporaryResidences
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToList();

            ViewBag.UserId = new SelectList(db.Users, "Id", "Name");
            ViewBag.CurrentPage = page;
            ViewBag.PageSize = pageSize;
            ViewBag.TotalItems = totalItems;
            ViewBag.TotalPages = (int)Math.Ceiling((double)totalItems / pageSize);

            return View(pagedTemporaryResidences);
        }

        // GET: Admin/TemporaryResidence/Create
        public ActionResult Create()
        {
            ViewBag.UserId = new SelectList(db.Users, "Id", "Name");

            if (Request.IsAjaxRequest())
            {
                return Json(new
                {
                    UserId = ((IEnumerable<SelectListItem>)ViewBag.UserId).Select(x => new { Value = x.Value, Text = x.Text }),
                    TemporaryResidence = new TemporaryResidence
                    {
                        CurrentDate = DateTime.Now,
                        StayReason = "Thuê trọ",
                        Status = 0
                    }
                }, JsonRequestBehavior.AllowGet);
            }

            return RedirectToAction("Index");
        }

        // POST: Admin/TemporaryResidence/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(TemporaryResidence temporaryResidence)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    temporaryResidence.CreatedAt = DateTime.Now;
                    db.TemporaryResidences.Add(temporaryResidence);
                    db.SaveChanges();
                    return Json(new { success = true, message = "Tạo đăng ký tạm trú thành công!" });
                }

                Response.StatusCode = 400;
                var errors = ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage);
                return Json(new { success = false, message = "Dữ liệu không hợp lệ", errors });
            }
            catch (Exception ex)
            {
                Response.StatusCode = 500;
                return Json(new { success = false, message = "Lỗi khi tạo đăng ký: " + ex.Message });
            }
        }

        // GET: Admin/TemporaryResidence/Detail/5
        [HttpGet]
        public ActionResult Detail(int id)
        {
            try
            {
                var temporaryResidence = db.TemporaryResidences
                    .Include("User")
                    .FirstOrDefault(tr => tr.Id == id);

                if (temporaryResidence == null)
                {
                    Response.StatusCode = 404;
                    return Json(new { success = false, message = "Không tìm thấy đăng ký tạm trú" }, JsonRequestBehavior.AllowGet);
                }

                return Json(new
                {
                    success = true,
                    Id = temporaryResidence.Id,
                    UserId = temporaryResidence.UserId,
                    FullName = temporaryResidence.FullName ?? "",
                    DateOfBirth = temporaryResidence.DateOfBirth.ToString("yyyy-MM-dd"),
                    IdentityNumber = temporaryResidence.IdentityNumber ?? "",
                    IdentityIssueDate = temporaryResidence.IdentityIssueDate.ToString("yyyy-MM-dd"),
                    IdentityIssuePlace = temporaryResidence.IdentityIssuePlace ?? "",
                    PermanentAddress = temporaryResidence.PermanentAddress ?? "",
                    TemporaryAddress = temporaryResidence.TemporaryAddress ?? "",
                    NameOfLocalPolice = temporaryResidence.NameOfLocalPolice ?? "",
                    StayReason = temporaryResidence.StayReason ?? "",
                    CurrentDate = temporaryResidence.CurrentDate.ToString("yyyy-MM-dd"),
                    Status = temporaryResidence.Status,
                    SubmittedAt = temporaryResidence.SubmittedAt.HasValue ? temporaryResidence.SubmittedAt.Value.ToString("yyyy-MM-dd") : null,
                    User = temporaryResidence.User != null ? new { Name = temporaryResidence.User.Name } : null
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                Response.StatusCode = 500;
                return Json(new { success = false, message = "Server error: " + ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        // GET: Admin/TemporaryResidence/Edit/5
        public ActionResult Edit(int id)
        {
            try
            {
                var temporaryResidence = db.TemporaryResidences.Find(id);
                if (temporaryResidence == null)
                {
                    Response.StatusCode = 404;
                    return Json(new { success = false, error = "Không tìm thấy đăng ký tạm trú" }, JsonRequestBehavior.AllowGet);
                }

                var user = db.Users.Find(temporaryResidence.UserId);
                if (user == null)
                {
                    Response.StatusCode = 400;
                    return Json(new { success = false, error = "Người dùng không tồn tại" }, JsonRequestBehavior.AllowGet);
                }

                return Json(new
                {
                    success = true,
                    Id = temporaryResidence.Id,
                    UserId = temporaryResidence.UserId,
                    FullName = temporaryResidence.FullName ?? "",
                    DateOfBirth = temporaryResidence.DateOfBirth.ToString("yyyy-MM-dd"),
                    IdentityNumber = temporaryResidence.IdentityNumber ?? "",
                    IdentityIssueDate = temporaryResidence.IdentityIssueDate.ToString("yyyy-MM-dd"),
                    IdentityIssuePlace = temporaryResidence.IdentityIssuePlace ?? "",
                    PermanentAddress = temporaryResidence.PermanentAddress ?? "",
                    TemporaryAddress = temporaryResidence.TemporaryAddress ?? "",
                    NameOfLocalPolice = temporaryResidence.NameOfLocalPolice ?? "",
                    StayReason = temporaryResidence.StayReason ?? "",
                    CurrentDate = temporaryResidence.CurrentDate.ToString("yyyy-MM-dd"),
                    Status = temporaryResidence.Status,
                    SubmittedAt = temporaryResidence.SubmittedAt.HasValue ? temporaryResidence.SubmittedAt.Value.ToString("yyyy-MM-dd") : null
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                Response.StatusCode = 500;
                return Json(new { success = false, error = $"Lỗi server: {ex.Message}" }, JsonRequestBehavior.AllowGet);
            }
        }

        // POST: Admin/TemporaryResidence/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(TemporaryResidence temporaryResidence, int page = 1, string sort = "", string search = "")
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var existingTemporaryResidence = db.TemporaryResidences.Find(temporaryResidence.Id);
                    if (existingTemporaryResidence == null)
                    {
                        return Json(new { success = false, message = "Không tìm thấy đăng ký tạm trú" });
                    }

                    existingTemporaryResidence.UserId = temporaryResidence.UserId;
                    existingTemporaryResidence.FullName = temporaryResidence.FullName;
                    existingTemporaryResidence.DateOfBirth = temporaryResidence.DateOfBirth;
                    existingTemporaryResidence.IdentityNumber = temporaryResidence.IdentityNumber;
                    existingTemporaryResidence.IdentityIssueDate = temporaryResidence.IdentityIssueDate;
                    existingTemporaryResidence.IdentityIssuePlace = temporaryResidence.IdentityIssuePlace;
                    existingTemporaryResidence.PermanentAddress = temporaryResidence.PermanentAddress;
                    existingTemporaryResidence.TemporaryAddress = temporaryResidence.TemporaryAddress;
                    existingTemporaryResidence.NameOfLocalPolice = temporaryResidence.NameOfLocalPolice;
                    existingTemporaryResidence.StayReason = temporaryResidence.StayReason;
                    existingTemporaryResidence.CurrentDate = temporaryResidence.CurrentDate;
                    existingTemporaryResidence.Status = temporaryResidence.Status;
                    existingTemporaryResidence.SubmittedAt = temporaryResidence.SubmittedAt;

                    db.SaveChanges();
                    return Json(new { success = true, message = "Cập nhật đăng ký tạm trú thành công!" });
                }

                Response.StatusCode = 400;
                var errors = ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage);
                return Json(new { success = false, message = "Dữ liệu không hợp lệ", errors });
            }
            catch (Exception ex)
            {
                Response.StatusCode = 500;
                return Json(new { success = false, message = "Lỗi khi cập nhật đăng ký: " + ex.Message });
            }
        }

        // GET: Admin/TemporaryResidence/Delete/5
        public ActionResult Delete(int id)
        {
            TemporaryResidence temporaryResidence = db.TemporaryResidences.Find(id);
            if (temporaryResidence == null)
            {
                return HttpNotFound();
            }
            return View(temporaryResidence);
        }

        // POST: Admin/TemporaryResidence/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id, int page = 1, string sort = "", string search = "")
        {
            try
            {
                var temporaryResidence = db.TemporaryResidences.Find(id);
                if (temporaryResidence == null)
                {
                    return Json(new { success = false, message = "Đăng ký tạm trú không tồn tại" });
                }

                db.TemporaryResidences.Remove(temporaryResidence);
                db.SaveChanges();

                return Json(new { success = true, message = "Xóa đăng ký tạm trú thành công!" });
            }
            catch (Exception ex)
            {
                Response.StatusCode = 500;
                return Json(new { success = false, message = "Lỗi khi xóa đăng ký: " + ex.Message });
            }
        }

        // GET: Admin/TemporaryResidence/Submit/5
        public ActionResult Submit(int id)
        {
            TemporaryResidence temporaryResidence = db.TemporaryResidences.Find(id);
            if (temporaryResidence == null)
            {
                return HttpNotFound();
            }
            return View(temporaryResidence);
        }

        public ActionResult DownloadTemporaryResidence(int id)
        {
            try
            {
                // Fetch the temporary residence record for the primary tenant
                var temporaryResidence = db.TemporaryResidences
                    .Include(tr => tr.User)
                    .FirstOrDefault(tr => tr.Id == id);

                if (temporaryResidence == null)
                {
                    return HttpNotFound("Không tìm thấy đăng ký tạm trú");
                }

                // Fetch the admin (optional, but keeping it as per your code)
                var admin = db.Users.FirstOrDefault(u => u.Role == 0);
                if (admin == null)
                {
                    return new HttpStatusCodeResult(500, "Không tìm thấy thông tin Admin");
                }

                // Fetch the primary tenant's user record to get the RoomId
                var primaryUser = db.Users
                    .FirstOrDefault(u => u.Id == temporaryResidence.UserId);

                if (primaryUser == null || !primaryUser.RoomId.HasValue)
                {
                    return new HttpStatusCodeResult(500, "Không tìm thấy thông tin người dùng hoặc phòng của người đại diện.");
                }

                // Fetch the room details for the room number
                var room = db.Rooms.FirstOrDefault(r => r.Id == primaryUser.RoomId.Value);
                if (room == null)
                {
                    return new HttpStatusCodeResult(500, "Không tìm thấy thông tin phòng.");
                }

                // Fetch all users in the same room (excluding the primary tenant)
                var otherUsers = db.Users
                    .Where(u => u.Id != primaryUser.Id && // Exclude the primary tenant
                                u.RoomId == primaryUser.RoomId) // Same room
                    .ToList();

                // Extract the UserIds from otherUsers into a list of integers
                var otherUserIds = otherUsers.Select(u => u.Id).ToList();

                // Fetch temporary residence records for all users in the same room (including the primary tenant)
                // Group by UserId and select the most recent record for each user
                var allTemporaryResidences = db.TemporaryResidences
                    .Include(tr => tr.User)
                    .Where(tr => tr.UserId == primaryUser.Id || // Include the primary tenant
                                 otherUserIds.Contains(tr.UserId)) // Include other users in the same room
                    .GroupBy(tr => tr.UserId) // Group by UserId to handle duplicates
                    .Select(g => g.OrderByDescending(tr => tr.SubmittedAt ?? tr.CreatedAt) // Order by SubmittedAt (or CreatedAt if SubmittedAt is null) to get the most recent record
                                  .FirstOrDefault()) // Take the most recent record for each UserId
                    .ToDictionary(tr => tr.UserId, tr => tr); // Create a dictionary for quick lookup

                // Create the document
                var doc = new Document();
                var builder = new DocumentBuilder(doc);

                // Set font and alignment for the header
                builder.Font.Name = "Times New Roman";
                builder.Font.Size = 13;
                builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;

                // Document header
                builder.Font.Bold = true;
                builder.Writeln("CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM");
                builder.Writeln("Độc lập – Tự do – Hạnh phúc");
                builder.Writeln("-------------------");
                builder.Font.Size = 14;
                builder.Writeln("ĐƠN XIN XÁC NHẬN TẠM TRÚ");
                builder.Font.Bold = false;
                builder.Font.Size = 13;
                builder.Writeln();

                // Main content
                builder.ParagraphFormat.Alignment = ParagraphAlignment.Left;
                builder.Writeln($"Kính gửi: Công an Quận 7");
                builder.Writeln($"Tôi tên là: {temporaryResidence.FullName}");
                builder.Writeln($"Sinh ngày: {temporaryResidence.DateOfBirth.ToString("dd/MM/yyyy")}");
                builder.Writeln($"Số CCCD: {temporaryResidence.IdentityNumber} Cấp ngày: {temporaryResidence.IdentityIssueDate.ToString("dd/MM/yyyy")}");
                builder.Writeln($"Nơi cấp: {temporaryResidence.IdentityIssuePlace}");
                builder.Writeln($"Địa chỉ thường trú: {temporaryResidence.PermanentAddress}");
                builder.Writeln($"Nay tôi làm đơn này kính mong Công an Quận 7 xác nhận cho tôi hiện đang tạm trú tại");
                builder.Writeln($"19 Đ. Nguyễn Hữu Thọ, Tân Phong, Quận 7, phòng số: {room.RoomNumber}");
                builder.Writeln();

                // Number of accompanying household members
                builder.Writeln($"Số nhân khẩu kèm theo: {otherUsers.Count}");
                builder.Writeln();

                // Table of residents
                builder.ParagraphFormat.Alignment = ParagraphAlignment.Left;
                builder.StartTable();
                builder.InsertCell();
                builder.Write("Stt");
                builder.InsertCell();
                builder.Write("Họ tên");
                builder.InsertCell();
                builder.Write("Năm sinh");
                builder.InsertCell();
                builder.Write("Số CMND");
                builder.InsertCell();
                builder.Write("Nơi thường trú");
                builder.InsertCell();
                builder.Write("Nghề nghiệp");
                builder.EndRow();

                // Add the primary tenant (Stt = 1)
                builder.InsertCell();
                builder.Write("1");
                builder.InsertCell();
                builder.Write(temporaryResidence.FullName ?? "N/A");
                builder.InsertCell();
                builder.Write(temporaryResidence.DateOfBirth.ToString("dd/MM/yyyy"));
                builder.InsertCell();
                builder.Write(temporaryResidence.IdentityNumber ?? "N/A");
                builder.InsertCell();
                builder.Write(temporaryResidence.PermanentAddress ?? "N/A");
                builder.InsertCell();
                builder.Write("Thuê trọ");
                builder.EndRow();

                // Add other users in the same room (Stt = 2, 3, ...)
                for (int i = 0; i < otherUsers.Count; i++)
                {
                    var user = otherUsers[i];
                    // Check if the user has a temporary residence record
                    if (allTemporaryResidences.TryGetValue(user.Id, out var tempResidence))
                    {
                        // If the user has a temporary residence record, use its details
                        builder.InsertCell();
                        builder.Write((i + 2).ToString()); // Sequential number starting from 2
                        builder.InsertCell();
                        builder.Write(tempResidence.FullName ?? "N/A");
                        builder.InsertCell();
                        builder.Write(tempResidence.DateOfBirth.ToString("dd/MM/yyyy"));
                        builder.InsertCell();
                        builder.Write(tempResidence.IdentityNumber ?? "N/A");
                        builder.InsertCell();
                        builder.Write(tempResidence.PermanentAddress ?? "N/A");
                        builder.InsertCell();
                        builder.Write("Thuê trọ");
                    }
                    else
                    {
                        // If the user does not have a temporary residence record, use basic info from Users
                        builder.InsertCell();
                        builder.Write((i + 2).ToString()); // Sequential number starting from 2
                        builder.InsertCell();
                        builder.Write(user.Name ?? "N/A");
                        builder.InsertCell();
                        builder.Write(user.DateOfBirth.ToString("dd/MM/yyyy")); // DateOfBirth not available
                        builder.InsertCell();
                        builder.Write(user.IdentityNumber ?? "N/A"); // IdentityNumber not available
                        builder.InsertCell();
                        builder.Write(user.Address ?? "N/A"); // PermanentAddress not available
                        builder.InsertCell();
                        builder.Write("Thuê trọ");
                    }
                    builder.EndRow();
                }

                builder.EndTable();
                builder.Writeln();

                // Footer content
                builder.Writeln($"Rất mong được sự chấp thuận của công an địa phương. Tôi cam đoan số người trọ là đúng sự thật.");
                builder.Writeln($"Tp. HCM, ngày {DateTime.Now.Day} tháng {DateTime.Now.Month} năm {DateTime.Now.Year}");
                builder.Writeln();

                builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;
                builder.Writeln($"XÁC NHẬN CỦA CÔNG AN Q7\t\t\t\t\t\t\t\tNgày {DateTime.Now.Day} tháng {DateTime.Now.Month} năm {DateTime.Now.Year}");
                builder.Writeln("\t\t\t\t\t\t\t\t\t\t\t\t\tKính đơn");

                // Save the document as a PDF
                using (MemoryStream stream = new MemoryStream())
                {
                    PdfSaveOptions saveOptions = new PdfSaveOptions();
                    doc.Save(stream, saveOptions);

                    stream.Position = 0;
                    return File(stream.ToArray(), "application/pdf", $"DonXinTamTru_{temporaryResidence.Id}.pdf");
                }
            }
            catch (Exception ex)
            {
                return new HttpStatusCodeResult(500, "Lỗi khi tạo file PDF: " + ex.Message);
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}