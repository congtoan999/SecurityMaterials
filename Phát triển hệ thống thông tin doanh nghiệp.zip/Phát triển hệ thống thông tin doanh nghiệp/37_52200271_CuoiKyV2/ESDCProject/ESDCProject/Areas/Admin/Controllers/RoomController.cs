﻿using ESDCProject.Models;
using System;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Web.Mvc;

namespace ESDCProject.Areas.Admin.Controllers
{
    public class RoomController : Controller
    {
        private ESDCProjectDbContext db = new ESDCProjectDbContext();

        // GET: Admin/Room
        public ActionResult Index(int page = 1, int pageSize = 10, string sort = "", string search = "", string statusFilter = "")
        {
            ViewBag.SelectedSort = sort;
            ViewBag.Search = search;
            ViewBag.StatusFilter = statusFilter;

            var rooms = db.Rooms.AsQueryable();

            // Apply searching
            if (!string.IsNullOrEmpty(search))
            {
                search = search.ToLower();
                rooms = rooms.Where(r =>
                    r.RoomNumber.ToLower().Contains(search) ||
                    (r.Area != null && r.Area.ToLower().Contains(search)) ||
                    (r.Description != null && r.Description.ToLower().Contains(search))
                );
            }

            // Apply status filter
            if (!string.IsNullOrEmpty(statusFilter))
            {
                if (statusFilter == "available")
                {
                    rooms = rooms.Where(r => r.Status == 0);
                }
                else if (statusFilter == "occupied")
                {
                    rooms = rooms.Where(r => r.Status == 1);
                }
            }

            // Apply sorting
            switch (sort)
            {
                case "room_asc":
                    rooms = rooms.OrderBy(r => r.RoomNumber);
                    break;
                case "room_desc":
                    rooms = rooms.OrderByDescending(r => r.RoomNumber);
                    break;
                case "price_asc":
                    rooms = rooms.OrderBy(r => r.BasePrice);
                    break;
                case "price_desc":
                    rooms = rooms.OrderByDescending(r => r.BasePrice);
                    break;
                case "max_occupants_asc":
                    rooms = rooms.OrderBy(r => r.MaxOccupants);
                    break;
                case "max_occupants_desc":
                    rooms = rooms.OrderByDescending(r => r.MaxOccupants);
                    break;
                case "area_asc":
                    rooms = rooms.OrderBy(r => r.Area);
                    break;
                case "area_desc":
                    rooms = rooms.OrderByDescending(r => r.Area);
                    break;
                case "status_asc":
                    rooms = rooms.OrderBy(r => r.Status);
                    break;
                case "status_desc":
                    rooms = rooms.OrderByDescending(r => r.Status);
                    break;
                default:
                    rooms = rooms.OrderBy(r => r.RoomNumber);
                    break;
            }

            // Apply pagination
            int totalItems = rooms.Count();
            var pagedRooms = rooms
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToList();

            ViewBag.CurrentPage = page;
            ViewBag.PageSize = pageSize;
            ViewBag.TotalItems = totalItems;
            ViewBag.TotalPages = (int)Math.Ceiling((double)totalItems / pageSize);

            return View(pagedRooms);
        }

        // GET: Admin/Room/Details/5
        public ActionResult Details(int id)
        {
            if (id <= 0)
            {
                return HttpNotFound();
            }

            Room room = db.Rooms.Find(id);
            if (room == null)
            {
                return HttpNotFound();
            }
            return View(room);
        }

        // GET: Admin/Room/Create
        public ActionResult Create()
        {
            Room room = new Room
            {
                BasePrice = 1000000,
                MaxOccupants = 1,
                Status = 0
            };
            return View(room);
        }

        // POST: Admin/Room/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Room room)
        {
            if (ModelState.IsValid)
            {
                db.Rooms.Add(room);
                db.SaveChanges();
                TempData["Message"] = "Thêm phòng thành công!";
                return RedirectToAction("Index");
            }
            return View(room);
        }

        // GET: Admin/Room/Detail/5 (for modal)
        public ActionResult Detail(int id)
        {
            try
            {
                if (id <= 0)
                {
                    Response.StatusCode = 400;
                    return Json(new { error = "ID phòng không hợp lệ" }, JsonRequestBehavior.AllowGet);
                }

                var room = db.Rooms.FirstOrDefault(r => r.Id == id);
                if (room == null)
                {
                    Response.StatusCode = 404;
                    return Json(new { error = "Không tìm thấy phòng" }, JsonRequestBehavior.AllowGet);
                }

                if (Request.Headers["X-Requested-With"] == "XMLHttpRequest")
                {
                    return Json(new
                    {
                        Id = room.Id,
                        RoomNumber = room.RoomNumber ?? "",
                        Area = room.Area ?? "",
                        BasePrice = room.BasePrice,
                        MaxOccupants = room.MaxOccupants,
                        Description = room.Description ?? "",
                        Status = room.Status
                    }, JsonRequestBehavior.AllowGet);
                }

                return View(room);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Lỗi khi lấy chi tiết phòng ID {id}: {ex.Message}\nStackTrace: {ex.StackTrace}");
                Response.StatusCode = 500;
                return Json(new { error = "Lỗi máy chủ: " + ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        // GET: Admin/Room/Edit/5
        public ActionResult Edit(int id)
        {
            try
            {
                if (id <= 0)
                {
                    Response.StatusCode = 400;
                    return Json(new { error = "ID phòng không hợp lệ" }, JsonRequestBehavior.AllowGet);
                }

                var room = db.Rooms.Find(id);
                if (room == null)
                {
                    Response.StatusCode = 404;
                    return Json(new { error = "Không tìm thấy phòng" }, JsonRequestBehavior.AllowGet);
                }

                return Json(new
                {
                    Id = room.Id,
                    RoomNumber = room.RoomNumber ?? "",
                    Area = room.Area ?? "",
                    BasePrice = room.BasePrice,
                    MaxOccupants = room.MaxOccupants,
                    Description = room.Description ?? "",
                    Status = room.Status
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Lỗi khi lấy dữ liệu chỉnh sửa phòng ID {id}: {ex.Message}\nStackTrace: {ex.StackTrace}");
                Response.StatusCode = 500;
                return Json(new { error = "Lỗi máy chủ: " + ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        // POST: Admin/Room/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Room room, int page = 1, string sort = "", string search = "", string statusFilter = "")
        {
            try
            {
                if (room.Id <= 0)
                {
                    if (Request.IsAjaxRequest())
                    {
                        Response.StatusCode = 400;
                        return Json(new { success = false, message = "ID phòng không hợp lệ" });
                    }
                    return HttpNotFound();
                }

                if (ModelState.IsValid)
                {
                    var existingRoom = db.Rooms.Find(room.Id);
                    if (existingRoom == null)
                    {
                        if (Request.IsAjaxRequest())
                        {
                            Response.StatusCode = 404;
                            return Json(new { success = false, message = "Không tìm thấy phòng" });
                        }
                        return HttpNotFound();
                    }

                    existingRoom.RoomNumber = room.RoomNumber;
                    existingRoom.Area = room.Area;
                    existingRoom.BasePrice = room.BasePrice;
                    existingRoom.MaxOccupants = room.MaxOccupants;
                    existingRoom.Description = room.Description;
                    existingRoom.Status = room.Status;

                    db.SaveChanges();
                    TempData["Message"] = "Cập nhật phòng thành công!";

                    if (Request.IsAjaxRequest())
                    {
                        return Json(new { success = true });
                    }
                    return RedirectToAction("Index", "Room", new { area = "Admin", page, sort, search, statusFilter });
                }

                if (Request.IsAjaxRequest())
                {
                    Response.StatusCode = 400;
                    return Json(new { success = false, message = "Dữ liệu không hợp lệ" });
                }

                return View(room);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Lỗi khi cập nhật phòng ID {room.Id}: {ex.Message}\nStackTrace: {ex.StackTrace}");
                if (Request.IsAjaxRequest())
                {
                    Response.StatusCode = 500;
                    return Json(new { success = false, message = "Lỗi máy chủ: " + ex.Message });
                }
                TempData["Error"] = "Lỗi khi cập nhật phòng: " + ex.Message;
                return View(room);
            }
        }

        // GET: Admin/Room/Delete/5
        public ActionResult Delete(int id)
        {
            try
            {
                if (id <= 0)
                {
                    return HttpNotFound();
                }

                Room room = db.Rooms.Find(id);
                if (room == null)
                {
                    return HttpNotFound();
                }

                if (Request.Headers["X-Requested-With"] == "XMLHttpRequest")
                {
                    return Json(new
                    {
                        Id = room.Id,
                        RoomNumber = room.RoomNumber ?? "",
                        Area = room.Area ?? "",
                        BasePrice = room.BasePrice,
                        MaxOccupants = room.MaxOccupants,
                        Description = room.Description ?? "",
                        Status = room.Status
                    }, JsonRequestBehavior.AllowGet);
                }

                return View(room);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Lỗi khi lấy dữ liệu xóa phòng ID {id}: {ex.Message}\nStackTrace: {ex.StackTrace}");
                if (Request.IsAjaxRequest())
                {
                    Response.StatusCode = 500;
                    return Json(new { error = "Lỗi máy chủ: " + ex.Message }, JsonRequestBehavior.AllowGet);
                }
                TempData["Error"] = "Lỗi khi lấy dữ liệu xóa: " + ex.Message;
                return RedirectToAction("Index");
            }
        }

        // POST: Admin/Room/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id, int page = 1, string sort = "", string search = "", string statusFilter = "")
        {
            using (var transaction = db.Database.BeginTransaction())
            {
                try
                {
                    if (id <= 0)
                    {
                        if (Request.IsAjaxRequest())
                        {
                            Response.StatusCode = 400;
                            return Json(new { success = false, message = "ID phòng không hợp lệ" });
                        }
                        return HttpNotFound();
                    }

                    Room room = db.Rooms.Find(id);
                    if (room == null)
                    {
                        if (Request.IsAjaxRequest())
                        {
                            Response.StatusCode = 404;
                            return Json(new { success = false, message = "Không tìm thấy phòng" });
                        }
                        return HttpNotFound();
                    }

                    // Kiểm tra hợp đồng hoạt động
                    var activeContracts = db.Contracts
                        .Where(c => c.RoomId == id && !c.IsTerminated && c.EndDate != null && c.EndDate >= DateTime.Now);
                    if (activeContracts.Any())
                    {
                        if (Request.IsAjaxRequest())
                        {
                            Response.StatusCode = 400;
                            return Json(new { success = false, message = "Không thể xóa phòng đang có hợp đồng hoạt động" });
                        }
                        TempData["Error"] = "Không thể xóa phòng đang có hợp đồng hoạt động";
                        return RedirectToAction("Index", new { page, sort, search, statusFilter });
                    }

                    // Xóa dữ liệu liên quan bằng SQL trực tiếp để tối ưu
                    db.Database.ExecuteSqlCommand("DELETE FROM Vehicle WHERE RoomId = {0}", id);
                    db.Database.ExecuteSqlCommand(
                        "DELETE FROM Payment WHERE BillId IN (SELECT Id FROM Bill WHERE ContractId IN (SELECT Id FROM Contract WHERE RoomId = {0}))",
                        id);
                    db.Database.ExecuteSqlCommand(
                        "DELETE FROM Bill WHERE ContractId IN (SELECT Id FROM Contract WHERE RoomId = {0})",
                        id);
                    db.Database.ExecuteSqlCommand("DELETE FROM Contract WHERE RoomId = {0}", id);

                    // Xóa phòng
                    db.Rooms.Remove(room);
                    db.SaveChanges();

                    transaction.Commit();
                    TempData["Message"] = "Xóa phòng thành công!";

                    if (Request.IsAjaxRequest())
                    {
                        return Json(new { success = true });
                    }

                    return RedirectToAction("Index", new { page, sort, search, statusFilter });
                }
                catch (DbUpdateException ex)
                {
                    transaction.Rollback();
                    var errorMessage = ex.InnerException?.Message ?? ex.Message;
                    System.Diagnostics.Debug.WriteLine($"Lỗi khi xóa phòng ID {id}: {errorMessage}\nStackTrace: {ex.StackTrace}");

                    if (Request.IsAjaxRequest())
                    {
                        Response.StatusCode = 500;
                        return Json(new { success = false, message = $"Không thể xóa phòng do có dữ liệu liên quan: {errorMessage}" });
                    }
                    TempData["Error"] = $"Lỗi khi xóa phòng: {errorMessage}";
                    return RedirectToAction("Index", new { page, sort, search, statusFilter });
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    System.Diagnostics.Debug.WriteLine($"Lỗi khi xóa phòng ID {id}: {ex.Message}\nStackTrace: {ex.StackTrace}");

                    if (Request.IsAjaxRequest())
                    {
                        Response.StatusCode = 500;
                        return Json(new { success = false, message = $"Lỗi máy chủ: {ex.Message}" });
                    }
                    TempData["Error"] = $"Lỗi khi xóa phòng: {ex.Message}";
                    return RedirectToAction("Index", new { page, sort, search, statusFilter });
                }
            }
        }

        private string GetStatusName(int statusCode)
        {
            switch (statusCode)
            {
                case 0:
                    return "Còn trống";
                case 1:
                    return "Đã thuê";
                default:
                    return "Khác";
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}