﻿using ESDCProject.Models;
using System;
using System.Linq;
using System.Web.Mvc;
using System.Data.Entity;

namespace ESDCProject.Areas.Admin.Controllers
{
    public class ContractExtensionController : Controller
    {
        private ESDCProjectDbContext db = new ESDCProjectDbContext();

        // GET: Admin/ContractExtension
        public ActionResult Index(int page = 1, int pageSize = 10, string search = "")
        {
            ViewBag.Search = search;

            var extensions = db.ContractExtensions
                .Include(ce => ce.Contract)
                .Include(ce => ce.Contract.User)
                .Include(ce => ce.Contract.Room)
                .AsQueryable();

            if (!string.IsNullOrEmpty(search))
            {
                search = search.ToLower();
                extensions = extensions.Where(ce =>
                    (ce.Contract.ContractNumber != null && ce.Contract.ContractNumber.ToLower().Contains(search)) ||
                    (ce.Contract.User != null && ce.Contract.User.Name != null && ce.Contract.User.Name.ToLower().Contains(search)) ||
                    (ce.Contract.Room != null && ce.Contract.Room.RoomNumber != null && ce.Contract.Room.RoomNumber.ToLower().Contains(search))
                );
            }

            int totalItems = extensions.Count();
            var pagedExtensions = extensions
                .OrderBy(ce => ce.IsAccepted ? 1 : 0)
                .ThenByDescending(ce => ce.Id)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToList();

            ViewBag.CurrentPage = page;
            ViewBag.PageSize = pageSize;
            ViewBag.TotalItems = totalItems;
            ViewBag.TotalPages = (int)Math.Ceiling((double)totalItems / pageSize);

            return View(pagedExtensions);
        }

        // POST: Admin/ContractExtension/Approve/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Approve(int id)
        {
            try
            {
                var extension = db.ContractExtensions
                    .Include(ce => ce.Contract)
                    .FirstOrDefault(ce => ce.Id == id);
                if (extension == null)
                {
                    return Json(new { success = false, message = "Yêu cầu gia hạn không tồn tại" });
                }

                if (extension.IsAccepted || extension.ProcessedDate != null)
                {
                    return Json(new { success = false, message = "Yêu cầu gia hạn đã được xử lý" });
                }

                var contract = extension.Contract;
                contract.EndDate = extension.NewEndDate;
                extension.IsAccepted = true;
                extension.ProcessedDate = DateTime.Now;

                db.Entry(contract).State = EntityState.Modified;
                db.Entry(extension).State = EntityState.Modified;
                db.SaveChanges();

                return Json(new { success = true, message = "Duyệt yêu cầu gia hạn thành công!" });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = "Lỗi khi duyệt yêu cầu: " + ex.Message });
            }
        }

        // POST: Admin/ContractExtension/Reject/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Reject(int id, string rejectionReason)
        {
            try
            {
                var extension = db.ContractExtensions.Find(id);
                if (extension == null)
                {
                    return Json(new { success = false, message = "Yêu cầu gia hạn không tồn tại" });
                }

                if (extension.IsAccepted || extension.ProcessedDate != null)
                {
                    return Json(new { success = false, message = "Yêu cầu gia hạn đã được xử lý" });
                }

                extension.ProcessedDate = DateTime.Now;
                extension.RejectionReason = rejectionReason;

                db.Entry(extension).State = EntityState.Modified;
                db.SaveChanges();

                return Json(new { success = true, message = "Từ chối yêu cầu gia hạn thành công!" });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = "Lỗi khi từ chối yêu cầu: " + ex.Message });
            }
        }

        // POST: Admin/ContractExtension/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id)
        {
            try
            {
                var extension = db.ContractExtensions.Find(id);
                if (extension == null)
                {
                    return Json(new { success = false, message = "Yêu cầu gia hạn không tồn tại" });
                }

                db.ContractExtensions.Remove(extension);
                db.SaveChanges();

                return Json(new { success = true, message = "Xóa yêu cầu gia hạn thành công!" });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = "Lỗi khi xóa yêu cầu: " + ex.Message });
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}