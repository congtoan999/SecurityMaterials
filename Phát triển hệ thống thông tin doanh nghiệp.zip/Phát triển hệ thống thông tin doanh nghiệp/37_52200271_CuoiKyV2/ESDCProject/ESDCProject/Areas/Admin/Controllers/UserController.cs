﻿using ESDCProject.Models;
using System;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.IO;
using System.Data.Entity;
using System.Collections.Generic;

namespace ESDCProject.Areas.Admin.Controllers
{
    public class UserController : Controller
    {
        private ESDCProjectDbContext db = new ESDCProjectDbContext();

        // GET: Admin/User
        public ActionResult Index(int page = 1, int pageSize = 10, string sort = "", string search = "")
        {
            ViewBag.SelectedSort = sort;
            ViewBag.Search = search;

            var users = db.Users.Where(u => u.Role == 2).Include(u => u.Room).AsQueryable();

            // Apply searching
            if (!string.IsNullOrEmpty(search))
            {
                search = search.ToLower();
                users = users.Where(u =>
                    (u.Name != null && u.Name.ToLower().Contains(search)) ||
                    (u.Email != null && u.Email.ToLower().Contains(search)) ||
                    (u.Phone != null && u.Phone.ToLower().Contains(search)) ||
                    (u.Room != null && u.Room.RoomNumber != null && u.Room.RoomNumber.ToLower().Contains(search))
                );
            }

            // Apply sorting
            switch (sort)
            {
                case "name_asc":
                    users = users.OrderBy(u => u.Name);
                    break;
                case "name_desc":
                    users = users.OrderByDescending(u => u.Name);
                    break;
                case "room_asc":
                    users = users.OrderBy(u => u.Room.RoomNumber);
                    break;
                case "room_desc":
                    users = users.OrderByDescending(u => u.Room.RoomNumber);
                    break;
                case "date_asc":
                    users = users.OrderBy(u => u.LastLogin);
                    break;
                case "date_desc":
                    users = users.OrderByDescending(u => u.LastLogin);
                    break;
                default:
                    users = users.OrderBy(u => u.Name);
                    break;
            }

            int totalItems = users.Count();
            var pagedUsers = users
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToList();

            ViewBag.CurrentPage = page;
            ViewBag.PageSize = pageSize;
            ViewBag.TotalItems = totalItems;
            ViewBag.TotalPages = (int)Math.Ceiling((double)totalItems / pageSize);
            ViewBag.RoomId = new SelectList(db.Rooms.OrderBy(r => r.RoomNumber), "Id", "RoomNumber");

            return View(pagedUsers);
        }

        // GET: Admin/User/Create
        public ActionResult Create()
        {
            ViewBag.RoomId = new SelectList(db.Rooms.OrderBy(r => r.RoomNumber), "Id", "RoomNumber");
            return View(new User());
        }

        // POST: Admin/User/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(User user, HttpPostedFileBase AvatarFile)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (db.Users.Any(u => u.Email == user.Email))
                    {
                        if (Request.IsAjaxRequest())
                        {
                            Response.StatusCode = 400;
                            return Json(new { success = false, message = "Email đã tồn tại!" });
                        }
                        ModelState.AddModelError("Email", "Email đã tồn tại!");
                        ViewBag.RoomId = new SelectList(db.Rooms.OrderBy(r => r.RoomNumber), "Id", "RoomNumber", user.RoomId);
                        return View(user);
                    }

                    if (db.Users.Any(u => u.Phone == user.Phone))
                    {
                        if (Request.IsAjaxRequest())
                        {
                            Response.StatusCode = 400;
                            return Json(new { success = false, message = "Số điện thoại đã tồn tại!" });
                        }
                        ModelState.AddModelError("Phone", "Số điện thoại đã tồn tại!");
                        ViewBag.RoomId = new SelectList(db.Rooms.OrderBy(r => r.RoomNumber), "Id", "RoomNumber", user.RoomId);
                        return View(user);
                    }

                    if (AvatarFile != null && AvatarFile.ContentLength > 0)
                    {
                        string[] allowedExtensions = { ".jpg", ".jpeg", ".png", ".gif" };
                        string fileExtension = Path.GetExtension(AvatarFile.FileName).ToLower();
                        if (!allowedExtensions.Contains(fileExtension))
                        {
                            if (Request.IsAjaxRequest())
                            {
                                Response.StatusCode = 400;
                                return Json(new { success = false, message = "Chỉ chấp nhận file ảnh (jpg, jpeg, png, gif)!" });
                            }
                            ModelState.AddModelError("AvatarFile", "Chỉ chấp nhận file ảnh (jpg, jpeg, png, gif)!");
                            ViewBag.RoomId = new SelectList(db.Rooms.OrderBy(r => r.RoomNumber), "Id", "RoomNumber", user.RoomId);
                            return View(user);
                        }

                        string fileName = Guid.NewGuid().ToString() + fileExtension;
                        string path = Path.Combine(Server.MapPath("~/Content/img/"), fileName);
                        AvatarFile.SaveAs(path);
                        user.Avatar = fileName;
                    }
                    else
                    {
                        user.Avatar = "default-avatar.jpg";
                    }

                    user.Role = user.Role != 0 ? user.Role : 2;

                    db.Users.Add(user);
                    db.SaveChanges();

                    if (Request.IsAjaxRequest())
                    {
                        return Json(new { success = true });
                    }

                    return RedirectToAction("Index");
                }

                if (Request.IsAjaxRequest())
                {
                    Response.StatusCode = 400;
                    return Json(new { success = false, message = "Dữ liệu không hợp lệ" });
                }

                ViewBag.RoomId = new SelectList(db.Rooms.OrderBy(r => r.RoomNumber), "Id", "RoomNumber", user.RoomId);
                return View(user);
            }
            catch (Exception ex)
            {
                if (Request.IsAjaxRequest())
                {
                    Response.StatusCode = 500;
                    return Json(new { success = false, message = ex.Message });
                }

                ModelState.AddModelError("", "Lỗi khi tạo người dùng: " + ex.Message);
                ViewBag.RoomId = new SelectList(db.Rooms.OrderBy(r => r.RoomNumber), "Id", "RoomNumber", user.RoomId);
                return View(user);
            }
        }

        // GET: Admin/User/Detail/5
        public ActionResult Detail(int id)
        {
            try
            {
                var user = db.Users.Include(u => u.Room).FirstOrDefault(u => u.Id == id);
                if (user == null)
                {
                    Response.StatusCode = 404;
                    return Json(new { error = "Người dùng không tồn tại" }, JsonRequestBehavior.AllowGet);
                }

                if (Request.Headers["X-Requested-With"] == "XMLHttpRequest")
                {
                    return Json(new
                    {
                        Id = user.Id,
                        Name = user.Name ?? "",
                        Email = user.Email ?? "",
                        Phone = user.Phone ?? "",
                        RoomId = user.RoomId,
                        RoomNumber = user.Room != null ? user.Room.RoomNumber : "Chưa thuê phòng",
                        Avatar = user.Avatar ?? "default-avatar.jpg",
                        LastLogin = user.LastLogin?.ToString("dd/MM/yyyy HH:mm") ?? "Chưa đăng nhập",
                        DebugRoomId = user.RoomId, // Added for debugging
                        DebugRoomExists = user.Room != null // Added for debugging
                    }, JsonRequestBehavior.AllowGet);
                }

                return View(user);
            }
            catch (Exception ex)
            {
                Response.StatusCode = 500;
                return Json(new { error = "Lỗi server: " + ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        // GET: Admin/User/Edit/5
        public ActionResult Edit(int id)
        {
            try
            {
                var user = db.Users.Include(u => u.Room).FirstOrDefault(u => u.Id == id);
                if (user == null)
                {
                    Response.StatusCode = 404;
                    return Json(new { error = "Người dùng không tồn tại" }, JsonRequestBehavior.AllowGet);
                }

                if (Request.Headers["X-Requested-With"] == "XMLHttpRequest")
                {
                    return Json(new
                    {
                        Id = user.Id,
                        Name = user.Name ?? "",
                        Email = user.Email ?? "",
                        Phone = user.Phone ?? "",
                        RoomId = user.RoomId,
                        RoomNumber = user.Room != null ? user.Room.RoomNumber : "Chưa thuê phòng",
                        Avatar = user.Avatar ?? "default-avatar.jpg",
                        LastLogin = user.LastLogin?.ToString("dd/MM/yyyy HH:mm") ?? "Chưa đăng nhập",
                        DebugRoomId = user.RoomId, // Added for debugging
                        DebugRoomExists = user.Room != null // Added for debugging
                    }, JsonRequestBehavior.AllowGet);
                }

                ViewBag.RoomId = new SelectList(db.Rooms.OrderBy(r => r.RoomNumber), "Id", "RoomNumber", user.RoomId);
                return View(user);
            }
            catch (Exception ex)
            {
                Response.StatusCode = 500;
                return Json(new { error = "Lỗi server: " + ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        // POST: Admin/User/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(User user, HttpPostedFileBase AvatarFile, int page = 1, string sort = "", string search = "")
        {
            try
            {
                if (user.RoomId == 0)
                {
                    user.RoomId = null;
                }

                if (string.IsNullOrEmpty(user.Password))
                {
                    ModelState.Remove("Password");
                }

                if (ModelState.IsValid)
                {
                    var existingUser = db.Users.Find(user.Id);
                    if (existingUser == null)
                    {
                        if (Request.IsAjaxRequest())
                        {
                            Response.StatusCode = 404;
                            return Json(new { success = false, message = "Người dùng không tồn tại" });
                        }
                        return HttpNotFound();
                    }

                    if (db.Users.Any(u => u.Email == user.Email && u.Id != user.Id))
                    {
                        if (Request.IsAjaxRequest())
                        {
                            Response.StatusCode = 400;
                            return Json(new { success = false, message = "Email đã tồn tại!" });
                        }
                        ModelState.AddModelError("Email", "Email đã tồn tại!");
                        ViewBag.RoomId = new SelectList(db.Rooms.OrderBy(r => r.RoomNumber), "Id", "RoomNumber", user.RoomId);
                        return View(user);
                    }

                    if (!string.IsNullOrEmpty(user.Phone) && db.Users.Any(u => u.Phone == user.Phone && u.Id != user.Id))
                    {
                        if (Request.IsAjaxRequest())
                        {
                            Response.StatusCode = 400;
                            return Json(new { success = false, message = "Số điện thoại đã tồn tại!" });
                        }
                        ModelState.AddModelError("Phone", "Số điện thoại đã tồn tại!");
                        ViewBag.RoomId = new SelectList(db.Rooms.OrderBy(r => r.RoomNumber), "Id", "RoomNumber", user.RoomId);
                        return View(user);
                    }

                    if (AvatarFile != null && AvatarFile.ContentLength > 0)
                    {
                        string[] allowedExtensions = { ".jpg", ".jpeg", ".png", ".gif" };
                        string fileExtension = Path.GetExtension(AvatarFile.FileName).ToLower();
                        if (!allowedExtensions.Contains(fileExtension))
                        {
                            if (Request.IsAjaxRequest())
                            {
                                Response.StatusCode = 400;
                                return Json(new { success = false, message = "Chỉ chấp nhận file ảnh (jpg, jpeg, png, gif)!" });
                            }
                            ModelState.AddModelError("AvatarFile", "Chỉ chấp nhận file ảnh (jpg, jpeg, png, gif)!");
                            ViewBag.RoomId = new SelectList(db.Rooms.OrderBy(r => r.RoomNumber), "Id", "RoomNumber", user.RoomId);
                            return View(user);
                        }

                        if (existingUser.Avatar != "default-avatar.jpg")
                        {
                            string oldFilePath = Path.Combine(Server.MapPath("~/Content/img/"), existingUser.Avatar);
                            if (System.IO.File.Exists(oldFilePath))
                            {
                                System.IO.File.Delete(oldFilePath);
                            }
                        }

                        string fileName = Guid.NewGuid().ToString() + fileExtension;
                        string path = Path.Combine(Server.MapPath("~/Content/img/"), fileName);
                        AvatarFile.SaveAs(path);
                        existingUser.Avatar = fileName;
                    }

                    existingUser.Name = user.Name;
                    existingUser.Email = user.Email;
                    existingUser.Phone = user.Phone;
                    existingUser.RoomId = user.RoomId;
                    if (!string.IsNullOrEmpty(user.Password))
                    {
                        existingUser.Password = user.Password;
                    }

                    db.SaveChanges();

                    if (Request.IsAjaxRequest())
                    {
                        return Json(new { success = true });
                    }
                    return RedirectToAction("Index", new { page, sort, search });
                }

                var errors = ModelState.Where(m => m.Value.Errors.Any())
                                      .ToDictionary(
                                          m => m.Key,
                                          m => m.Value.Errors.Select(e => e.ErrorMessage).ToList()
                                      );

                if (Request.IsAjaxRequest())
                {
                    Response.StatusCode = 400;
                    return Json(new
                    {
                        success = false,
                        message = "Dữ liệu không hợp lệ",
                        errors = errors
                    });
                }

                ViewBag.RoomId = new SelectList(db.Rooms.OrderBy(r => r.RoomNumber), "Id", "RoomNumber", user.RoomId);
                return View(user);
            }
            catch (Exception ex)
            {
                if (Request.IsAjaxRequest())
                {
                    Response.StatusCode = 500;
                    return Json(new { success = false, message = "Lỗi server: " + ex.Message });
                }
                ModelState.AddModelError("", "Lỗi khi cập nhật người dùng: " + ex.Message);
                ViewBag.RoomId = new SelectList(db.Rooms.OrderBy(r => r.RoomNumber), "Id", "RoomNumber", user.RoomId);
                return View(user);
            }
        }

        // GET: Admin/User/Delete/5
        public ActionResult Delete(int id)
        {
            var user = db.Users.Include(u => u.Room).FirstOrDefault(u => u.Id == id);
            if (user == null)
            {
                return HttpNotFound();
            }
            ViewBag.RoomId = new SelectList(db.Rooms.OrderBy(r => r.RoomNumber), "Id", "RoomNumber", user.RoomId);
            return View(user);
        }

        // POST: Admin/User/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id, int page = 1, string sort = "", string search = "")
        {
            try
            {
                var user = db.Users.Find(id);
                if (user == null)
                {
                    if (Request.IsAjaxRequest())
                    {
                        Response.StatusCode = 404;
                        return Json(new { success = false, message = "Người dùng không tồn tại" });
                    }
                    return HttpNotFound();
                }

                // Check for related records
                bool hasRelatedContracts = db.Contracts.Any(c => c.UserId == id);
                bool hasRelatedBills = db.Bills.Any(b => b.UserId == id);
                bool hasRelatedPayments = db.Payments.Any(p => p.UserId == id);
                bool hasRelatedRequests = db.Requests.Any(r => r.UserId == id);
                bool hasRelatedTempResidences = db.TemporaryResidences.Any(tr => tr.UserId == id);

                if (hasRelatedContracts || hasRelatedBills || hasRelatedPayments || hasRelatedRequests || hasRelatedTempResidences)
                {
                    string message = "Không thể xóa người dùng do còn ràng buộc dữ liệu với ";
                    List<string> relatedEntities = new List<string>();
                    if (hasRelatedContracts) relatedEntities.Add("hợp đồng");
                    if (hasRelatedBills) relatedEntities.Add("hóa đơn");
                    if (hasRelatedPayments) relatedEntities.Add("thanh toán");
                    if (hasRelatedRequests) relatedEntities.Add("yêu cầu");
                    if (hasRelatedTempResidences) relatedEntities.Add("tạm trú");

                    message += string.Join(", ", relatedEntities) + "!";

                    if (Request.IsAjaxRequest())
                    {
                        Response.StatusCode = 400;
                        return Json(new { success = false, message = message });
                    }

                    ModelState.AddModelError("", message);
                    return RedirectToAction("Index", new { page, sort, search });
                }

                if (!string.IsNullOrEmpty(user.Avatar) && user.Avatar != "default-avatar.jpg")
                {
                    string filePath = Path.Combine(Server.MapPath("~/Content/img/"), user.Avatar);
                    if (System.IO.File.Exists(filePath))
                    {
                        System.IO.File.Delete(filePath);
                    }
                }

                db.Users.Remove(user);
                db.SaveChanges();

                if (Request.IsAjaxRequest())
                {
                    return Json(new { success = true });
                }

                return RedirectToAction("Index", new { page, sort, search });
            }
            catch (Exception ex)
            {
                var errorMessage = ex.InnerException?.Message ?? ex.Message;
                if (Request.IsAjaxRequest())
                {
                    Response.StatusCode = 500;
                    return Json(new { success = false, message = "Lỗi khi xóa người dùng: " + errorMessage });
                }
                ModelState.AddModelError("", "Lỗi khi xóa người dùng: " + errorMessage);
                return RedirectToAction("Index", new { page, sort, search });
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}