﻿using ESDCProject.Areas.Admin.ViewModels;
using ESDCProject.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Web.Mvc;

namespace ESDCProject.Areas.Admin.Controllers
{
    public class BillController : Controller
    {
        private ESDCProjectDbContext db = new ESDCProjectDbContext();
        private static readonly string _from = "nguyenlh2004@gmail.com";
        private static readonly string _pass = "fsos zhhk zbgr yyfu";
        private const int DefaultElectricityQuantity = 50;
        private const int DefaultWaterQuantity = 10;

        // GET: Admin/Bill
        public ActionResult Index(int page = 1, int pageSize = 10, string sort = "", string search = "", string searchIsPaid = "")
        {
            ViewBag.SelectedSort = sort;
            ViewBag.Search = search;
            ViewBag.SearchIsPaid = searchIsPaid;

            var bills = db.Bills
                .Include(b => b.User)
                .Include(b => b.User.Room)
                .Include(b => b.Contract.Room)
                .AsQueryable();

            // Apply Searching
            if (!string.IsNullOrEmpty(search))
            {
                search = search.ToLower();
                bills = bills.Where(b =>
                    (b.User != null && b.User.Name.ToLower().Contains(search)) ||
                    (b.User != null && b.User.Room != null && b.User.Room.RoomNumber.ToLower().Contains(search)) ||
                    (b.Contract != null && b.Contract.Room != null && b.Contract.Room.RoomNumber.ToLower().Contains(search)) ||
                    (search.Contains("đã") && b.IsPaid) ||
                    (search.Contains("chưa") && !b.IsPaid) ||
                    (search == "true" && b.IsPaid) ||
                    (search == "false" && !b.IsPaid)
                );
            }

            // Apply Payment Status Filter
            if (!string.IsNullOrEmpty(searchIsPaid) && bool.TryParse(searchIsPaid, out bool isPaid))
            {
                bills = bills.Where(b => b.IsPaid == isPaid);
            }

            // Apply Sorting
            switch (sort)
            {
                case "user_asc":
                    bills = bills.OrderBy(b => b.User.Name);
                    break;
                case "user_desc":
                    bills = bills.OrderByDescending(b => b.User.Name);
                    break;
                case "date_asc":
                    bills = bills.OrderBy(b => b.DateOfBill);
                    break;
                case "date_desc":
                    bills = bills.OrderByDescending(b => b.DateOfBill);
                    break;
                case "ispaid_asc":
                    bills = bills.OrderBy(b => b.IsPaid);
                    break;
                case "ispaid_desc":
                    bills = bills.OrderByDescending(b => b.IsPaid);
                    break;
                default:
                    bills = bills.OrderByDescending(b => b.DateOfBill);
                    break;
            }

            int totalItems = bills.Count();
            var pagedBills = bills
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToList();

            ViewBag.UserId = new SelectList(db.Users, "Id", "Name");
            ViewBag.RoomId = new SelectList(db.Rooms, "Id", "RoomNumber");
            ViewBag.CurrentPage = page;
            ViewBag.PageSize = pageSize;
            ViewBag.TotalItems = totalItems;
            ViewBag.TotalPages = (int)Math.Ceiling((double)totalItems / pageSize);

            return View(pagedBills);
        }

        // GET: Admin/Bill/Details/5
        public ActionResult Details(int id)
        {
            try
            {
                var bill = db.Bills
                    .Include(b => b.User)
                    .Include(b => b.User.Room)
                    .Include(b => b.Contract.Room)
                    .FirstOrDefault(b => b.Id == id);
                if (bill == null)
                {
                    if (Request.IsAjaxRequest())
                    {
                        Response.StatusCode = 404;
                        return Json(new { error = "Hóa đơn không tồn tại" }, JsonRequestBehavior.AllowGet);
                    }
                    return HttpNotFound();
                }

                var roomNumber = bill.User?.Room?.RoomNumber ?? bill.Contract?.Room?.RoomNumber ?? "N/A";

                if (Request.IsAjaxRequest())
                {
                    return Json(new
                    {
                        Id = bill.Id,
                        UserId = bill.UserId,
                        UserName = bill.User?.Name ?? "N/A",
                        RoomNumber = roomNumber,
                        BillingPeriodStart = bill.BillingPeriodStart.ToString("yyyy-MM-dd"),
                        BillingPeriodEnd = bill.BillingPeriodEnd.ToString("yyyy-MM-dd"),
                        ElectricityFee = bill.ElectricityFee,
                        WaterFee = bill.WaterFee,
                        VehicleFee = bill.VehicleFee,
                        RentFee = bill.RentFee,
                        IsPaid = bill.IsPaid,
                        DateOfBill = bill.DateOfBill.ToString("yyyy-MM-dd HH:mm"),
                        Total = bill.ElectricityFee + bill.WaterFee + bill.VehicleFee + bill.RentFee
                    }, JsonRequestBehavior.AllowGet);
                }

                return View(bill);
            }
            catch (Exception ex)
            {
                if (Request.IsAjaxRequest())
                {
                    Response.StatusCode = 500;
                    return Json(new { error = $"Lỗi server: {ex.Message}" }, JsonRequestBehavior.AllowGet);
                }
                TempData["Error"] = $"Lỗi khi lấy chi tiết hóa đơn: {ex.Message}";
                return RedirectToAction("Index");
            }
        }

        // GET: Admin/Bill/Edit/5
        public ActionResult Edit(int id)
        {
            try
            {
                var bill = db.Bills
                    .Include(b => b.User)
                    .Include(b => b.User.Room)
                    .Include(b => b.Contract.Room)
                    .FirstOrDefault(b => b.Id == id);
                if (bill == null)
                {
                    if (Request.IsAjaxRequest())
                    {
                        Response.StatusCode = 404;
                        return Json(new { error = "Hóa đơn không tồn tại" }, JsonRequestBehavior.AllowGet);
                    }
                    return HttpNotFound();
                }

                var roomId = bill.User?.RoomId ?? bill.Contract?.RoomId;

                if (Request.IsAjaxRequest())
                {
                    return Json(new
                    {
                        Id = bill.Id,
                        UserId = bill.UserId,
                        RoomId = roomId,
                        BillingPeriodStart = bill.BillingPeriodStart.ToString("yyyy-MM-dd"),
                        BillingPeriodEnd = bill.BillingPeriodEnd.ToString("yyyy-MM-dd"),
                        ElectricityFee = bill.ElectricityFee,
                        WaterFee = bill.WaterFee,
                        VehicleFee = bill.VehicleFee,
                        RentFee = bill.RentFee,
                        IsPaid = bill.IsPaid,
                        DateOfBill = bill.DateOfBill.ToString("yyyy-MM-dd HH:mm")
                    }, JsonRequestBehavior.AllowGet);
                }

                ViewBag.UserId = new SelectList(db.Users, "Id", "Name", bill.UserId);
                ViewBag.RoomId = new SelectList(db.Rooms, "Id", "RoomNumber", roomId);
                return View(bill);
            }
            catch (Exception ex)
            {
                if (Request.IsAjaxRequest())
                {
                    Response.StatusCode = 500;
                    return Json(new { error = $"Lỗi server: {ex.Message}" }, JsonRequestBehavior.AllowGet);
                }
                TempData["Error"] = $"Lỗi khi lấy dữ liệu chỉnh sửa: {ex.Message}";
                return RedirectToAction("Index");
            }
        }

        // POST: Admin/Bill/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Bill bill, int? RoomId, int page = 1, string sort = "", string search = "", string searchIsPaid = "")
        {
            try
            {
                if (bill.ElectricityFee < 0 || bill.WaterFee < 0 || bill.VehicleFee < 0 || bill.RentFee < 0)
                {
                    ModelState.AddModelError("", "Các khoản phí không được âm.");
                }

                if (bill.BillingPeriodStart > bill.BillingPeriodEnd)
                {
                    ModelState.AddModelError("", "Ngày bắt đầu kỳ phải trước ngày kết thúc kỳ.");
                }

                if (ModelState.IsValid)
                {
                    var existingBill = db.Bills.Find(bill.Id);
                    if (existingBill == null)
                    {
                        if (Request.IsAjaxRequest())
                        {
                            Response.StatusCode = 404;
                            return Json(new { success = false, message = "Hóa đơn không tồn tại" });
                        }
                        return HttpNotFound();
                    }

                    existingBill.UserId = bill.UserId;
                    existingBill.BillingPeriodStart = bill.BillingPeriodStart;
                    existingBill.BillingPeriodEnd = bill.BillingPeriodEnd;
                    existingBill.ElectricityFee = bill.ElectricityFee;
                    existingBill.WaterFee = bill.WaterFee;
                    existingBill.VehicleFee = bill.VehicleFee;
                    existingBill.RentFee = bill.RentFee;
                    existingBill.IsPaid = bill.IsPaid;
                    existingBill.DateOfBill = bill.DateOfBill;

                    if (RoomId.HasValue)
                    {
                        var user = db.Users.Find(bill.UserId);
                        if (user != null)
                        {
                            user.RoomId = RoomId;
                        }
                        var contract = db.Contracts.FirstOrDefault(c => c.UserId == bill.UserId && !c.IsTerminated);
                        if (contract != null)
                        {
                            contract.RoomId = RoomId;
                        }
                    }

                    db.SaveChanges();
                    TempData["Message"] = "Cập nhật hóa đơn thành công!";

                    if (Request.IsAjaxRequest())
                    {
                        return Json(new { success = true, message = "Cập nhật hóa đơn thành công!" });
                    }
                    return RedirectToAction("Index", new { page, sort, search, searchIsPaid });
                }

                if (Request.IsAjaxRequest())
                {
                    Response.StatusCode = 400;
                    return Json(new { success = false, message = "Dữ liệu không hợp lệ: " + string.Join("; ", ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage)) });
                }

                ViewBag.UserId = new SelectList(db.Users, "Id", "Name", bill.UserId);
                ViewBag.RoomId = new SelectList(db.Rooms, "Id", "RoomNumber", RoomId);
                return View(bill);
            }
            catch (Exception ex)
            {
                if (Request.IsAjaxRequest())
                {
                    Response.StatusCode = 500;
                    return Json(new { success = false, message = $"Lỗi server: {ex.Message}" });
                }
                TempData["Error"] = $"Lỗi khi cập nhật hóa đơn: {ex.Message}";
                ViewBag.UserId = new SelectList(db.Users, "Id", "Name", bill.UserId);
                ViewBag.RoomId = new SelectList(db.Rooms, "Id", "RoomNumber", RoomId);
                return View(bill);
            }
        }

        // GET: Admin/Bill/Delete/5
        public ActionResult Delete(int id)
        {
            try
            {
                var bill = db.Bills
                    .Include(b => b.User)
                    .Include(b => b.User.Room)
                    .Include(b => b.Contract.Room)
                    .FirstOrDefault(b => b.Id == id);
                if (bill == null)
                {
                    if (Request.IsAjaxRequest())
                    {
                        Response.StatusCode = 404;
                        return Json(new { error = "Hóa đơn không tồn tại" }, JsonRequestBehavior.AllowGet);
                    }
                    return HttpNotFound();
                }

                var roomNumber = bill.User?.Room?.RoomNumber ?? bill.Contract?.Room?.RoomNumber ?? "N/A";

                if (Request.IsAjaxRequest())
                {
                    return Json(new
                    {
                        Id = bill.Id,
                        UserName = bill.User?.Name ?? "N/A",
                        RoomNumber = roomNumber,
                        BillingPeriodStart = bill.BillingPeriodStart.ToString("dd/MM/yyyy"),
                        BillingPeriodEnd = bill.BillingPeriodEnd.ToString("dd/MM/yyyy"),
                        ElectricityFee = bill.ElectricityFee,
                        WaterFee = bill.WaterFee,
                        VehicleFee = bill.VehicleFee,
                        RentFee = bill.RentFee,
                        IsPaid = bill.IsPaid,
                        DateOfBill = bill.DateOfBill.ToString("dd/MM/yyyy HH:mm"),
                        Total = bill.ElectricityFee + bill.WaterFee + bill.VehicleFee + bill.RentFee
                    }, JsonRequestBehavior.AllowGet);
                }

                return View(bill);
            }
            catch (Exception ex)
            {
                if (Request.IsAjaxRequest())
                {
                    Response.StatusCode = 500;
                    return Json(new { error = $"Lỗi server: {ex.Message}" }, JsonRequestBehavior.AllowGet);
                }
                TempData["Error"] = $"Lỗi khi lấy dữ liệu xóa: {ex.Message}";
                return RedirectToAction("Index");
            }
        }

        // POST: Admin/Bill/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id, int page = 1, string sort = "", string search = "", string searchIsPaid = "")
        {
            try
            {
                var bill = db.Bills.Find(id);
                if (bill == null)
                {
                    if (Request.IsAjaxRequest())
                    {
                        Response.StatusCode = 404;
                        return Json(new { success = false, message = "Hóa đơn không tồn tại!" });
                    }
                    TempData["Error"] = "Hóa đơn không tồn tại!";
                    return RedirectToAction("Index", new { page, sort, search, searchIsPaid });
                }

                var relatedRecords = db.Payments.Where(p => p.BillId == id);
                db.Payments.RemoveRange(relatedRecords);

                db.Bills.Remove(bill);
                db.SaveChanges();
                TempData["Message"] = "Xóa hóa đơn thành công!";

                if (Request.IsAjaxRequest())
                {
                    return Json(new { success = true, message = "Xóa hóa đơn thành công!" });
                }

                return RedirectToAction("Index", new { page, sort, search, searchIsPaid });
            }
            catch (DbUpdateException ex)
            {
                var errorMessage = ex.InnerException?.Message ?? ex.Message;
                if (Request.IsAjaxRequest())
                {
                    Response.StatusCode = 500;
                    return Json(new { success = false, message = $"Không thể xóa hóa đơn do có dữ liệu liên quan: {errorMessage}" });
                }
                TempData["Error"] = $"Không thể xóa hóa đơn do có dữ liệu liên quan: {errorMessage}";
                return RedirectToAction("Index", new { page, sort, search, searchIsPaid });
            }
            catch (Exception ex)
            {
                if (Request.IsAjaxRequest())
                {
                    Response.StatusCode = 500;
                    return Json(new { success = false, message = $"Lỗi server: {ex.Message}" });
                }
                TempData["Error"] = $"Lỗi khi xóa hóa đơn: {ex.Message}";
                return RedirectToAction("Index", new { page, sort, search, searchIsPaid });
            }
        }

        // GET: Admin/Bill/InputConsumption
        public ActionResult InputConsumption()
        {
            var now = DateTime.Now;
            var currentMonth = new DateTime(now.Year, now.Month, 1);
            var endOfMonth = currentMonth.AddMonths(1).AddDays(-1);

            var activeContracts = db.Contracts
                .Include(c => c.Room)
                .Include(c => c.User)
                .Where(c => !c.IsTerminated && c.StartDate <= now && (c.EndDate == null || c.EndDate >= now))
                .ToList();

            if (!activeContracts.Any())
            {
                TempData["Error"] = "Không có hợp đồng hoạt động nào để tạo hóa đơn.";
                return RedirectToAction("Index");
            }

            var roomsWithBills = db.Bills
                .Where(b => b.BillingPeriodStart == currentMonth && b.BillingPeriodEnd == endOfMonth)
                .Select(b => b.Contract.RoomId)
                .Distinct()
                .ToList();

            var contractsWithoutBills = activeContracts
                .Where(c => c.Room != null && c.User != null && !roomsWithBills.Contains(c.RoomId.Value))
                .ToList();

            if (!contractsWithoutBills.Any())
            {
                return View(new List<ConsumptionInputViewModel>());
            }

            var model = contractsWithoutBills
                .GroupBy(c => c.Room.Id)
                .Select(g => new ConsumptionInputViewModel
                {
                    RoomId = g.First().Room.Id,
                    RoomNumber = g.First().Room.RoomNumber ?? "N/A",
                    ElectricityQuantity = 0,
                    WaterQuantity = 0
                })
                .ToList();

            return View(model);
        }

        // POST: Admin/Bill/InputConsumption
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult InputConsumption(List<ConsumptionInputViewModel> model)
        {
            if (ModelState.IsValid)
            {
                if (model == null || !model.Any())
                {
                    ModelState.AddModelError("", "Không có dữ liệu tiêu thụ được gửi.");
                    return View(model);
                }

                if (model.Any(m => m.ElectricityQuantity < 0 || m.WaterQuantity < 0))
                {
                    ModelState.AddModelError("", "Lượng tiêu thụ không được âm.");
                    return View(model);
                }

                // Generate bills logic
                try
                {
                    var consumptionData = model;
                    if (!consumptionData.Any())
                    {
                        TempData["Error"] = "Không có dữ liệu tiêu thụ để tạo hóa đơn.";
                        return RedirectToAction("Index");
                    }

                    var now = DateTime.Now;
                    var billingPeriodStart = new DateTime(now.Year, now.Month, 1);
                    var billingPeriodEnd = billingPeriodStart.AddMonths(1).AddDays(-1);

                    var activeContracts = db.Contracts
                        .Include(c => c.User)
                        .Include(c => c.Room)
                        .Where(c => !c.IsTerminated && c.StartDate <= now && (c.EndDate == null || c.EndDate >= now))
                        .ToList();

                    int successCount = 0;
                    int failCount = 0;
                    var failedRooms = new List<string>();

                    foreach (var contract in activeContracts)
                    {
                        if (contract.User == null || contract.Room == null)
                        {
                            failedRooms.Add($"Phòng {contract.Room?.RoomNumber ?? "N/A"} (Hợp đồng {contract.Id})");
                            failCount++;
                            continue;
                        }

                        bool billExists = db.Bills.Any(b =>
                            b.UserId == contract.UserId &&
                            b.BillingPeriodStart == billingPeriodStart &&
                            b.BillingPeriodEnd == billingPeriodEnd);

                        if (billExists)
                        {
                            failedRooms.Add($"Phòng {contract.Room.RoomNumber} (Đã có hóa đơn cho kỳ này)");
                            continue;
                        }

                        var consumption = consumptionData.FirstOrDefault(c => c.RoomId == contract.RoomId);
                        var electricityQuantity = consumption?.ElectricityQuantity ?? DefaultElectricityQuantity;
                        var waterQuantity = consumption?.WaterQuantity ?? DefaultWaterQuantity;

                        var bill = new Bill
                        {
                            UserId = contract.UserId,
                            ContractId = contract.Id,
                            BillingPeriodStart = billingPeriodStart,
                            BillingPeriodEnd = billingPeriodEnd,
                            DateOfBill = now,
                            IsPaid = false,
                            ElectricityFee = CalculateElectricityFee(electricityQuantity),
                            WaterFee = CalculateWaterFee(waterQuantity),
                            VehicleFee = (int)CalculateVehicleFee(contract.UserId),
                            RentFee = contract.Price
                        };

                        db.Bills.Add(bill);
                        successCount++;
                    }

                    db.SaveChanges();
                    TempData["Message"] = $"Tạo {successCount} hóa đơn thành công. Thất bại: {failCount}.";
                    if (failCount > 0)
                    {
                        TempData["Error"] = $"Các phòng thất bại: {string.Join(", ", failedRooms)}.";
                    }
                }
                catch (Exception ex)
                {
                    TempData["Error"] = $"Lỗi khi tạo hóa đơn: {ex.Message}";
                }

                return RedirectToAction("Index");
            }

            TempData["Error"] = "Dữ liệu không hợp lệ. Vui lòng kiểm tra lại.";
            return View(model);
        }

        // POST: Admin/Bill/PaymentReminder
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult PaymentReminder()
        {
            try
            {
                var unpaidBills = db.Bills
                    .Include(b => b.User)
                    .Where(b => !b.IsPaid)
                    .ToList();

                if (!unpaidBills.Any())
                {
                    TempData["Message"] = "Không có hóa đơn nào cần nhắc nhở.";
                    return RedirectToAction("Index");
                }

                int successCount = 0;
                int failCount = 0;
                var failedEmails = new List<string>();

                foreach (var bill in unpaidBills)
                {
                    if (string.IsNullOrEmpty(bill.User?.Email))
                    {
                        failedEmails.Add($"Hóa đơn {bill.Id} (Không có email)");
                        failCount++;
                        continue;
                    }

                    string subject = $"Nhắc nhở thanh toán hóa đơn - Kỳ {bill.BillingPeriodStart:dd/MM/yyyy} đến {bill.BillingPeriodEnd:dd/MM/yyyy}";
                    string content = GenerateEmailContent(bill);
                    string result = Send(bill.User.Email, subject, content);

                    if (result == "OK")
                    {
                        successCount++;
                    }
                    else
                    {
                        failedEmails.Add($"Hóa đơn {bill.Id} ({result})");
                        failCount++;
                    }
                }

                TempData["Message"] = $"Đã gửi {successCount} email nhắc nhở thành công. Thất bại: {failCount}.";
                if (failCount > 0)
                {
                    TempData["Error"] = $"Các email thất bại: {string.Join(", ", failedEmails)}.";
                }
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                TempData["Error"] = $"Lỗi khi gửi email nhắc nhở: {ex.Message}";
                return RedirectToAction("Index");
            }
        }

        private int CalculateElectricityFee(int electricityQuantity)
        {
            try
            {
                if (electricityQuantity < 0)
                    return 50000;
                var electricityPrice = db.FixedPrices
                    .FirstOrDefault(fp => fp.Type == FixedPriceType.Electricity)?.Price ?? 3500;
                return electricityQuantity * electricityPrice;
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"[{DateTime.Now}] Error calculating electricity fee: {ex.Message}");
                return 50000;
            }
        }

        private int CalculateWaterFee(int waterQuantity)
        {
            try
            {
                if (waterQuantity < 0)
                    return 20000;
                var waterPrice = db.FixedPrices
                    .FirstOrDefault(fp => fp.Type == FixedPriceType.Water)?.Price ?? 20000;
                return waterQuantity * waterPrice;
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"[{DateTime.Now}] Error calculating water fee: {ex.Message}");
                return 20000;
            }
        }

        private decimal CalculateVehicleFee(int? userId)
        {
            try
            {
                if (!userId.HasValue)
                    return 0;

                var totalVehiclePrice = db.Vehicles
                    .Where(v => v.RoomId == db.Contracts
                        .Where(c => c.UserId == userId && !c.IsTerminated)
                        .Select(c => c.RoomId)
                        .FirstOrDefault())
                    .Sum(v => (decimal?)v.Price) ?? 0;

                return totalVehiclePrice;
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"[{DateTime.Now}] Error calculating vehicle fee for UserId {userId}: {ex.Message}");
                return 0;
            }
        }

        private string GenerateEmailContent(Bill bill)
        {
            var total = bill.ElectricityFee + bill.WaterFee + bill.VehicleFee + bill.RentFee;
            var roomNumber = bill.User?.Room?.RoomNumber ?? bill.Contract?.Room?.RoomNumber ?? "N/A";

            StringBuilder sb = new StringBuilder();
            sb.AppendLine("<html>");
            sb.AppendLine("<body style='font-family: Arial, sans-serif; line-height: 1.6;'>");
            sb.AppendLine($"<h2 style='color: #2e6c80;'>Nhắc Nhở Thanh Toán Hóa Đơn</h2>");
            sb.AppendLine($"<p>Kính gửi {bill.User?.Name ?? "Khách hàng"},</p>");
            sb.AppendLine("<p>Chúng tôi xin nhắc nhở về hóa đơn chưa thanh toán của quý khách với các thông tin sau:</p>");
            sb.AppendLine("<table style='border-collapse: collapse; width: 100%; margin: 20px 0;'>");
            sb.AppendLine("<tr style='background-color: #f2f2f2;'><th style='padding: 8px; border: 1px solid #ddd; text-align: left;'>Thông tin</th><th style='padding: 8px; border: 1px solid #ddd; text-align: left;'>Chi tiết</th></tr>");
            sb.AppendLine($"<tr><td style='padding: 8px; border: 1px solid #ddd;'>Phòng</td><td style='padding: 8px; border: 1px solid #ddd;'>{roomNumber}</td></tr>");
            sb.AppendLine($"<tr><td style='padding: 8px; border: 1px solid #ddd;'>Kỳ thanh toán</td><td style='padding: 8px; border: 1px solid #ddd;'>{bill.BillingPeriodStart:dd/MM/yyyy} - {bill.BillingPeriodEnd:dd/MM/yyyy}</td></tr>");
            sb.AppendLine($"<tr><td style='padding: 8px; border: 1px solid #ddd;'>Phí điện</td><td style='padding: 8px; border: 1px solid #ddd;'>{bill.ElectricityFee:N0} VNĐ</td></tr>");
            sb.AppendLine($"<tr><td style='padding: 8px; border: 1px solid #ddd;'>Phí nước</td><td style='padding: 8px; border: 1px solid #ddd;'>{bill.WaterFee:N0} VNĐ</td></tr>");
            sb.AppendLine($"<tr><td style='padding: 8px; border: 1px solid #ddd;'>Phí xe</td><td style='padding: 8px; border: 1px solid #ddd;'>{bill.VehicleFee:N0} VNĐ</td></tr>");
            sb.AppendLine($"<tr><td style='padding: 8px; border: 1px solid #ddd;'>Phí thuê phòng</td><td style='padding: 8px; border: 1px solid #ddd;'>{bill.RentFee:N0} VNĐ</td></tr>");
            sb.AppendLine($"<tr style='background-color: #f2f2f2;'><td style='padding: 8px; border: 1px solid #ddd;'>Tổng cộng</td><td style='padding: 8px; border: 1px solid #ddd; font-weight: bold;'>{total:N0} VNĐ</td></tr>");
            sb.AppendLine("</table>");
            sb.AppendLine("<p>Vui lòng thanh toán hóa đơn trước ngày <strong>10 ngày kể từ ngày lập hóa đơn</strong> để tránh các khoản phí phạt.</p>");
            sb.AppendLine("<p>Nếu đã thanh toán, xin vui lòng bỏ qua email này.</p>");
            sb.AppendLine("<p>Trân trọng,<br>Phòng Quản Lý Ký Túc Xá</p>");
            sb.AppendLine("</body>");
            sb.AppendLine("</html>");

            return sb.ToString();
        }

        public static string Send(string sendto, string subject, string content)
        {
            try
            {
                MailMessage mail = new MailMessage();
                SmtpClient smtpServer = new SmtpClient("smtp.gmail.com");

                mail.From = new MailAddress(_from);
                mail.To.Add(sendto);
                mail.Subject = subject;
                mail.IsBodyHtml = true;
                mail.Body = content;
                mail.Priority = MailPriority.High;

                smtpServer.Port = 587;
                smtpServer.Credentials = new System.Net.NetworkCredential(_from, _pass);
                smtpServer.EnableSsl = true;

                smtpServer.Send(mail);
                return "OK";
            }
            catch (SmtpException smtpEx)
            {
                System.Diagnostics.Debug.WriteLine($"[{DateTime.Now}] SMTP Error: {smtpEx.Message}. Status Code: {smtpEx.StatusCode}");
                return $"SMTP Error: {smtpEx.Message}";
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"[{DateTime.Now}] General Error: {ex.Message}");
                return $"General Error: {ex.Message}";
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}