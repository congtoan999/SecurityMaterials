﻿using ESDCProject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Aspose.Words;
using Aspose.Words.Saving;
using System.Data.Entity;
using System.IO;
using System.Data.Entity.Infrastructure;

namespace ESDCProject.Areas.Admin.Controllers
{
    public class ContractController : Controller
    {
        private ESDCProjectDbContext db = new ESDCProjectDbContext();

        // GET: Admin/Contract
        public ActionResult Index(int page = 1, int pageSize = 10, string sort = "", string search = "")
        {
            ViewBag.SelectedSort = sort;
            ViewBag.Search = search;

            // Update expired contracts
            var expiredContracts = db.Contracts
                .Where(c => !c.IsTerminated && c.EndDate < DateTime.Now)
                .ToList();

            foreach (var contract in expiredContracts)
            {
                var room = db.Rooms.Find(contract.RoomId);
                if (room != null)
                {
                    room.Status = 0;
                    db.Entry(room).State = EntityState.Modified;
                }
            }
            db.SaveChanges();

            var contracts = db.Contracts.Include(c => c.User).Include(c => c.Room).AsQueryable();

            // Apply searching
            if (!string.IsNullOrEmpty(search))
            {
                search = search.ToLower();
                contracts = contracts.Where(c =>
                    (c.ContractNumber != null && c.ContractNumber.ToLower().Contains(search)) ||
                    (c.User != null && c.User.Name != null && c.User.Name.ToLower().Contains(search)) ||
                    (c.Room != null && c.Room.RoomNumber != null && c.Room.RoomNumber.ToLower().Contains(search))
                );
            }

            // Apply sorting
            switch (sort)
            {
                case "number_asc":
                    contracts = contracts.OrderBy(c => c.ContractNumber);
                    break;
                case "number_desc":
                    contracts = contracts.OrderByDescending(c => c.ContractNumber);
                    break;
                case "user_asc":
                    contracts = contracts.OrderBy(c => c.User.Name);
                    break;
                case "user_desc":
                    contracts = contracts.OrderByDescending(c => c.User.Name);
                    break;
                case "room_asc":
                    contracts = contracts.OrderBy(c => c.Room.RoomNumber);
                    break;
                case "room_desc":
                    contracts = contracts.OrderByDescending(c => c.Room.RoomNumber);
                    break;
                case "price_asc":
                    contracts = contracts.OrderBy(c => c.Price);
                    break;
                case "price_desc":
                    contracts = contracts.OrderByDescending(c => c.Price);
                    break;
                case "startdate_asc":
                    contracts = contracts.OrderBy(c => c.StartDate);
                    break;
                case "startdate_desc":
                    contracts = contracts.OrderByDescending(c => c.StartDate);
                    break;
                case "enddate_asc":
                    contracts = contracts.OrderBy(c => c.EndDate);
                    break;
                case "enddate_desc":
                    contracts = contracts.OrderByDescending(c => c.EndDate);
                    break;
                case "status_active":
                    contracts = contracts.Where(c => !c.IsTerminated && c.EndDate >= DateTime.Now)
                                        .OrderBy(c => c.EndDate);
                    break;
                case "status_expired":
                    contracts = contracts.Where(c => !c.IsTerminated && c.EndDate < DateTime.Now)
                                        .OrderBy(c => c.EndDate);
                    break;
                case "status_terminated":
                    contracts = contracts.Where(c => c.IsTerminated)
                                        .OrderBy(c => c.TerminationDate ?? c.EndDate);
                    break;
                default:
                    contracts = contracts.OrderByDescending(c => c.StartDate);
                    break;
            }

            // Apply pagination
            int totalItems = contracts.Count();
            var pagedContracts = contracts
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToList();

            // Update room statuses
            var availableRooms = db.Rooms
                .Where(r => !db.Contracts.Any(c => c.RoomId == r.Id && !c.IsTerminated && c.EndDate >= DateTime.Now))
                .ToList();

            foreach (var room in db.Rooms.ToList())
            {
                bool hasActiveContract = db.Contracts.Any(c => c.RoomId == room.Id && !c.IsTerminated && c.EndDate >= DateTime.Now);
                room.Status = hasActiveContract ? 1 : 0;
                db.Entry(room).State = EntityState.Modified;
            }
            db.SaveChanges();

            ViewBag.UserId = new SelectList(db.Users, "Id", "Name");
            ViewBag.RoomId = new SelectList(availableRooms, "Id", "RoomNumber");
            ViewBag.CurrentPage = page;
            ViewBag.PageSize = pageSize;
            ViewBag.TotalItems = totalItems;
            ViewBag.TotalPages = (int)Math.Ceiling((double)totalItems / pageSize);

            return View(pagedContracts);
        }

        // GET: Admin/Contract/Create
        public ActionResult Create()
        {
            ViewBag.UserId = new SelectList(db.Users, "Id", "Name");
            ViewBag.RoomId = new SelectList(db.Rooms.Where(r => r.Status == 0), "Id", "RoomNumber");

            if (Request.IsAjaxRequest())
            {
                return Json(new
                {
                    UserId = ((IEnumerable<SelectListItem>)ViewBag.UserId).Select(x => new { Value = x.Value, Text = x.Text }),
                    RoomId = ((IEnumerable<SelectListItem>)ViewBag.RoomId).Select(x => new { Value = x.Value, Text = x.Text }),
                    Contract = new Contract
                    {
                        Price = 3000000,
                        Deposit = 3000000,
                        StartDate = DateTime.Now,
                        EndDate = DateTime.Now.AddMonths(6),
                        ContractNumber = GenerateContractNumber()
                    }
                }, JsonRequestBehavior.AllowGet);
            }

            // Nếu không phải AJAX, chuyển hướng về Index
            return RedirectToAction("Index");
        }

        // POST: Admin/Contract/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Contract contract)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrWhiteSpace(contract.ContractNumber))
                    {
                        contract.ContractNumber = GenerateContractNumber();
                    }

                    contract.IsTerminated = false;

                    // Tạo và lưu file PDF
                    byte[] pdfBytes = GenerateContractPdf(contract);

                    string contractsFolder = Server.MapPath("~/Content/Contracts/");
                    if (!Directory.Exists(contractsFolder))
                    {
                        Directory.CreateDirectory(contractsFolder);
                    }

                    string filePath = Server.MapPath($"~/Content/Contracts/{contract.ContractNumber}.pdf");
                    System.IO.File.WriteAllBytes(filePath, pdfBytes);

                    // Lưu hợp đồng vào database
                    db.Contracts.Add(contract);
                    db.SaveChanges();

                    // Cập nhật trạng thái phòng
                    var room = db.Rooms.Find(contract.RoomId);
                    if (room != null)
                    {
                        room.Status = 1;
                        db.Entry(room).State = EntityState.Modified;
                        db.SaveChanges();
                    }

                    return Json(new { success = true, message = "Tạo hợp đồng thành công!" });
                }

                Response.StatusCode = 400;
                var errors = ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage);
                return Json(new { success = false, message = "Dữ liệu không hợp lệ", errors });
            }
            catch (Exception ex)
            {
                Response.StatusCode = 500;
                return Json(new { success = false, message = "Lỗi khi tạo hợp đồng: " + ex.Message });
            }
        }
        private string GenerateContractNumber()
        {
            string prefix = "HD" + DateTime.Now.ToString("yyyyMMdd");
            string randomPart = new Random().Next(1000, 9999).ToString();

            string contractNumber = prefix + randomPart;
            while (db.Contracts.Any(c => c.ContractNumber == contractNumber))
            {
                randomPart = new Random().Next(1000, 9999).ToString();
                contractNumber = prefix + randomPart;
            }

            return contractNumber;
        }

        // GET: Admin/Contract/Detail/5
        [HttpGet]
        public ActionResult Detail(int id)
        {
            try
            {
                var contract = db.Contracts
                    .Include("User")
                    .Include("Room")
                    .FirstOrDefault(c => c.Id == id);

                if (contract == null)
                {
                    Response.StatusCode = 404;
                    return Json(new { success = false, message = "Không tìm thấy hợp đồng" }, JsonRequestBehavior.AllowGet);
                }

                return Json(new
                {
                    success = true,
                    Id = contract.Id,
                    ContractNumber = contract.ContractNumber ?? "",
                    UserId = contract.UserId,
                    RoomId = contract.RoomId,
                    Price = contract.Price,
                    Deposit = contract.Deposit,
                    StartDate = contract.StartDate.ToString("yyyy-MM-dd"),
                    EndDate = contract.EndDate.ToString("yyyy-MM-dd"),
                    IsTerminated = contract.IsTerminated,
                    TerminationDate = contract.TerminationDate.HasValue ? contract.TerminationDate.Value.ToString("yyyy-MM-dd") : null,
                    TerminationReason = contract.TerminationReason ?? "",
                    User = contract.User != null ? new { Name = contract.User.Name } : null,
                    Room = contract.Room != null ? new { RoomNumber = contract.Room.RoomNumber } : null
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                Response.StatusCode = 500;
                return Json(new { success = false, message = "Server error: " + ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        // GET: Admin/Contract/Edit/5
        public ActionResult Edit(int id)
        {
            try
            {
                var contract = db.Contracts.Find(id);
                if (contract == null)
                {
                    Response.StatusCode = 404;
                    return Json(new { success = false, error = "Không tìm thấy hợp đồng" }, JsonRequestBehavior.AllowGet);
                }

                // Kiểm tra UserId
                var user = db.Users.Find(contract.UserId);
                if (user == null)
                {
                    Response.StatusCode = 400;
                    return Json(new { success = false, error = "Người thuê không tồn tại" }, JsonRequestBehavior.AllowGet);
                }

                // Lấy danh sách phòng (chỉ lấy phòng trống hoặc phòng đang được hợp đồng sử dụng)
                var rooms = db.Rooms
                    .Where(r => r.Status == 0 || r.Id == contract.RoomId)
                    .ToList();

                var roomList = rooms.Select(r => new
                {
                    Value = r.Id,
                    Text = r.RoomNumber
                }).ToList();

                return Json(new
                {
                    success = true,
                    Id = contract.Id,
                    ContractNumber = contract.ContractNumber ?? "",
                    UserId = contract.UserId,
                    RoomId = contract.RoomId,
                    Price = contract.Price,
                    Deposit = contract.Deposit,
                    StartDate = contract.StartDate.ToString("yyyy-MM-dd"),
                    EndDate = contract.EndDate.ToString("yyyy-MM-dd"),
                    IsTerminated = contract.IsTerminated,
                    TerminationDate = contract.TerminationDate.HasValue ? contract.TerminationDate.Value.ToString("yyyy-MM-dd") : null,
                    TerminationReason = contract.TerminationReason ?? "",
                    Rooms = roomList
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                Response.StatusCode = 500;
                return Json(new { success = false, error = $"Lỗi server: {ex.Message}" }, JsonRequestBehavior.AllowGet);
            }
        }

        // POST: Admin/Contract/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Contract contract, int page = 1, string sort = "", string search = "")
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var existingContract = db.Contracts.Find(contract.Id);
                    if (existingContract == null)
                    {
                        return Json(new { success = false, message = "Không tìm thấy hợp đồng" });
                    }

                    existingContract.ContractNumber = contract.ContractNumber;
                    existingContract.UserId = contract.UserId;
                    existingContract.RoomId = contract.RoomId;
                    existingContract.Price = contract.Price;
                    existingContract.Deposit = contract.Deposit;
                    existingContract.StartDate = contract.StartDate;
                    existingContract.EndDate = contract.EndDate;
                    existingContract.IsTerminated = contract.IsTerminated;

                    if (contract.IsTerminated)
                    {
                        existingContract.TerminationDate = contract.TerminationDate ?? DateTime.Now;
                        existingContract.TerminationReason = contract.TerminationReason;
                    }
                    else
                    {
                        existingContract.TerminationDate = null;
                        existingContract.TerminationReason = null;
                    }

                    db.SaveChanges();
                    return Json(new { success = true, message = "Cập nhật hợp đồng thành công!" });
                }

                Response.StatusCode = 400;
                var errors = ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage);
                return Json(new { success = false, message = "Dữ liệu không hợp lệ", errors });
            }
            catch (Exception ex)
            {
                Response.StatusCode = 500;
                return Json(new { success = false, message = "Lỗi khi cập nhật hợp đồng: " + ex.Message });
            }
        }

        // GET: Admin/Contract/Delete/5
        public ActionResult Delete(int id)
        {
            Contract contract = db.Contracts.Find(id);
            if (contract == null)
            {
                return HttpNotFound();
            }
            return View(contract);
        }

        // POST: Admin/Contract/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id, int page = 1, string sort = "", string search = "")
        {
            try
            {
                var contract = db.Contracts.Find(id);
                if (contract == null)
                {
                    return Json(new { success = false, message = "Hợp đồng không tồn tại" });
                }

                bool hasRelatedBills = db.Bills.Any(b => b.ContractId == id);
                if (hasRelatedBills)
                {
                    return Json(new { success = false, message = "Không thể xóa hợp đồng do còn ràng buộc dữ liệu với hóa đơn!" });
                }

                db.Contracts.Remove(contract);
                db.SaveChanges();

                return Json(new { success = true, message = "Xóa hợp đồng thành công!" });
            }
            catch (Exception ex)
            {
                Response.StatusCode = 500;
                return Json(new { success = false, message = "Lỗi khi xóa hợp đồng: " + ex.Message });
            }
        }

        // GET: Admin/Contract/Terminate/5
        public ActionResult Terminate(int id)
        {
            Contract contract = db.Contracts.Find(id);
            if (contract == null)
            {
                return HttpNotFound();
            }
            return View(contract);
        }

        // POST: Admin/Contract/Terminate/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Terminate(int id, string terminationReason, int page = 1, string sort = "", string search = "")
        {
            try
            {
                Contract contract = db.Contracts.Find(id);
                if (contract == null)
                {
                    if (Request.IsAjaxRequest())
                    {
                        Response.StatusCode = 404;
                        return Json(new { success = false, message = "Không tìm thấy hợp đồng" });
                    }
                    return HttpNotFound();
                }

                contract.IsTerminated = true;
                contract.TerminationDate = DateTime.Now;
                contract.TerminationReason = terminationReason;

                var room = db.Rooms.Find(contract.RoomId);
                if (room != null)
                {
                    room.Status = 0;
                    db.Entry(room).State = EntityState.Modified;
                }

                db.Entry(contract).State = EntityState.Modified;
                db.SaveChanges();

                if (Request.IsAjaxRequest())
                {
                    return Json(new { success = true, message = "Chấm dứt hợp đồng thành công" });
                }

                return RedirectToAction("Index", "Contract", new { area = "Admin", page, sort, search });
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Lỗi chấm dứt hợp đồng: {ex.Message}");

                if (Request.IsAjaxRequest())
                {
                    Response.StatusCode = 500;
                    return Json(new { success = false, message = "Có lỗi xảy ra khi chấm dứt hợp đồng. Vui lòng thử lại." });
                }

                ModelState.AddModelError("", "Lỗi khi chấm dứt hợp đồng.");
                return RedirectToAction("Index", new { page, sort, search });
            }
        }

        // GET: Admin/Contract/DownloadContract/5
        public ActionResult DownloadContract(int id)
        {
            try
            {
                var contract = db.Contracts
                    .Include(c => c.User)
                    .Include(c => c.Room)
                    .FirstOrDefault(c => c.Id == id);

                if (contract == null)
                {
                    return HttpNotFound("Không tìm thấy hợp đồng");
                }

                var filePath = Server.MapPath($"~/Content/Contracts/{contract.ContractNumber}.pdf");
                if (!System.IO.File.Exists(filePath))
                {
                    return HttpNotFound($"File hợp đồng {contract.ContractNumber}.pdf không tồn tại.");
                }

                var fileBytes = System.IO.File.ReadAllBytes(filePath);
                var fileName = $"HopDongThuePhong_{contract.ContractNumber}.pdf";
                return File(fileBytes, "application/pdf", fileName);
            }
            catch (Exception ex)
            {
                return new HttpStatusCodeResult(500, "Lỗi khi tải hợp đồng: " + ex.Message);
            }
        }
        private byte[] GenerateContractPdf(Contract contract)
        {
            var admin = db.Users.FirstOrDefault(u => u.Role == 0);
            if (admin == null)
            {
                throw new Exception("Không tìm thấy thông tin Admin");
            }

            var user = db.Users.Find(contract.UserId);
            if (user == null)
            {
                throw new Exception("Người thuê không tồn tại");
            }

            var room = db.Rooms.Find(contract.RoomId);
            if (room == null)
            {
                throw new Exception("Phòng không tồn tại");
            }

            var electricityPrice = db.FixedPrices.FirstOrDefault(fp => fp.Type == FixedPriceType.Electricity)?.Price ?? 3200;
            var waterPrice = db.FixedPrices.FirstOrDefault(fp => fp.Type == FixedPriceType.Water)?.Price ?? 20000;

            var vehiclePrice = db.Vehicles
                .Where(v => v.RoomId == contract.RoomId)
                .Sum(v => (int?)v.Price) ?? 20000;

            var doc = new Document();
            var builder = new DocumentBuilder(doc);

            builder.Font.Name = "Times New Roman";
            builder.Font.Size = 13;
            builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;

            builder.Font.Bold = true;
            builder.Writeln("CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM");
            builder.Writeln("Độc lập – Tự do – Hạnh phúc");
            builder.Writeln("-------------------");
            builder.Font.Size = 14;
            builder.Writeln("HỢP ĐỒNG THUÊ PHÒNG TRỌ");
            builder.Font.Bold = false;
            builder.Font.Size = 13;
            builder.Writeln($"Hôm nay ngày {DateTime.Now:dd/MM/yyyy};");
            builder.Writeln();

            builder.ParagraphFormat.Alignment = ParagraphAlignment.Left;
            builder.Writeln("Chúng tôi gồm:");
            builder.Writeln("1. Đại diện bên cho thuê phòng trọ (Bên A):");
            builder.Writeln($"Ông/bà: {admin.Name}\tSinh ngày: {admin.DateOfBirth:dd/MM/yyyy}");
            builder.Writeln($"CCCD số: {admin.IdentityNumber} cấp ngày 19/02/2021 tại: Thành Phố Hồ Chí Minh");
            builder.Writeln($"Số điện thoại: {admin.Phone}");
            builder.Writeln();

            builder.Writeln("2. Bên thuê phòng trọ (Bên B):");
            builder.Writeln($"Ông/bà: {user.Name}\tSinh ngày: {user.DateOfBirth:dd/MM/yyyy}");
            builder.Writeln($"Số CCCD: {user.IdentityNumber}\tcấp ngày …../…../…… tại: ……………………...");
            builder.Writeln($"Số điện thoại: {user.Phone}");
            builder.Writeln();

            builder.Writeln("Sau khi bàn bạc trên tinh thần dân chủ, hai bên cùng có lợi, cùng thống nhất như sau:");
            builder.Writeln($"Bên A đồng ý cho bên B thuê 01 phòng số: {room.RoomNumber}");
            builder.Writeln($"Giá thuê: {contract.Price:N0} đ/tháng");
            builder.Writeln("Hình thức thanh toán: Thanh toán trực tiếp/trực tuyến.");
            builder.Writeln($"Tiền điện: {electricityPrice:N0} đ/kwh tính theo chỉ số công tơ, thanh toán vào cuối các tháng.");
            builder.Writeln($"Tiền nước: {waterPrice:N0} đ/người thanh toán vào đầu các tháng.");
            builder.Writeln($"Tiền giữ xe: {vehiclePrice:N0} đ/tháng.");
            builder.Writeln($"Tiền đặt cọc: {contract.Deposit:N0} ₫");
            builder.Writeln($"Hợp đồng có giá trị kể từ: {contract.StartDate:dd/MM/yyyy} đến {contract.EndDate:dd/MM/yyyy}");
            builder.Writeln();

            builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;
            builder.Font.Bold = true;
            builder.Writeln("TRÁCH NHIỆM CỦA CÁC BÊN");
            builder.Font.Bold = false;
            builder.ParagraphFormat.Alignment = ParagraphAlignment.Left;

            builder.Writeln("* Trách nhiệm của bên A:");
            builder.Writeln("- Tạo mọi điều kiện thuận lợi để bên B thực hiện theo hợp đồng.");
            builder.Writeln("- Cung cấp nguồn điện, nước, wifi cho bên B sử dụng.");
            builder.Writeln();

            builder.Writeln("* Trách nhiệm của bên B:");
            builder.Writeln("- Thanh toán đầy đủ các khoản tiền theo đúng thỏa thuận.");
            builder.Writeln("- Bảo quản các trang thiết bị và cơ sở vật chất của bên A trang bị cho ban đầu (làm hỏng phải sửa, mất phải đền).");
            builder.Writeln("- Không được tự ý sửa chữa, cải tạo cơ sở vật chất khi chưa được sự đồng ý của bên A.");
            builder.Writeln("- Giữ gìn vệ sinh trong và ngoài khuôn viên của phòng trọ.");
            builder.Writeln("- Bên B phải chấp hành mọi quy định của pháp luật Nhà nước và quy định của địa phương.");
            builder.Writeln("- Nếu bên B cho khách ở qua đêm thì phải báo và được sự đồng ý của chủ nhà đồng thời phải chịu trách nhiệm về các hành vi vi phạm pháp luật của khách trong thời gian ở lại.");
            builder.Writeln();

            builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;
            builder.Font.Bold = true;
            builder.Writeln("TRÁCH NHIỆM CHUNG");
            builder.Font.Bold = false;
            builder.ParagraphFormat.Alignment = ParagraphAlignment.Left;

            builder.Writeln("- Hai bên phải tạo điều kiện cho nhau thực hiện hợp đồng.");
            builder.Writeln("- Trong thời gian hợp đồng còn hiệu lực nếu bên nào vi phạm các điều khoản đã thỏa thuận thì bên còn lại có quyền đơn phương chấm dứt hợp đồng; nếu sự vi phạm hợp đồng đó gây tổn thất cho bên bị vi phạm hợp đồng thì bên vi phạm hợp đồng phải bồi thường thiệt hại.");
            builder.Writeln("- Một trong hai bên muốn chấm dứt hợp đồng trước thời hạn thì phải báo trước cho bên kia ít nhất 30 ngày và hai bên phải có sự thống nhất.");
            builder.Writeln("- Bên A phải trả lại tiền đặt cọc cho bên B.");
            builder.Writeln("- Bên nào vi phạm điều khoản chung thì phải chịu trách nhiệm trước pháp luật.");
            builder.Writeln("- Hợp đồng được lập thành 02 bản có giá trị pháp lý như nhau, mỗi bên giữ một bản.");
            builder.Writeln();

            builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;
            builder.Writeln("ĐẠI DIỆN BÊN B\t\t\t\t\t\t\t\tĐẠI DIỆN BÊN A");

            using (MemoryStream stream = new MemoryStream())
            {
                PdfSaveOptions saveOptions = new PdfSaveOptions();
                doc.Save(stream, saveOptions);
                return stream.ToArray();
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}