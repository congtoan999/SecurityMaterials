﻿using System;
using System.Linq;
using System.Web.Mvc;
using ESDCProject.Models;
using System.Collections.Generic;
using System.Data.Entity;
using ESDCProject.Areas.Tenant.ViewModel;

namespace ESDCProject.Areas.Tenant.Controllers
{
    public class TemporaryResidenceController : Controller
    {
        private ESDCProjectDbContext db = new ESDCProjectDbContext();

        // GET: Tenant/TemporaryResidence
        public ActionResult Index()
        {
            string userEmail = Session["UserEmail"]?.ToString();
            if (string.IsNullOrEmpty(userEmail))
            {
                return RedirectToAction("Tenant_Login", "Login", new { area = "" });
            }

            var user = db.Users.FirstOrDefault(u => u.Email == userEmail && u.Role == 2);
            if (user == null)
            {
                return HttpNotFound("Không tìm thấy thông tin người dùng.");
            }

            // Check if the user has a temporary residence record (either as primary or as part of a household)
            var tempResidence = db.TemporaryResidences.FirstOrDefault(tr => tr.UserId == user.Id);
            if (tempResidence != null)
            {


                return View("ViewSubmitted", tempResidence);
            }

            // Find the room associated with the logged-in Tenant via an active contract
            var activeContract = db.Contracts
                .FirstOrDefault(c => c.UserId == user.Id && !c.IsTerminated && c.EndDate >= DateTime.Now);

            if (activeContract == null)
            {
                return HttpNotFound("Không tìm thấy hợp đồng hoạt động cho người dùng này.");
            }

            var model = new TemporaryResidenceViewModel
            {
                PrimaryTenant = new TemporaryResidence
                {
                    UserId = user.Id,
                    FullName = user.Name,
                    DateOfBirth = user.DateOfBirth,
                    IdentityNumber = user.IdentityNumber,
                    IdentityIssueDate = DateTime.Now,
                    CurrentDate = DateTime.Now,
                    Status = 0,
                    TemporaryAddress = "19 Đ. Nguyễn Hữu Thọ, Tân Phong, Quận 7, Hồ Chí Minh",
                    NameOfLocalPolice = "Công an Quận 7",
                    StayReason = "Thuê trọ"
                },
                OtherTenants = new List<TemporaryResidence>(),
                RegistrationType = "Individual", // Default to Individual
                NumberOfAdditionalPeople = 0
            };

            return View(model);
        }

        // POST: Tenant/TemporaryResidence/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(TemporaryResidenceViewModel model)
        {
            string userEmail = Session["UserEmail"]?.ToString();
            var user = db.Users.FirstOrDefault(u => u.Email == userEmail && u.Role == 2);
            if (user == null)
            {
                return HttpNotFound("Không tìm thấy thông tin người dùng.");
            }

            if (!model.ConfirmCheckbox)
            {
                ModelState.AddModelError("ConfirmCheckbox", "Bạn phải chọn xác nhận thông tin để gửi đăng ký");
                return View("Index", model);
            }

            if (!ModelState.IsValid)
            {
                return View("Index", model);
            }

            if (ModelState.IsValid)
            {
                var activeContract = db.Contracts
                    .FirstOrDefault(c => c.UserId == user.Id && !c.IsTerminated && c.EndDate >= DateTime.Now);

                if (activeContract == null)
                {
                    return HttpNotFound("Không tìm thấy hợp đồng hoạt động cho người dùng này.");
                }

                user.RoomId = activeContract.RoomId;
                db.SaveChanges();

                if (model.RegistrationType == "Household" && model.OtherTenants != null && model.OtherTenants.Any())
                {
                    var existingIdentityNumbers = db.Users
                        .Select(u => u.IdentityNumber)
                        .ToList();

                    for (int i = 0; i < model.OtherTenants.Count; i++)
                    {
                        var otherTenant = model.OtherTenants[i];
                        if (string.IsNullOrEmpty(otherTenant.IdentityNumber))
                        {
                            ModelState.AddModelError($"OtherTenants[{i}].IdentityNumber", "Số CMND/CCCD không được để trống.");
                            continue;
                        }

                        if (existingIdentityNumbers.Contains(otherTenant.IdentityNumber))
                        {
                            ModelState.AddModelError($"OtherTenants[{i}].IdentityNumber", $"Số CMND/CCCD {otherTenant.IdentityNumber} đã tồn tại. Vui lòng sử dụng số khác.");
                        }
                    }

                    if (!ModelState.IsValid)
                    {
                        return View("Index", model);
                    }
                }

                var primaryResidence = model.PrimaryTenant;
                primaryResidence.UserId = user.Id;
                primaryResidence.CreatedAt = DateTime.Now;
                primaryResidence.SubmittedAt = DateTime.Now;
                primaryResidence.Status = 1;
                primaryResidence.TemporaryAddress = "19 Đ. Nguyễn Hữu Thọ, Tân Phong, Quận 7, Hồ Chí Minh";
                primaryResidence.NameOfLocalPolice = "Công an Quận 7";
                db.TemporaryResidences.Add(primaryResidence);

                if (model.RegistrationType == "Household" && model.OtherTenants != null && model.OtherTenants.Any())
                {
                    foreach (var otherTenant in model.OtherTenants)
                    {
                        var newUser = new User
                        {
                            Name = otherTenant.FullName,
                            Email = $"{otherTenant.IdentityNumber}@esdcproject.com",
                            Password = otherTenant.IdentityNumber,
                            Role = 2,
                            IsActive = false,
                            RoomId = activeContract.RoomId,
                            DateOfBirth = otherTenant.DateOfBirth,
                            IdentityNumber = otherTenant.IdentityNumber,
                            Address = otherTenant.PermanentAddress,
                            CreatedAt = DateTime.Now
                        };
                        db.Users.Add(newUser);

                        // Tạo TemporaryResidence cho thành viên khác
                        var newTempResidence = new TemporaryResidence
                        {
                            UserId = 0, // Sẽ cập nhật sau
                            FullName = otherTenant.FullName,
                            DateOfBirth = otherTenant.DateOfBirth,
                            IdentityNumber = otherTenant.IdentityNumber,
                            IdentityIssueDate = otherTenant.IdentityIssueDate != default(DateTime) ? otherTenant.IdentityIssueDate : DateTime.Now,
                            IdentityIssuePlace = otherTenant.IdentityIssuePlace,
                            PermanentAddress = otherTenant.PermanentAddress,
                            TemporaryAddress = primaryResidence.TemporaryAddress,
                            NameOfLocalPolice = primaryResidence.NameOfLocalPolice,
                            StayReason = otherTenant.StayReason ?? "Thuê trọ",
                            CurrentDate = otherTenant.CurrentDate != default(DateTime) ? otherTenant.CurrentDate : DateTime.Now,
                            CreatedAt = DateTime.Now,
                            SubmittedAt = DateTime.Now,
                            Status = 1
                        };
                        db.TemporaryResidences.Add(newTempResidence);
                    }

                    db.SaveChanges();

                    // Cập nhật UserId cho các TemporaryResidence vừa thêm
                    var oneMinuteAgo = DateTime.Now.AddMinutes(-1);
                    foreach (var tempResidence in db.TemporaryResidences.Where(tr => tr.UserId == 0 && tr.SubmittedAt >= oneMinuteAgo))
                    {
                        var matchingUser = db.Users.FirstOrDefault(u => u.IdentityNumber == tempResidence.IdentityNumber);
                        if (matchingUser != null)
                        {
                            tempResidence.UserId = matchingUser.Id;
                        }
                    }
                }

                db.SaveChanges();

                // Thông báo tùy thuộc vào loại đăng ký
                TempData["SuccessMessage"] = model.RegistrationType == "Household"
                    ? "Đăng ký tạm trú hộ thành công!"
                    : "Đăng ký tạm trú cá nhân thành công!";
                return RedirectToAction("Index");
            }

            return View("Index", model);
        }

        // GET: Tenant/TemporaryResidence/RegisterAdditional
        public ActionResult RegisterAdditional()
        {
            string userEmail = Session["UserEmail"]?.ToString();
            var user = db.Users.FirstOrDefault(u => u.Email == userEmail && u.Role == 2);
            if (user == null)
            {
                return HttpNotFound("Không tìm thấy thông tin người dùng.");
            }

            var activeContract = db.Contracts
                .FirstOrDefault(c => c.UserId == user.Id && !c.IsTerminated && c.EndDate >= DateTime.Now);
            if (activeContract == null)
            {
                return HttpNotFound("Bạn không có quyền đăng ký tạm trú cho người khác.");
            }

            var model = new TemporaryResidenceViewModel
            {
                PrimaryTenant = new TemporaryResidence(),
                OtherTenants = new List<TemporaryResidence>(),
                RegistrationType = "Household",
                NumberOfAdditionalPeople = 1
            };

            return View(model);
        }

        // POST: Tenant/TemporaryResidence/RegisterAdditional
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult RegisterAdditional(TemporaryResidenceViewModel model)
        {
            string userEmail = Session["UserEmail"]?.ToString();
            var user = db.Users.FirstOrDefault(u => u.Email == userEmail && u.Role == 2);
            if (user == null)
            {
                return HttpNotFound("Không tìm thấy thông tin người dùng.");
            }

            var activeContract = db.Contracts
                .FirstOrDefault(c => c.UserId == user.Id && !c.IsTerminated && c.EndDate >= DateTime.Now);
            if (activeContract == null)
            {
                return HttpNotFound("Bạn không có quyền đăng ký tạm trú cho người khác.");
            }

            if (!model.ConfirmCheckbox)
            {
                ModelState.AddModelError("ConfirmCheckbox", "Bạn phải chọn xác nhận thông tin để gửi đăng ký");
                return View("RegisterAdditional", model);
            }

            // Loại bỏ lỗi validation cho CreatedAt và SubmittedAt
            ModelState.Remove("OtherTenants.CreatedAt");
            ModelState.Remove("OtherTenants.SubmittedAt");
            for (int i = 0; i < (model.OtherTenants?.Count ?? 0); i++)
            {
                ModelState.Remove($"OtherTenants[{i}].CreatedAt");
                ModelState.Remove($"OtherTenants[{i}].SubmittedAt");
            }

            if (!ModelState.IsValid)
            {
                TempData["ErrorMessage"] = "Có lỗi trong thông tin đăng ký. Vui lòng kiểm tra lại.";
                return View("RegisterAdditional", model);
            }

            var primaryResidence = db.TemporaryResidences.FirstOrDefault(tr => tr.UserId == user.Id);
            if (primaryResidence == null)
            {
                return HttpNotFound("Không tìm thấy thông tin đăng ký tạm trú của người đại diện.");
            }

            if (model.OtherTenants != null && model.OtherTenants.Any())
            {
                var existingIdentityNumbers = db.Users
                    .Select(u => u.IdentityNumber)
                    .ToList();

                for (int i = 0; i < model.OtherTenants.Count; i++)
                {
                    var otherTenant = model.OtherTenants[i];
                    if (string.IsNullOrEmpty(otherTenant.IdentityNumber))
                    {
                        ModelState.AddModelError($"OtherTenants[{i}].IdentityNumber", "Số CMND/CCCD không được để trống.");
                        continue;
                    }

                    if (existingIdentityNumbers.Contains(otherTenant.IdentityNumber))
                    {
                        ModelState.AddModelError($"OtherTenants[{i}].IdentityNumber", $"Số CMND/CCCD {otherTenant.IdentityNumber} đã tồn tại. Vui lòng sử dụng số khác.");
                    }
                }

                if (!ModelState.IsValid)
                {
                    TempData["ErrorMessage"] = "Có lỗi trong thông tin đăng ký. Vui lòng kiểm tra lại.";
                    return View("RegisterAdditional", model);
                }

                foreach (var otherTenant in model.OtherTenants)
                {
                    // Tạo User mới
                    var newUser = new User
                    {
                        Name = otherTenant.FullName,
                        Email = $"{otherTenant.IdentityNumber}@esdcproject.com",
                        Password = otherTenant.IdentityNumber,
                        Role = 2,
                        IsActive = false,
                        RoomId = activeContract.RoomId,
                        DateOfBirth = otherTenant.DateOfBirth,
                        IdentityNumber = otherTenant.IdentityNumber,
                        Address = otherTenant.PermanentAddress,
                        CreatedAt = DateTime.Now
                    };
                    db.Users.Add(newUser);

                    // Tạo TemporaryResidence cho thành viên
                    var newTempResidence = new TemporaryResidence
                    {
                        UserId = 0, // Sẽ cập nhật sau khi lưu User
                        FullName = otherTenant.FullName,
                        DateOfBirth = otherTenant.DateOfBirth,
                        IdentityNumber = otherTenant.IdentityNumber,
                        IdentityIssueDate = otherTenant.IdentityIssueDate != default(DateTime) ? otherTenant.IdentityIssueDate : DateTime.Now,
                        IdentityIssuePlace = otherTenant.IdentityIssuePlace,
                        PermanentAddress = otherTenant.PermanentAddress,
                        TemporaryAddress = primaryResidence.TemporaryAddress,
                        NameOfLocalPolice = primaryResidence.NameOfLocalPolice,
                        StayReason = otherTenant.StayReason ?? "Thuê trọ",
                        CurrentDate = otherTenant.CurrentDate != default(DateTime) ? otherTenant.CurrentDate : DateTime.Now,
                        CreatedAt = DateTime.Now,
                        SubmittedAt = DateTime.Now,
                        Status = 1
                    };
                    db.TemporaryResidences.Add(newTempResidence);
                }

                try
                {
                    db.SaveChanges();
                }
                catch (Exception ex)
                {
                    TempData["ErrorMessage"] = "Có lỗi xảy ra khi lưu thông tin đăng ký. Vui lòng thử lại.";
                    return View("RegisterAdditional", model);
                }

                // Cập nhật UserId cho các TemporaryResidence vừa thêm
                var oneMinuteAgo = DateTime.Now.AddMinutes(-1);
                foreach (var tempResidence in db.TemporaryResidences.Where(tr => tr.UserId == 0 && tr.SubmittedAt >= oneMinuteAgo))
                {
                    var matchingUser = db.Users.FirstOrDefault(u => u.IdentityNumber == tempResidence.IdentityNumber);
                    if (matchingUser != null)
                    {
                        tempResidence.UserId = matchingUser.Id;
                    }
                }

                try
                {
                    db.SaveChanges();
                }
                catch (Exception ex)
                {
                    TempData["ErrorMessage"] = "Có lỗi xảy ra khi cập nhật thông tin. Vui lòng thử lại.";
                    return View("RegisterAdditional", model);
                }
            }
            else
            {
                TempData["ErrorMessage"] = "Vui lòng cung cấp thông tin ít nhất một thành viên để đăng ký.";
                return View("RegisterAdditional", model);
            }

            TempData["SuccessMessage"] = "Đăng ký tạm trú cho người khác thành công!";
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}