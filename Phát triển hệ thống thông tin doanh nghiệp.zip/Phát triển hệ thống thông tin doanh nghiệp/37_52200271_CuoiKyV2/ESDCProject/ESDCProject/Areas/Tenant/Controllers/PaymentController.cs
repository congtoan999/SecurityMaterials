﻿using ESDCProject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using QRCoder;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Web.Hosting;
using Aspose.Words.Drawing;

namespace ESDCProject.Areas.Tenant.Controllers
{
    public class PaymentController : Controller
    {
        private ESDCProjectDbContext db = new ESDCProjectDbContext();
        // GET: Tenant/Payment
        public ActionResult Index(string sort, int page = 1, int pageSize = 10)
        {
            int userId = Convert.ToInt32(Session["UserId"]);
            if (userId == 0)
            {
                return RedirectToAction("Tenant_Login", "Login", new { area = "" });
            }

            // Lấy danh sách hóa đơn của user đó
            var bills = db.Bills.Where(b => b.UserId == userId);

            // Thực hiện sắp xếp (nếu có)
            switch (sort)
            {
                case "user_asc":
                    bills = bills.OrderBy(b => b.User.Name);
                    break;
                case "user_desc":
                    bills = bills.OrderByDescending(b => b.User.Name);
                    break;
                case "status_asc":
                    bills = bills.OrderBy(b => b.Status);
                    break;
                case "status_desc":
                    bills = bills.OrderByDescending(b => b.Status);
                    break;
                case "date_asc":
                    bills = bills.OrderBy(b => b.DateOfBill);
                    break;
                case "date_desc":
                    bills = bills.OrderByDescending(b => b.DateOfBill);
                    break;
                case "ispaid_asc":
                    bills = bills.OrderBy(b => b.IsPaid);
                    break;
                case "ispaid_desc":
                    bills = bills.OrderByDescending(b => b.IsPaid);
                    break;
                default:
                    bills = bills.OrderByDescending(b => b.DateOfBill);
                    break;
            }

            // Phân trang
            int totalItems = bills.Count();
            var pagedBills = bills.Skip((page - 1) * pageSize).Take(pageSize).ToList();

            ViewBag.TotalItems = totalItems;
            ViewBag.PageSize = pageSize;
            ViewBag.CurrentPage = page;
            ViewBag.TotalPages = (int)Math.Ceiling((double)totalItems / pageSize);
            ViewBag.SelectedSort = sort;

            return View(pagedBills);
        }

        public ActionResult Details(int id)
        {
            var bill = db.Bills.Include("User").FirstOrDefault(b => b.Id == id);
            if (bill == null)
                return HttpNotFound();

            string qrUrl = $"https://img.vietqr.io/image/MB-80203051010-compact2.jpg?amount={(bill.ElectricityFee + bill.WaterFee + bill.VehicleFee + bill.RentFee)}&addInfo=HD{id}&accountName=VAN%20THI%20THANH%20HUONG";

            ViewBag.QRUrl = qrUrl;

            return PartialView("_BillDetailsPopup", bill);
        }
        [HttpPost]
        public ActionResult UploadReceipt(int billId, HttpPostedFileBase receiptFile)
        {
            var bill = db.Bills.Include("User").FirstOrDefault(b => b.Id == billId);
            if (bill == null)
            {
                return HttpNotFound();
            }

            if (receiptFile != null && receiptFile.ContentLength > 0)
            {
                var fileName = Path.GetFileName(receiptFile.FileName);
                var safeFileName = $"receipt_bill_{billId}_{DateTime.Now.Ticks}{Path.GetExtension(fileName)}";
                var savePath = Path.Combine(Server.MapPath("~/UploadedReceipts/"), safeFileName);

                Directory.CreateDirectory(Server.MapPath("~/UploadedReceipts/"));

                receiptFile.SaveAs(savePath);

                bill.ReceiptFilePath = "~/UploadedReceipts/" + safeFileName;
                db.SaveChanges();
                bill.IsPaid = true;
            }
            var amount = bill.ElectricityFee + bill.WaterFee + bill.VehicleFee + bill.RentFee;
            var addInfo = HttpUtility.UrlEncode("HD" + bill.Id);
            var accountName = HttpUtility.UrlEncode("VAN THI THANH HUONG");

            string qrUrl = $"https://img.vietqr.io/image/MB-80203051010-compact2.jpg?amount={amount}&addInfo={addInfo}&accountName={accountName}";
            ViewBag.QRUrl = qrUrl;

            return PartialView("_BillDetailsPopup", bill);
        }

    }
}