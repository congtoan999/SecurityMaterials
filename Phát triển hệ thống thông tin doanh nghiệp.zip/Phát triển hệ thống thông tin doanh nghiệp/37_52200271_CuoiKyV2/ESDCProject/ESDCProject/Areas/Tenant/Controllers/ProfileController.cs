﻿using System;
using System.Linq;
using System.Web.Mvc;
using ESDCProject.Models;

namespace ESDCProject.Areas.Tenant.Controllers
{
    public class ProfileController : Controller
    {
        private ESDCProjectDbContext db = new ESDCProjectDbContext();

        // GET: Tenant/Profile
        public ActionResult Index()
        {
            string userEmail = Session["UserEmail"]?.ToString();
            if (string.IsNullOrEmpty(userEmail))
            {
                return RedirectToAction("Tenant_Login", "Login", new { area = "" });
            }

            var user = db.Users.FirstOrDefault(u => u.Email == userEmail && u.Role == 2);
            if (user == null)
            {
                return HttpNotFound("Không tìm thấy thông tin người dùng.");
            }

            return View(user);
        }

        // POST: Tenant/Profile/Edit
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(User updatedUser)
        {
            if (ModelState.IsValid)
            {
                string userEmail = Session["UserEmail"]?.ToString();
                var user = db.Users.FirstOrDefault(u => u.Email == userEmail && u.Role == 2);
                if (user == null)
                {
                    return HttpNotFound("Không tìm thấy thông tin người dùng.");
                }
                user.Name = updatedUser.Name;
                user.Phone = updatedUser.Phone;
                user.Address = updatedUser.Address;
                user.IsFemale = updatedUser.IsFemale;
                user.DateOfBirth = updatedUser.DateOfBirth;
                user.IdentityNumber = updatedUser.IdentityNumber;

                db.SaveChanges();

                TempData["SuccessMessage"] = "Cập nhật thông tin cá nhân thành công!";
                return RedirectToAction("Index");
            }

            return View("Index", updatedUser);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}