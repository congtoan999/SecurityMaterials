﻿using ESDCProject.Models;
using System;
using System.Linq;
using System.Web.Mvc;

namespace ESDCProject.Areas.Tenant.Controllers
{
    public class RequestController : Controller
    {
        private ESDCProjectDbContext db = new ESDCProjectDbContext();

        // GET: Tenant/Request
        public ActionResult Index(int page = 1, int pageSize = 10, string sort = "")
        {
            string userEmail = Session["UserEmail"]?.ToString();
            if (string.IsNullOrEmpty(userEmail))
            {
                return RedirectToAction("Tenant_Login", "Login", new { area = "" });
            }

            var user = db.Users.FirstOrDefault(u => u.Email == userEmail && u.Role == 2);
            if (user == null)
            {
                return HttpNotFound("Không tìm thấy thông tin người dùng.");
            }

            ViewBag.SelectedSort = sort;

            var requests = db.Requests.Where(r => r.UserId == user.Id).AsQueryable();

            switch (sort)
            {
                case "status_asc":
                    requests = requests.OrderBy(r => r.Status);
                    break;
                case "status_desc":
                    requests = requests.OrderByDescending(r => r.Status);
                    break;
                case "date_asc":
                    requests = requests.OrderBy(r => r.CreatedAt);
                    break;
                case "date_desc":
                    requests = requests.OrderByDescending(r => r.CreatedAt);
                    break;
                default:
                    requests = requests.OrderByDescending(r => r.CreatedAt);
                    break;
            }

            int totalItems = requests.Count();
            var pagedRequests = requests
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToList();

            ViewBag.CurrentPage = page;
            ViewBag.PageSize = pageSize;
            ViewBag.TotalItems = totalItems;
            ViewBag.TotalPages = (int)Math.Ceiling((double)totalItems / pageSize);

            return View(pagedRequests);
        }

        // POST: Tenant/Request/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Request request)
        {
            string userEmail = Session["UserEmail"]?.ToString();
            if (string.IsNullOrEmpty(userEmail))
            {
                return Json(new { success = false, message = "Bạn cần đăng nhập để thực hiện thao tác này." });
            }

            var user = db.Users.FirstOrDefault(u => u.Email == userEmail && u.Role == 2);
            if (user == null)
            {
                return Json(new { success = false, message = "Không tìm thấy thông tin người dùng." });
            }

            if (ModelState.IsValid)
            {
                request.UserId = user.Id;
                request.Status = 0;
                request.CreatedAt = DateTime.Now;
                db.Requests.Add(request);
                db.SaveChanges();

                var html = RenderRazorViewToString("_RequestRow", request);
                return Json(new { success = true, html = html, request = request });
            }

            return Json(new { success = false, message = "Dữ liệu không hợp lệ. Vui lòng kiểm tra lại." });
        }

        // POST: Tenant/Request/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Request request)
        {
            string userEmail = Session["UserEmail"]?.ToString();
            if (string.IsNullOrEmpty(userEmail))
            {
                return Json(new { success = false, message = "Bạn cần đăng nhập để thực hiện thao tác này." });
            }

            var user = db.Users.FirstOrDefault(u => u.Email == userEmail && u.Role == 2);
            if (user == null)
            {
                return Json(new { success = false, message = "Không tìm thấy thông tin người dùng." });
            }

            var existingRequest = db.Requests.FirstOrDefault(r => r.Id == request.Id && r.UserId == user.Id);
            if (existingRequest == null)
            {
                return Json(new { success = false, message = "Không tìm thấy yêu cầu." });
            }

            if (existingRequest.Status != 0)
            {
                return Json(new { success = false, message = "Không thể chỉnh sửa yêu cầu đã được xử lý." });
            }

            if (ModelState.IsValid)
            {
                existingRequest.Des = request.Des;
                db.SaveChanges();

                var html = RenderRazorViewToString("_RequestRow", existingRequest);
                return Json(new { success = true, html = html, request = existingRequest });
            }

            return Json(new { success = false, message = "Dữ liệu không hợp lệ. Vui lòng kiểm tra lại." });
        }

        // GET: Tenant/Request/Delete/5
        public ActionResult Delete(int id, int page = 1, string sort = "")
        {
            string userEmail = Session["UserEmail"]?.ToString();
            if (string.IsNullOrEmpty(userEmail))
            {
                return RedirectToAction("Tenant_Login", "Login", new { area = "" });
            }

            var user = db.Users.FirstOrDefault(u => u.Email == userEmail && u.Role == 2);
            if (user == null)
            {
                return HttpNotFound("Không tìm thấy thông tin người dùng.");
            }

            var request = db.Requests.FirstOrDefault(r => r.Id == id && r.UserId == user.Id);
            if (request == null)
            {
                return HttpNotFound("Không tìm thấy yêu cầu.");
            }

            db.Requests.Remove(request);
            db.SaveChanges();

            TempData["SuccessMessage"] = "Xóa yêu cầu thành công!";
            return RedirectToAction("Index", new { page, sort });
        }

        // Hàm hỗ trợ để render view thành chuỗi HTML
        private string RenderRazorViewToString(string viewName, object model)
        {
            ViewData.Model = model;
            using (var sw = new System.IO.StringWriter())
            {
                var viewResult = ViewEngines.Engines.FindPartialView(ControllerContext, viewName);
                var viewContext = new ViewContext(ControllerContext, viewResult.View, ViewData, TempData, sw);
                viewResult.View.Render(viewContext, sw);
                viewResult.ViewEngine.ReleaseView(ControllerContext, viewResult.View);
                return sw.GetStringBuilder().ToString();
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}