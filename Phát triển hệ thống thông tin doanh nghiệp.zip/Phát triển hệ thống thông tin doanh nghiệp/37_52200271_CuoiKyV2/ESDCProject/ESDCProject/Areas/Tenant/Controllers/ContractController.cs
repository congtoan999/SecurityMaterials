﻿using ESDCProject.Models;
using ESDCProject.Services;
using System;
using System.Linq;
using System.Web.Mvc;
using System.Data.Entity;

namespace ESDCProject.Areas.Tenant.Controllers
{
    public class ContractController : Controller
    {
        private ESDCProjectDbContext db = new ESDCProjectDbContext();

        // GET: Tenant/Contract
        public ActionResult Index(int page = 1, int pageSize = 10, string sort = "", string search = "")
        {
            ViewBag.SelectedSort = sort;
            ViewBag.Search = search;

            int userId = Convert.ToInt32(Session["UserId"]);
            if (userId == 0)
            {
                return RedirectToAction("Tenant_Login", "Login", new { area = "" });
            }

            var contracts = db.Contracts
                .Include(c => c.User)
                .Include(c => c.Room)
                .Where(c => c.UserId == userId)
                .AsQueryable();

            if (!string.IsNullOrEmpty(search))
            {
                search = search.ToLower();
                contracts = contracts.Where(c =>
                    (c.ContractNumber != null && c.ContractNumber.ToLower().Contains(search)) ||
                    (c.Room != null && c.Room.RoomNumber != null && c.Room.RoomNumber.ToLower().Contains(search))
                );
            }

            switch (sort)
            {
                case "status_active":
                    contracts = contracts.Where(c => !c.IsTerminated && c.EndDate >= DateTime.Now)
                                        .OrderBy(c => c.EndDate);
                    break;
                case "status_expired":
                    contracts = contracts.Where(c => !c.IsTerminated && c.EndDate < DateTime.Now)
                                        .OrderBy(c => c.EndDate);
                    break;
                case "status_terminated":
                    contracts = contracts.Where(c => c.IsTerminated)
                                        .OrderBy(c => c.TerminationDate ?? c.EndDate);
                    break;
                default:
                    contracts = contracts.OrderByDescending(c => c.StartDate);
                    break;
            }

            int totalItems = contracts.Count();
            var pagedContracts = contracts
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToList();

            ViewBag.ActiveContracts = db.Contracts
                .Include(c => c.Room)
                .Where(c => c.UserId == userId && !c.IsTerminated && c.EndDate >= DateTime.Now)
                .ToList();

            ViewBag.CurrentPage = page;
            ViewBag.PageSize = pageSize;
            ViewBag.TotalItems = totalItems;
            ViewBag.TotalPages = (int)Math.Ceiling((double)totalItems / pageSize);

            return View(pagedContracts);
        }

        // POST: Tenant/Contract/ExtendContract
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ExtendContract(int contractId, DateTime newEndDate)
        {
            try
            {
                var contract = db.Contracts.Find(contractId);
                if (contract == null)
                {
                    return Json(new { success = false, message = "Hợp đồng không tồn tại." });
                }

                int userId = Convert.ToInt32(Session["UserId"]);
                if (userId == 0 || contract.UserId != userId)
                {
                    return Json(new { success = false, message = "Bạn không có quyền gia hạn hợp đồng này." });
                }

                if (newEndDate <= contract.EndDate)
                {
                    return Json(new { success = false, message = $"Ngày kết thúc mới phải sau ngày {contract.EndDate:dd/MM/yyyy}." });
                }

                var existingExtension = ContractExtensionService.GetAll()
                    .Any(ce => ce.ContractId == contractId && !ce.IsAccepted && ce.ProcessedDate == null);
                if (existingExtension)
                {
                    return Json(new { success = false, message = "Hợp đồng này đã có yêu cầu gia hạn đang chờ xử lý." });
                }

                var extension = new ContractExtension
                {
                    ContractId = contractId,
                    NewEndDate = newEndDate,
                    IsAccepted = false
                };

                ContractExtensionService.Add(extension);

                return Json(new { success = true, message = "Yêu cầu gia hạn hợp đồng đã được gửi thành công!" });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = "Lỗi khi gửi yêu cầu gia hạn: " + ex.Message });
            }
        }

        // GET: Tenant/Contract/DownloadContract/5
        public ActionResult DownloadContract(int id)
        {
            try
            {
                var contract = db.Contracts
                    .Include(c => c.User)
                    .FirstOrDefault(c => c.Id == id);

                if (contract == null)
                {
                    return HttpNotFound("Hợp đồng không tồn tại.");
                }

                int userId = Convert.ToInt32(Session["UserId"]);
                if (userId == 0 || contract.UserId != userId)
                {
                    return new HttpUnauthorizedResult("Bạn không có quyền tải hợp đồng này.");
                }

                var filePath = Server.MapPath($"~/Content/Contracts/{contract.ContractNumber}.pdf");
                if (!System.IO.File.Exists(filePath))
                {
                    return HttpNotFound($"File hợp đồng {contract.ContractNumber}.pdf không tồn tại.");
                }

                var fileBytes = System.IO.File.ReadAllBytes(filePath);
                var fileName = $"HopDongThuePhong_{contract.ContractNumber}.pdf";
                return File(fileBytes, "application/pdf", fileName);
            }
            catch (Exception ex)
            {
                return Content("Lỗi khi tải hợp đồng: " + ex.Message);
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}