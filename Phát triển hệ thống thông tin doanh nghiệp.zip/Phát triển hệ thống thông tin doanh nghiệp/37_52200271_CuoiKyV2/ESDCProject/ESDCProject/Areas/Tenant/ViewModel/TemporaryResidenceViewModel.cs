﻿using ESDCProject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ESDCProject.Areas.Tenant.ViewModel
{
    public class TemporaryResidenceViewModel
    {
        public TemporaryResidence PrimaryTenant { get; set; }
        public List<TemporaryResidence> OtherTenants { get; set; }
        public bool ConfirmCheckbox { get; set; }
        public string RegistrationType { get; set; }
        public int NumberOfAdditionalPeople { get; set; }
    }
}