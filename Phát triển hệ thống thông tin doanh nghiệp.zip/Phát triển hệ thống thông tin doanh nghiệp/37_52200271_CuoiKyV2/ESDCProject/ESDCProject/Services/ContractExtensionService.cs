﻿using ESDCProject.Models;
using System.Collections.Generic;
using System.Linq;
using System.Data.Entity;

namespace ESDCProject.Services
{
    public static class ContractExtensionService
    {
        public static List<ContractExtension> GetAll()
        {
            using (var db = new ESDCProjectDbContext())
            {
                return db.ContractExtensions
                    .Include(ce => ce.Contract)
                    .ToList();
            }
        }

        public static ContractExtension GetById(int id)
        {
            using (var db = new ESDCProjectDbContext())
            {
                return db.ContractExtensions
                    .Include(ce => ce.Contract)
                    .FirstOrDefault(e => e.Id == id);
            }
        }

        public static void Add(ContractExtension extension)
        {
            using (var db = new ESDCProjectDbContext())
            {
                db.ContractExtensions.Add(extension);
                db.SaveChanges();
            }
        }

        public static void Update(ContractExtension extension)
        {
            using (var db = new ESDCProjectDbContext())
            {
                var existing = db.ContractExtensions.FirstOrDefault(e => e.Id == extension.Id);
                if (existing != null)
                {
                    existing.ContractId = extension.ContractId;
                    existing.NewEndDate = extension.NewEndDate;
                    existing.IsAccepted = extension.IsAccepted;
                    existing.ProcessedDate = extension.ProcessedDate;
                    existing.RejectionReason = extension.RejectionReason;
                    db.Entry(existing).State = EntityState.Modified;
                    db.SaveChanges();
                }
            }
        }

        public static void Delete(int id)
        {
            using (var db = new ESDCProjectDbContext())
            {
                var extension = db.ContractExtensions.Find(id);
                if (extension != null)
                {
                    db.ContractExtensions.Remove(extension);
                    db.SaveChanges();
                }
            }
        }

        public static void Clear()
        {
        }
    }
}