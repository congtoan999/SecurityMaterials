﻿using Aspose.Words;
using Aspose.Words.Saving;
using ESDCProject.Models;
using System;
using System.IO;

namespace ESDCProject.Services
{
    public class ContractPdfService
    {
        public string GenerateContractPdf(Contract contract, User user, Room room, FixedPrice electricPrice, FixedPrice waterPrice, string outputDirectory)
        {
            try
            {
                // Đảm bảo thư mục đầu ra tồn tại
                if (!Directory.Exists(outputDirectory))
                {
                    Directory.CreateDirectory(outputDirectory);
                }

                // Đường dẫn file PDF
                string fileName = $"Contract_{contract.ContractNumber}_{DateTime.Now:yyyyMMddHHmmss}.pdf";
                string outputPath = Path.Combine(outputDirectory, fileName);

                // Tạo tài liệu mới
                Document doc = new Document();
                DocumentBuilder builder = new DocumentBuilder(doc);

                // Thiết lập font và định dạng chung
                builder.Font.Name = "Times New Roman";
                builder.Font.Size = 12;

                // Tiêu đề quốc hiệu
                builder.Font.Bold = true;
                builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;
                builder.Writeln("CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM");
                builder.Writeln("Độc lập – Tự do – Hạnh phúc");
                builder.Writeln("---------------------");
                builder.Font.Size = 14;
                builder.Writeln("HỢP ĐỒNG THUÊ PHÒNG TRỌ");
                builder.Font.Size = 12;
                builder.Font.Bold = false;
                builder.ParagraphFormat.Alignment = ParagraphAlignment.Left;
                builder.Writeln($"Hôm nay ngày {DateTime.Now:dd/MM/yyyy},");
                builder.Writeln("Chúng tôi gồm:");
                builder.Writeln();

                // 1. Thông tin bên A
                builder.Font.Bold = true;
                builder.Writeln("1. Đại diện bên cho thuê phòng trọ (Bên A):");
                builder.Font.Bold = false;
                builder.Writeln("Ông/bà: Admin");
                builder.Writeln("Sinh ngày: 01/04/2004");
                builder.Writeln("CMND số: 082204001010 cấp ngày 19/02/2021 tại: Thành Phố Hồ Chí Minh");
                builder.Writeln("Số điện thoại: 0999999999");
                builder.Writeln();

                // 2. Thông tin bên B
                builder.Font.Bold = true;
                builder.Writeln("2. Bên thuê phòng trọ (Bên B):");
                builder.Font.Bold = false;
                builder.Writeln($"Ông/bà: {user.Name}");
                builder.Writeln($"Sinh ngày: {user.DateOfBirth:dd/MM/yyyy}");
                builder.Writeln($"Số CMND: {user.IdentityNumber ?? "N/A"} cấp ngày: N/A tại: N/A");
                builder.Writeln($"Số điện thoại: {user.Phone ?? "N/A"}");
                builder.Writeln();

                // Thỏa thuận
                builder.Writeln("Sau khi bàn bạc trên tinh thần dân chủ, hai bên cùng có lợi, cùng thống nhất như sau:");
                builder.Writeln($"Bên A đồng ý cho bên B thuê 01 phòng số: {room.RoomNumber}");
                builder.Writeln($"Giá thuê: {room.BasePrice:N0} đ/tháng");
                builder.Writeln("Hình thức thanh toán: Thanh toán trực tiếp/trực tuyến.");
                builder.Writeln();
                builder.Writeln($"Tiền điện: {electricPrice.Price:N0} đ/kwh tính theo chỉ số công tơ, thanh toán vào cuối các tháng.");
                builder.Writeln($"Tiền nước: {waterPrice.Price:N0} đ/người thanh toán vào đầu các tháng.");
                builder.Writeln($"Tiền đặt cọc: {contract.Deposit:N0} ₫");
                builder.Writeln($"Hợp đồng có giá trị kể từ: {contract.StartDate:dd/MM/yyyy} đến {contract.EndDate:dd/MM/yyyy}");
                builder.Writeln();

                // Trách nhiệm của các bên
                builder.Font.Bold = true;
                builder.Writeln("TRÁCH NHIỆM CỦA CÁC BÊN");
                builder.Font.Bold = false;

                builder.Writeln("* Trách nhiệm của bên A:");
                builder.Writeln("- Tạo mọi điều kiện thuận lợi để bên B thực hiện theo hợp đồng.");
                builder.Writeln("- Cung cấp nguồn điện, nước, wifi cho bên B sử dụng.");
                builder.Writeln();

                builder.Writeln("* Trách nhiệm của bên B:");
                builder.Writeln("- Thanh toán đầy đủ các khoản tiền theo đúng thỏa thuận.");
                builder.Writeln("- Bảo quản các trang thiết bị và cơ sở vật chất của bên A trang bị cho ban đầu (làm hỏng phải sửa, mất phải đền).");
                builder.Writeln("- Không được tự ý sửa chữa, cải tạo cơ sở vật chất khi chưa được sự đồng ý của bên A.");
                builder.Writeln("- Giữ gìn vệ sinh trong và ngoài khuôn viên của phòng trọ.");
                builder.Writeln("- Bên B phải chấp hành mọi quy định của pháp luật Nhà nước và quy định của địa phương.");
                builder.Writeln("- Nếu bên B cho khách ở qua đêm thì phải báo và được sự đồng ý của chủ nhà đồng thời phải chịu trách nhiệm về các hành vi vi phạm pháp luật của khách trong thời gian ở lại.");
                builder.Writeln();

                // Trách nhiệm chung
                builder.Font.Bold = true;
                builder.Writeln("TRÁCH NHIỆM CHUNG");
                builder.Font.Bold = false;
                builder.Writeln("- Hai bên phải tạo điều kiện cho nhau thực hiện hợp đồng.");
                builder.Writeln("- Trong thời gian hợp đồng còn hiệu lực nếu bên nào vi phạm các điều khoản đã thỏa thuận thì bên còn lại có quyền đơn phương chấm dứt hợp đồng; nếu sự vi phạm hợp đồng đó gây tổn thất cho bên bị vi phạm hợp đồng thì bên vi phạm hợp đồng phải bồi thường thiệt hại.");
                builder.Writeln("- Một trong hai bên muốn chấm dứt hợp đồng trước thời hạn thì phải báo trước cho bên kia ít nhất 30 ngày và hai bên phải có sự thống nhất.");
                builder.Writeln("- Bên A phải trả lại tiền đặt cọc cho bên B.");
                builder.Writeln("- Bên nào vi phạm điều khoản chung thì phải chịu trách nhiệm trước pháp luật.");
                builder.Writeln("- Hợp đồng được lập thành 02 bản có giá trị pháp lý như nhau, mỗi bên giữ một bản.");
                builder.Writeln();

                // Chữ ký
                builder.ParagraphFormat.Alignment = ParagraphAlignment.Justify;
                builder.Writeln("ĐẠI DIỆN BÊN B                                      ĐẠI DIỆN BÊN A");
                builder.ParagraphFormat.Alignment = ParagraphAlignment.Left;

                // Lưu tài liệu dưới dạng PDF
                PdfSaveOptions saveOptions = new PdfSaveOptions
                {
                    Compliance = PdfCompliance.Pdf17
                };
                doc.Save(outputPath, saveOptions);

                return outputPath; // Trả về đường dẫn file để sử dụng sau này
            }
            catch (Exception ex)
            {
                throw new Exception($"Lỗi khi tạo PDF: {ex.Message}");
            }
        }
    }
}