﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ESDCProject.Models
{
    public class Payment
    {
        [Key]
        public int Id { get; set; }

        public int Amount { get; set; } = 0;

        [StringLength(255)]
        public string Description { get; set; }

        public DateTime PaymentDate { get; set; } = DateTime.Now;

        public int Method { get; set; } = 0;

        [StringLength(100)]
        public string TransactionReference { get; set; }

        public int? BillId { get; set; }
        public int? UserId { get; set; }

        [ForeignKey("BillId")]
        public virtual Bill Bill { get; set; }

        [ForeignKey("UserId")]
        public virtual User User { get; set; }
    }
}