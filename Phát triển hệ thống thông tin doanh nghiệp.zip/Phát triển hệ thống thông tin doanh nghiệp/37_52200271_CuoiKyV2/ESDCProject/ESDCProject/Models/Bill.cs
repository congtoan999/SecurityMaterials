﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ESDCProject.Models
{
    public class Bill
    {
        [Key]
        public int Id { get; set; }

        public int PreviousElectricity { get; set; } = 0;
        public int CurrentElectricity { get; set; } = 0;
        public int ElectricityQuantity { get; set; } = 0;
        public int PreviousWater { get; set; } = 0;
        public int CurrentWater { get; set; } = 0;
        public int WaterQuantity { get; set; } = 0;
        public int ElectricityFee { get; set; } = 0;
        public int WaterFee { get; set; } = 0;
        public int VehicleFee { get; set; } = 0;
        public int RentFee { get; set; } = 0;
        public DateTime BillingPeriodStart { get; set; }
        public DateTime BillingPeriodEnd { get; set; }

        public int Status { get; set; } = 0;

        public int? ContractId { get; set; }
        public int? UserId { get; set; }

        public DateTime? PaymentDate { get; set; }

        [StringLength(50)]
        public string PaymentMethod { get; set; }

        [StringLength(100)]
        public string PaymentReference { get; set; }

        public DateTime DateOfBill { get; set; } = DateTime.Now;

        public Boolean IsPaid { get; set; } = false;

        public string ReceiptFilePath { get; set; }

        [ForeignKey("ContractId")]
        public virtual Contract Contract { get; set; }

        [ForeignKey("UserId")]
        public virtual User User { get; set; }

        public virtual ICollection<Payment> Payments { get; set; }
    }
}