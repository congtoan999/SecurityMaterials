﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ESDCProject.Models
{
    public class TemporaryResidence
    {
        [Key]
        public int Id { get; set; }

        public int UserId { get; set; }

        [Required]
        [StringLength(100)]
        public string FullName { get; set; }

        public DateTime DateOfBirth { get; set; }

        [Required]
        [StringLength(20)]
        public string IdentityNumber { get; set; }

        public DateTime IdentityIssueDate { get; set; }

        [Required]
        [StringLength(100)]
        public string IdentityIssuePlace { get; set; }

        [Required]
        [StringLength(200)]
        public string PermanentAddress { get; set; }

        [Required]
        [StringLength(200)]
        public string TemporaryAddress { get; set; }

        [StringLength(50)]
        public string NameOfLocalPolice { get; set; }

        [Required]
        [StringLength(200)]
        public string StayReason { get; set; } = "Thuê trọ";

        public DateTime CurrentDate { get; set; }

        [StringLength(255)]
        public string SignatureImage { get; set; }

        public byte[] SignatureData { get; set; }

        [StringLength(255)]
        public string PdfFilePath { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.Now;

        public DateTime? SubmittedAt { get; set; }

        public int Status { get; set; } = 0;

        [ForeignKey("UserId")]
        public virtual User User { get; set; }
    }
}