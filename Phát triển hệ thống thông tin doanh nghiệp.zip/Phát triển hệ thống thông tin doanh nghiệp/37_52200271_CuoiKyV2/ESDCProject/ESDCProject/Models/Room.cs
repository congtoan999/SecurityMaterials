﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ESDCProject.Models
{
    public class Room
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [StringLength(20)]
        public string RoomNumber { get; set; }

        public string Area { get; set; }

        public int BasePrice { get; set; } = 0;

        public int MaxOccupants { get; set; } = 2;

        [StringLength(500)]
        public string Description { get; set; }

        public int Status { get; set; } = 0;

        public DateTime CreatedAt { get; set; } = DateTime.Now;

        public virtual ICollection<User> Users { get; set; }
        public virtual ICollection<Contract> Contracts { get; set; }
        public virtual ICollection<Vehicle> Vehicles { get; set; }
    }
}