﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ESDCProject.Models
{
    public class User
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [StringLength(100)]
        public string Email { get; set; }

        [Required]
        [StringLength(100)]
        public string Name { get; set; }

        [Required]
        [StringLength(100)]
        public string Password { get; set; }

        public int Role { get; set; } = 0;

        public bool IsFemale { get; set; } = false;

        public DateTime DateOfBirth { get; set; } = new DateTime(2000, 1, 1);

        [StringLength(20)]
        public string Phone { get; set; }

        [StringLength(20)]
        public string IdentityNumber { get; set; }

        [StringLength(200)]
        public string Address { get; set; }

        [StringLength(200)]
        public string Avatar { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.Now;

        public DateTime? LastLogin { get; set; }

        public bool IsActive { get; set; } = true;

        public int? RoomId { get; set; }

        [ForeignKey("RoomId")]
        public virtual Room Room { get; set; }

        public virtual ICollection<Contract> Contracts { get; set; }
        public virtual ICollection<Bill> Bills { get; set; }
        public virtual ICollection<Request> Requests { get; set; }
        public virtual ICollection<Payment> Payments { get; set; }
        public virtual ICollection<TemporaryResidence> TemporaryResidences { get; set; }
    }
}