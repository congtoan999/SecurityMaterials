﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ESDCProject.Models
{
    public class FixedPrice
    {
        [Key]
        public int Id { get; set; }

        public FixedPriceType Type { get; set; }

        public int Price { get; set; } = 0;
    }
    public enum FixedPriceType
    {
        Water,
        Electricity
    }
}