﻿using System;

namespace ESDCProject.Models
{
    public class ContractExtension
    {
        public int Id { get; set; }
        public int ContractId { get; set; }
        public DateTime NewEndDate { get; set; }
        public bool IsAccepted { get; set; }
        public DateTime? ProcessedDate { get; set; }
        public string RejectionReason { get; set; }
        public virtual Contract Contract { get; set; }
    }
}