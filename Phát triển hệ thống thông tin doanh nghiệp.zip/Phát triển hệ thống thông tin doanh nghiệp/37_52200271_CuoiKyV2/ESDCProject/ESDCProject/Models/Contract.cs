﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ESDCProject.Models
{
    public class Contract
    {
        [Key]
        public int Id { get; set; }

        [StringLength(50)]
        public string ContractNumber { get; set; }

        public int? UserId { get; set; }

        public int? RoomId { get; set; }

        public int Price { get; set; } = 0;

        public int Deposit { get; set; } = 0;

        public DateTime StartDate { get; set; } = DateTime.Now;

        public DateTime EndDate { get; set; }

        public bool IsTerminated { get; set; } = false;

        public DateTime? TerminationDate { get; set; }

        [StringLength(500)]
        public string TerminationReason { get; set; }

        [StringLength(255)]
        public string ContractFilePath { get; set; }

        public int PaymentDayOfMonth { get; set; } = 5;

        [ForeignKey("UserId")]
        public virtual User User { get; set; }

        [ForeignKey("RoomId")]
        public virtual Room Room { get; set; }
    }
}