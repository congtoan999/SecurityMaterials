﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Web;

namespace ESDCProject.Models
{
    public class ESDCProjectDbContext : DbContext
    {
        public ESDCProjectDbContext() : base("name=ESDCProject")
        {
        }

        public virtual DbSet<User> Users { get; set; }
        public virtual DbSet<Room> Rooms { get; set; }
        public virtual DbSet<Contract> Contracts { get; set; }
        public virtual DbSet<Bill> Bills { get; set; }
        public virtual DbSet<Vehicle> Vehicles { get; set; }
        public virtual DbSet<Request> Requests { get; set; }
        public virtual DbSet<FixedPrice> FixedPrices { get; set; }
        public virtual DbSet<Payment> Payments { get; set; }
        public virtual DbSet<TemporaryResidence> TemporaryResidences { get; set; }
        public virtual DbSet<ContractExtension> ContractExtensions { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            // Remove pluralizing table names convention
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();

            // User entity configuration
            modelBuilder.Entity<User>()
                .Property(u => u.Role)
                .HasColumnAnnotation("DefaultValue", 0);

            modelBuilder.Entity<User>()
                .Property(u => u.IsFemale)
                .HasColumnAnnotation("DefaultValue", false);

            modelBuilder.Entity<User>()
                .Property(u => u.DateOfBirth)
                .HasColumnAnnotation("DefaultValue", new DateTime(2000, 1, 1));

            modelBuilder.Entity<User>()
                .Property(u => u.CreatedAt)
                .HasColumnAnnotation("DefaultValueSql", "GETDATE()");

            modelBuilder.Entity<User>()
                .Property(u => u.IsActive)
                .HasColumnAnnotation("DefaultValue", true);

            // Room entity configuration
            modelBuilder.Entity<Room>()
                .Property(r => r.BasePrice)
                .HasColumnAnnotation("DefaultValue", 0);

            modelBuilder.Entity<Room>()
                .Property(r => r.MaxOccupants)
                .HasColumnAnnotation("DefaultValue", 2);

            modelBuilder.Entity<Room>()
                .Property(r => r.Status)
                .HasColumnAnnotation("DefaultValue", 0);

            modelBuilder.Entity<Room>()
                .Property(r => r.CreatedAt)
                .HasColumnAnnotation("DefaultValueSql", "GETDATE()");

            // Other entity configurations as needed
        }
    }
}