# README.txt

## 1. Yêu cầu môi trường
- Visual Studio 2019 trở lên
- .NET Framework 4.7.2

## 2. Hướng dẫn setup
1. **Clone/Mở project**  
   Mở file `ESDCProject.csproj` bằng Visual Studio. (Nếu có file `.sln` ở thư mục cha, hãy mở file `.sln` đó.)

2. **Cấu hình Web.config**  
   - Đổi phần `<connectionStrings>` trong file `Web.config`.
   - Đổi `data source=` thành tên SQL Server instance trên máy chấm (ví dụ: `localhost`, `.\SQLEXPRESS`, hoặc tên máy).
   - Có thể đổi tên database (`initial catalog=ESDCProject`) nếu muốn.

   Ví dụ:
   ```
   <connectionStrings>
     <add name="ESDCProject"
          connectionString="data source=localhost;initial catalog=ESDCProject;user id=sa;pwd=your_password"
          providerName="System.Data.SqlClient" />
   </connectionStrings>
   ```

3. **Khởi tạo database và dữ liệu mẫu**
   - Dữ liệu mẫu sẽ tự động sinh khi chạy migration lần đầu, Entity Framework sẽ tự động tạo database và sinh dữ liệu mẫu (tài khoản, phòng, hợp đồng, hóa đơn...).
   - Nếu cần, có thể chạy lệnh migration thủ công trong Package Manager Console:
     ```
     Update-Database
     ```

4. **Chạy project**
   - Mở file ESDCProject.csproj (hoặc file .sln nếu có) trên Visual Studio.
   - Trên menu Build chọn "Clean Solution".
   - Trên menu Build chọn "Rebuild Solution".
   - Nhấn F5 hoặc bấm "Start" trong Visual Studio để chạy web app.

## 3. Tài khoản đăng nhập mẫu

| Role    | Email                | Password    |
|---------|----------------------|------------|
| Admin   | admin@gmail.com      | Admin@123  |
| Manager | manager1@gmail.com   | Manager@123|
| Manager | manager2@gmail.com   | Manager@123|
| User    | tenant1@gmail.com    | Tenant@123 |
| User    | tenant2@gmail.com    | Tenant@123 |
| User    | tenant3@gmail.com    | Tenant@123 |
| User    | tenant4@gmail.com    | Tenant@123 |
| User    | tenant5@gmail.com    | Tenant@123 |
| User    | tenant6@gmail.com    | Tenant@123 |
| User    | tenant7@gmail.com    | Tenant@123 |

## 4. Một số lưu ý quan trọng
- Cơ sở dữ liệu và dữ liệu mẫu sẽ tự động sinh khi chạy migration.
- Đăng nhập bằng tài khoản admin để truy cập khu vực quản trị (`/Admin`).
- Nếu gặp lỗi kết nối database, kiểm tra lại connection string và quyền truy cập SQL Server. 