#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

typedef struct {
    int number;
    int factorial_result;
    int smaller_sum;
    char filename[50];
    pthread_mutex_t lock;
} ThreadData;

void *calculateFactorial(void *arg) {
    ThreadData *data = (ThreadData *)arg;
    pthread_mutex_lock(&data->lock);
    if (data->number == 0) {
        data->factorial_result = 1;
    } else {
        int fact = 1;
        for (int i = 1; i <= data->number; i++) {
            fact *= i;
        }
        data->factorial_result = fact;
    }
    pthread_mutex_unlock(&data->lock);
    pthread_exit(NULL);
}

void *calculateWordCount(void *arg) {
    ThreadData *data = (ThreadData *)arg;
    pthread_mutex_lock(&data->lock);
    int factorial = data->factorial_result;
    pthread_mutex_unlock(&data->lock);

    int sum = 0;
    for (int i = 1; i < factorial; i++) {
        sum += i;
    }

    pthread_mutex_lock(&data->lock);
    data->smaller_sum = sum;
    pthread_mutex_unlock(&data->lock);
    pthread_exit(NULL);
}

void *writeToFile(void *arg) {
    ThreadData *data = (ThreadData *)arg;
    pthread_mutex_lock(&data->lock);
    while (data->factorial_result == 0 || data->smaller_sum == 0) {
        pthread_mutex_unlock(&data->lock);
        continue;
    }

    FILE *file = fopen(data->filename, "w");
    if (file != NULL) {
        fprintf(file, "N = %d\n", data->number);
        fprintf(file, "%d! = %d\n", data->number, data->factorial_result);
        fprintf(file, "Sum = %d\n", data->smaller_sum);
        fclose(file);
    } else {
        printf("Error opening file.\n");
    }
    pthread_mutex_unlock(&data->lock);
    pthread_exit(NULL);
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Please provide two arguments.\n");
        return 1;
    }

    ThreadData data;
    data.number = atoi(argv[1]);
    if (strlen(argv[2]) >= 50) {
        printf("File name too long.\n");
        return 1;
    }
    strcpy(data.filename, argv[2]);
    pthread_mutex_init(&data.lock, NULL);

    pthread_t t1, t2, t3;

    pthread_create(&t1, NULL, calculateFactorial, (void *)&data);
    pthread_create(&t2, NULL, calculateWordCount, (void *)&data);
    pthread_create(&t3, NULL, writeToFile, (void *)&data);

    pthread_join(t1, NULL);
    pthread_join(t2, NULL);
    pthread_join(t3, NULL);

    pthread_mutex_destroy(&data.lock);

    printf("Program executed successfully.\n");
    return 0;
}
