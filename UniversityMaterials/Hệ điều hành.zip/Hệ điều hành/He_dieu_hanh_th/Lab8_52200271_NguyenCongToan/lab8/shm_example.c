#include <stdio.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <unistd.h>
#include <sys/wait.h>

#define SHM_SIZE 1024  // Define size of shared memory

// Structure for shared memory
struct shm_data {
    int num1;
    int num2;
    int sum;
};

int main(int argc, char *argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <num1> <num2>\n", argv[0]);
        exit(1);
    }

    // Create a shared memory segment
    key_t key = ftok("shmfile", 65);
    int shmid = shmget(key, SHM_SIZE, 0666 | IPC_CREAT);
    if (shmid == -1) {
        perror("shmget failed");
        exit(1);
    }

    // Attach the shared memory segment to our address space
    struct shm_data *shared_data = (struct shm_data *)shmat(shmid, NULL, 0);
    if (shared_data == (void *)-1) {
        perror("shmat failed");
        exit(1);
    }

    // Create a child process using fork()
    pid_t pid = fork();

    if (pid < 0) {
        perror("Fork failed");
        exit(1);
    }

    if (pid == 0) {
        // Child process
        shared_data->num1 = atoi(argv[1]);
        shared_data->num2 = atoi(argv[2]);

        // Child writes the numbers to shared memory
        printf("Child: Numbers written to shared memory: %d and %d\n", shared_data->num1, shared_data->num2);

        // Wait for parent to sum and write the result
        while (shared_data->sum == 0) {
            sleep(1);  // Wait for the sum to be written by parent
        }

        // Read the sum from shared memory and output to the screen
        printf("Child: Sum read from shared memory: %d\n", shared_data->sum);

        // Detach from shared memory and exit
        shmdt(shared_data);
        exit(0);
    } else {
        // Parent process
        sleep(1);  // Give child time to write the numbers to shared memory

        // Parent reads the numbers from shared memory and calculates the sum
        int num1 = shared_data->num1;
        int num2 = shared_data->num2;
        shared_data->sum = num1 + num2;

        // Parent writes the sum back to shared memory
        printf("Parent: Calculated sum is: %d\n", shared_data->sum);

        // Wait for child to read the sum
        wait(NULL);

        // Detach from shared memory and remove the shared memory segment
        shmdt(shared_data);
        shmctl(shmid, IPC_RMID, NULL);  // Remove the shared memory segment
    }

    return 0;
}
