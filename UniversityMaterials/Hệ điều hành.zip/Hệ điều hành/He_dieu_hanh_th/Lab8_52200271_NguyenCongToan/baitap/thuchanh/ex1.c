#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/wait.h>

#define SIZE 10 // Maximum size of the array
#define SM_0 "/sm_0" // Shared memory for array elements
#define SM_1 "/sm_1" // Shared memory for sum result

int main() {
    pid_t pid;
    int fd_0, fd_1;
    int *sm_0, *sm_1;

    // Create shared memory objects
    fd_0 = shm_open(SM_0, O_CREAT | O_RDWR, 0666);
    fd_1 = shm_open(SM_1, O_CREAT | O_RDWR, 0666);
    ftruncate(fd_0, SIZE * sizeof(int)); // allocate space for array
    ftruncate(fd_1, sizeof(int)); // allocate space for sum result

    // Map shared memory objects
    sm_0 = mmap(0, SIZE * sizeof(int), PROT_WRITE | PROT_READ, MAP_SHARED, fd_0, 0);
    sm_1 = mmap(0, sizeof(int), PROT_WRITE | PROT_READ, MAP_SHARED, fd_1, 0);

    if ((pid = fork()) == 0) { // Child process
        // Write data to SM_0
        int array[SIZE - 1] = {1, 2, 3, 4, 5}; // Example array
        int n = 5; // Number of elements
        sm_0[0] = n; // Set the number of elements in sm_0[0]
        
        for (int i = 0; i < n; i++) {
            sm_0[i + 1] = array[i]; // Write array elements starting from sm_0[1]
        }

        // Unmap and close shared memory
        munmap(sm_0, SIZE * sizeof(int));
        munmap(sm_1, sizeof(int));
        close(fd_0);
        close(fd_1);
        exit(0);
    } else { // Parent process
        wait(NULL); // Wait for the child process to finish writing

        // Read number of elements from sm_0[0]
        int n = sm_0[0];
        int sum = 0;

        // Sum elements from SM_0 and write the result to SM_1
        for (int i = 0; i < n; i++) {
            sum += sm_0[i + 1];
        }
        sm_1[0] = sum; // Write sum to SM_1

        // Print the result
        printf("The sum of array elements is: %d\n", sm_1[0]);

        // Clean up
        munmap(sm_0, SIZE * sizeof(int));
        munmap(sm_1, sizeof(int));
        close(fd_0);
        close(fd_1);
        shm_unlink(SM_0);
        shm_unlink(SM_1);
    }

    return 0;
}
