#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>

#define SM_0 "/sm_0" // Shared memory for operation data
#define SM_1 "/sm_1" // Shared memory for result

typedef struct {
    int operand1;
    int operand2;
    char operator;
} OperationData;

int main() {
    pid_t pid;
    int fd_0, fd_1;
    OperationData *sm_0;
    int *sm_1;

    // Open the input file
    FILE *inputFile = fopen("input.txt", "r");
    if (inputFile == NULL) {
        perror("Error opening input file");
        exit(EXIT_FAILURE);
    }

    // Create shared memory objects
    fd_0 = shm_open(SM_0, O_CREAT | O_RDWR, 0666);
    fd_1 = shm_open(SM_1, O_CREAT | O_RDWR, 0666);
    ftruncate(fd_0, sizeof(OperationData)); // Allocate space for operation data
    ftruncate(fd_1, sizeof(int)); // Allocate space for result

    // Map shared memory objects
    sm_0 = mmap(0, sizeof(OperationData), PROT_WRITE | PROT_READ, MAP_SHARED, fd_0, 0);
    sm_1 = mmap(0, sizeof(int), PROT_WRITE | PROT_READ, MAP_SHARED, fd_1, 0);

    if ((pid = fork()) == 0) { // Child process
        // Read data from input file
        int operand1, operand2;
        char operator;
        fscanf(inputFile, "%d %d %c", &operand1, &operand2, &operator);
        fclose(inputFile);

        // Print the read values for verification
        printf("Read from input.txt: operand1 = %d, operand2 = %d, operator = %c\n", operand1, operand2, operator);

        // Write data to shared memory SM_0
        sm_0->operand1 = operand1;
        sm_0->operand2 = operand2;
        sm_0->operator = operator;

        // Wait for the parent process to calculate the result
        sleep(1); // Allow time for the parent to calculate

        // Read the result from SM_1
        int result = *sm_1;

        // Open output file to write the result
        FILE *outputFile = fopen("output.txt", "w");
        if (outputFile == NULL) {
            perror("Error opening output file");
            exit(EXIT_FAILURE);
        }
        fprintf(outputFile, "Result: %d\n", result);
        fclose(outputFile);

        // Unmap and close shared memory
        munmap(sm_0, sizeof(OperationData));
        munmap(sm_1, sizeof(int));
        close(fd_0);
        close(fd_1);
        exit(0);

    } else { // Parent process
        // Wait for the child to write to shared memory SM_0
        sleep(1); // Allow time for the child to write to shared memory

        // Read the operation data from SM_0
        int operand1 = sm_0->operand1;
        int operand2 = sm_0->operand2;
        char operator = sm_0->operator;
        int result;

        // Perform the specified arithmetic operation
        switch (operator) {
            case '+':
                result = operand1 + operand2;
                break;
            case '-':
                result = operand1 - operand2;
                break;
            case '*':
                result = operand1 * operand2;
                break;
            case '/':
                if (operand2 == 0) {
                    fprintf(stderr, "Division by zero error.\n");
                    result = 0; // Handle error
                } else {
                    result = operand1 / operand2;
                }
                break;
            default:
                fprintf(stderr, "Invalid operator.\n");
                result = 0;
                break;
        }

        // Write the result to SM_1
        *sm_1 = result;

        // Wait for the child to finish writing to output.txt
        wait(NULL);

        // Clean up
        munmap(sm_0, sizeof(OperationData));
        munmap(sm_1, sizeof(int));
        close(fd_0);
        close(fd_1);
        shm_unlink(SM_0);
        shm_unlink(SM_1);
    }

    return 0;
}
