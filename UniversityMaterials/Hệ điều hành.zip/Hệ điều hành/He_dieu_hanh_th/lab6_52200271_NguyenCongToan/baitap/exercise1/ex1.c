#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void calculateFactorial(int n, unsigned long long *result) {
    if (n == 0 || n == 1) {
        *result = 1;
    } else {
        unsigned long long factorial = 1;
        for (int i = 1; i <= n; ++i) {
            factorial *= i;
        }
        *result = factorial;
    }
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <integer>\n", argv[0]);
        return 1;
    }

    int number = atoi(argv[1]);

    int fd[2];
    if (pipe(fd) == -1) {
        fprintf(stderr, "Pipe failed");
        return 1;
    }

    pid_t pid = fork();

    if (pid < 0) {
        fprintf(stderr, "Fork failed");
        return 1;
    } else if (pid > 0) { // parent process
        close(fd[1]); // close the unused write end

        unsigned long long factorial_result;
        read(fd[0], &factorial_result, sizeof(factorial_result)); // read the result from the pipe
        close(fd[0]); // close the read end

        printf("Factorial of %d is: %llu\n", number, factorial_result);

    } else { // child process
        close(fd[0]); // close the unused read end

        unsigned long long result;
        calculateFactorial(number, &result);

        write(fd[1], &result, sizeof(result)); // write the result to the pipe
        close(fd[1]); // close the write end

        exit(0);
    }

    return 0;
}
