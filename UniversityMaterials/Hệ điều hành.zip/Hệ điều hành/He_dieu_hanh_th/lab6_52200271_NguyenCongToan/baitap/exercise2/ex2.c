#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

int main() {
    mkfifo("pipe", 0666);
    int fd;
    char *myfifo = "pipe";

    pid_t pid = fork();

    if (pid < 0) {
        fprintf(stderr, "Fork failed");
        return 1;
    } else if (pid > 0) { // parent process
        int num1, num2;
        char op;

        printf("Enter two integers: ");
        scanf("%d %d", &num1, &num2);

        printf("Enter an operator (+, -, *, /): ");
        scanf(" %c", &op);

        fd = open(myfifo, O_WRONLY);
        write(fd, &num1, sizeof(num1));
        write(fd, &num2, sizeof(num2));
        write(fd, &op, sizeof(op));
        close(fd);

        int result;
        fd = open(myfifo, O_RDONLY);
        read(fd, &result, sizeof(result));
        close(fd);

        FILE *fptr;
        fptr = fopen("result.txt", "w");
        if (fptr == NULL) {
            printf("Error creating file!");
            return 1;
        }
        fprintf(fptr, "The result is: %d", result);
        fclose(fptr);

    } else { // child process
        int num1, num2;
        char op;
        fd = open(myfifo, O_RDONLY);
        read(fd, &num1, sizeof(num1));
        read(fd, &num2, sizeof(num2));
        read(fd, &op, sizeof(op));
        close(fd);

        int result;
        if (op == '+') {
            result = num1 + num2;
        } else if (op == '-') {
            result = num1 - num2;
        } else if (op == '*') {
            result = num1 * num2;
        } else if (op == '/') {
            if (num2 == 0) {
                printf("Error! Division by zero!");
                return 1;
            }
            result = num1 / num2;
        }

        fd = open(myfifo, O_WRONLY);
        write(fd, &result, sizeof(result));
        close(fd);
    }

    return 0;
}
