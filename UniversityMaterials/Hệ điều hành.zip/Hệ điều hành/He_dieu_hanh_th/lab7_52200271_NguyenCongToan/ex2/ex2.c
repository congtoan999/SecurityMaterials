#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <unistd.h>

// Define a structure for the message
struct Message {
    long mtype;  // Message type
    int num1;    // First number
    int num2;    // Second number
    char op;     // Operation
    int result;  // Result
};

int main() {
    // Generate a key for the message queue
    key_t key = ftok(".", 'm');
    if (key == -1) {
        perror("ftok");
        return 1;
    }

    // Create a message queue
    int msgid = msgget(key, IPC_CREAT | 0666);
    if (msgid == -1) {
        perror("msgget");
        return 1;
    }

    // Fork a child process
    pid_t pid = fork();

    if (pid < 0) {
        fprintf(stderr, "Fork failed\n");
        return 1;
    } else if (pid == 0) {  // Child process
        // Read data from file
        FILE *file = fopen("input.txt", "r");
        if (file == NULL) {
            perror("Error opening file");
            return 1;
        }

        struct Message msg;
        fscanf(file, "%d %d %c", &msg.num1, &msg.num2, &msg.op);

        fclose(file);

        // Pass data to the parent process through the message queue
        msg.mtype = 1;  // Message type 1
        if (msgsnd(msgid, &msg, sizeof(struct Message) - sizeof(long), 0) == -1) {
            perror("msgsnd");
            return 1;
        }

        printf("Child process sent data to parent process.\n");
    } else {  // Parent process
        // Receive data from the child process
        struct Message msg;
        if (msgrcv(msgid, &msg, sizeof(struct Message) - sizeof(long), 1, 0) == -1) {
            perror("msgrcv");
            return 1;
        }

        // Calculate the result
        switch (msg.op) {
            case '+':
                msg.result = msg.num1 + msg.num2;
                break;
            case '-':
                msg.result = msg.num1 - msg.num2;
                break;
            case '*':
                msg.result = msg.num1 * msg.num2;
                break;
            case '/':
                if (msg.num2 != 0) {
                    msg.result = msg.num1 / msg.num2;
                } else {
                    fprintf(stderr, "Error: Division by zero\n");
                    msg.result = 0;
                }
                break;
            default:
                fprintf(stderr, "Error: Invalid operation\n");
                msg.result = 0;
        }

        // Send the result back to the child process
        msg.mtype = 2;  // Message type 2
        if (msgsnd(msgid, &msg, sizeof(struct Message) - sizeof(long), 0) == -1) {
            perror("msgsnd");
            return 1;
        }

        printf("Parent process calculated result = %d.\n");

        // Write the result to a file
        FILE *resultFile = fopen("result.txt", "w");
        if (resultFile == NULL) {
            perror("Error opening result file");
            return 1;
        }

        fprintf(resultFile, "Result: %d\n", msg.result);
        fclose(resultFile);
    }

    // Remove the message queue
    if (msgctl(msgid, IPC_RMID, NULL) == -1) {
        perror("msgctl");
        return 1;
    }

    return 0;
}
