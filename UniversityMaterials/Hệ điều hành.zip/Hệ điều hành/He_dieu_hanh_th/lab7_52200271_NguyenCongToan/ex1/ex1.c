#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <unistd.h>

// Define a structure for the message
struct Message {
    long mtype;  // Message type
    int data;    // Data to be sent in the message
};

int factorial(int n) {
    if (n == 0 || n == 1) {
        return 1;
    } else {
        return n * factorial(n - 1);
    }
}

int main(int argc, char *argv[]) {
    // Check if the correct number of arguments is provided
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <integer greater than 3>\n", argv[0]);
        return 1;
    }

    // Convert the argument to an integer
    int n = atoi(argv[1]);

    // Check if n is greater than 3
    if (n <= 3) {
        fprintf(stderr, "Please provide an integer greater than 3\n");
        return 1;
    }

    // Generate a key for the message queue
    key_t key = ftok(".", 'm');
    if (key == -1) {
        perror("ftok");
        return 1;
    }

    // Create a message queue
    int msgid = msgget(key, IPC_CREAT | 0666);
    if (msgid == -1) {
        perror("msgget");
        return 1;
    }

    // Fork a child process
    pid_t pid = fork();

    if (pid < 0) {
        fprintf(stderr, "Fork failed\n");
        return 1;
    } else if (pid == 0) {  // Child process
        // Send n to the parent process
        struct Message msg;
        msg.mtype = 1;  // Message type 1
        msg.data = n;

        if (msgsnd(msgid, &msg, sizeof(int), 0) == -1) {
            perror("msgsnd");
            return 1;
        }

        printf("Child process sent n = %d to parent process.\n", n);
    } else {  // Parent process
        // Receive n from the child process
        struct Message msg;
        if (msgrcv(msgid, &msg, sizeof(int), 1, 0) == -1) {
            perror("msgrcv");
            return 1;
        }

        int received_n = msg.data;

        // Calculate the sum of factorials
        long long sum = 0;
        for (int i = 1; i <= received_n; ++i) {
            sum += factorial(i);
        }

        // Send the sum to the child process
        msg.mtype = 2;  // Message type 2
        msg.data = sum;

        if (msgsnd(msgid, &msg, sizeof(long long), 0) == -1) {
            perror("msgsnd");
            return 1;
        }

        printf("Parent process received n = %d and calculated sum = %lld.\n", received_n, sum);
    }

    // Remove the message queue
    if (msgctl(msgid, IPC_RMID, NULL) == -1) {
        perror("msgctl");
        return 1;
    }

    return 0;
}
