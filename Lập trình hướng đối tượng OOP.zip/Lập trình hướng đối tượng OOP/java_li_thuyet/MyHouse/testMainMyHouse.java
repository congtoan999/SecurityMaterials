public class testMainMyHouse {
    public static void main(String[] args) {
        MyHouse m1 = new MyHouse("CT", 2.5, 4.3, 1);
        MyHouse m2 = new MyHouse("NT", 5, 12, 2);
        MyHouse h1 = new MyHouse("DT1", 25, 1,1 );
        MyHouse h2 = new MyHouse("NT", 1, 75, 1);
        MyHouse h3 = new MyHouse("DT1", 5, 5, 1);
        MyHouse h4 = new MyHouse(null, 5, 12, 2);

        System.out.println(m1.getDai());
        System.out.println(m1.getLocation());
        System.out.println(m1.getRong());
        System.out.println(m2.getSoTang());
        System.out.println(m2.getUsableArea());
        System.out.println(m2.calculateCompensationPrice());
        System.out.println(h1.equals(h2));
        System.out.println(h1.equals(h3));
        System.out.println(h1.equals(h4));
        m1.setLocation("Nt1");
        System.out.println(m1.getLocation());
    }

}
