public class MyHouse {
    private String location;
    private double dai;
    private double rong;
    private int soTang;

    public MyHouse() {
        this.location = "NT";
        this.dai = 15;
        this.rong = 5;
        this.soTang = 1;
    }

    public MyHouse(String location, double dai, double rong, int soTang) {
        this.location = location;
        this.dai = dai;
        this.rong = rong;
        this.soTang = soTang;
    }

    // get
    public String getLocation() {
        return location;
    }

    public double getDai() {
        return dai;
    }

    public double getRong() {
        return rong;
    }

    public int getSoTang() {
        return soTang;
    }

    // set
    public void setLocation(String location) {
        this.location = location;
    }

    public void setDai(double dai) {
        this.dai = dai;
    }

    public void setRong(double rong) {
        this.rong = rong;
    }

    public void setSoTang(int soTang) {
        this.soTang = soTang;
    }

    public double getUsableArea() {
        return dai * rong * soTang;
    }

    public double calculateCompensationPrice() {
        double ok = 0;
        if (location == "NT") {
            ok = rong * dai * soTang * 10;

        } else if (location == "DT2") {
            ok = rong * dai * soTang * 15;
        } else if (location == "DT1") {
            ok = rong * dai * rong * 30;
        }
        return ok;
    }

    public boolean equals(Object obj) {
        if (obj instanceof MyHouse) { // instanceof kiem tra xem obj co phai doi tuong khong
            MyHouse house = (MyHouse) obj;
            if (this.getLocation() == null || house.getLocation() == null) {
                return false;
            }
            double getCompensation = Math.abs(this.calculateCompensationPrice() - house.calculateCompensationPrice());
            if (getCompensation <= 50) {
                return true;
            }
        }
        return false;
    }
}
