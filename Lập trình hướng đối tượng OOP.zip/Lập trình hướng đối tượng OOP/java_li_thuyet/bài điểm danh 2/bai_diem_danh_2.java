import java.util.Scanner;

public class bai_diem_danh_2 {
    public static void main(String[] args) {
        double toan, van, anh, dtb = 0;
        Scanner sc = new Scanner(System.in);
        System.out.print("nhap diem toan = ");
        toan = sc.nextDouble();
        System.out.print("nhap diem van = ");
        van = sc.nextDouble();
        System.out.print("nhap diem anh = ");
        anh = sc.nextDouble();

        dtb = (toan * 2 + van + anh) / 4;
        diemA(dtb);
        diemB(dtb);
        diemC(dtb);
    }

    public static void diemA(double dtb) {
        if (dtb >= 8.0 && dtb <= 10.0) {
            System.out.print("A");
        }
    }

    public static void diemB(double dtb) {
        if (dtb >= 5.0 && dtb <= 8.0) {
            System.out.print("B");
        }
    }

    public static void diemC(double dtb) {
        if (dtb >= 0 && dtb < 5.0) {
            System.out.print("C");
        }
    }
}
