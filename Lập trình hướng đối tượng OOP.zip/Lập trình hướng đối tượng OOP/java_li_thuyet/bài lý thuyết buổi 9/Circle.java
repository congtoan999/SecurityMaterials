class Circle implements Shape{
    private double radius;
    public Circle(){
        radius = 1;
    }
    public double getArea(){
        return radius * radius * Math.PI;
    }
}