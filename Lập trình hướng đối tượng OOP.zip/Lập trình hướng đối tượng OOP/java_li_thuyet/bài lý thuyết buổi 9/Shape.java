interface Shape {
    float getArea();
}