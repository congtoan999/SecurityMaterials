class Main{
    public static void main(String[] args){
        Shape s = new Circle();
        System.out.println(s.getArea());
    }
}