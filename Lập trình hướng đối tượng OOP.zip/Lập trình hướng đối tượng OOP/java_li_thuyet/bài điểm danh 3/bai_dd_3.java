public class bai_dd_3 {
    public static int so_tu_trong_ten(String ten_day_du) {
        // String[] tu = ten_day_du.trim().split(" ") ==> trim() là xóa khảng cách đầu
        // và cuối
        String[] tu = ten_day_du.split(" "); // split(" ") dung để chia nhỏ các từ bởi khoảng trắng
                                             // tuy nhiên nếu ở đầu có khoảng trắng có thể tính khoảng trắng đầu
                                             // split("") tinh so ki tu
        return tu.length;
    }

    public static String getFirstName(String ten_day_du) {
        String[] tu = ten_day_du.split(" ");
        return tu[tu.length - 1]; // tu.length -1 là chỉ từ cuối chính là tên
    }

    public static String getLastName(String ten_day_du) {
        String[] tu = ten_day_du.split(" ");
        return tu[0];
    }

    public static String ten_dem(String ten_day_du) {
        String[] tu = ten_day_du.split(" ");
        String middleName = ""; // dùng để không lấy khoang cach dau va cuoi của ten lót
        int i;
        for (i = 1; i < tu.length - 1; i++) { // nếu i = 0 thì đó là tên họ
            middleName += tu[i] + " ";
        }
        return middleName;
    }

    public static String capitalizeName(String ten_day_du) {
        String[] tu = ten_day_du.split("\\s+");// nếu không có \\s+ thì cả chương trình dưới đều bị lỗi
        String capitalized = "";
        for (String word : tu) {
            String firstChar = word.substring(0, 1);
            String rest = word.substring(1);
            capitalized += firstChar.toUpperCase() + rest.toLowerCase() + " ";
        }
        return capitalized;
    }

    public static String formalizeName(String ten_day_du) {
        String[] tu = ten_day_du.split("\\s+");// nếu không có \\s+ thì cả chương trình dưới đều bị lỗi
        String formalized = "";
        for (String word : tu) {
            formalized += word + " ";
        }
        return formalized;
    }

    public static void main(String[] args) {
        String ten_day_du = "Nguyen  tran    minh Tuan";
        int so_tu = so_tu_trong_ten(ten_day_du);
        System.out.println("Số từ trong tên đầy đủ là: " + so_tu);

        String firstName = getFirstName(ten_day_du);
        System.out.println("Tên là: " + firstName);

        String lastName = getLastName(ten_day_du);
        System.out.println("ho la : " + lastName);

        String middleName = ten_dem(ten_day_du);
        System.out.println("ten lot la : " + middleName);

        String capitalized = capitalizeName(ten_day_du);
        System.out.println("sau khi viet hoa chu cai dau : " + capitalized);

        String formalized = formalizeName(ten_day_du);
        System.out.println("sau khi xoa khoang cach : " + formalized);

    }
}
