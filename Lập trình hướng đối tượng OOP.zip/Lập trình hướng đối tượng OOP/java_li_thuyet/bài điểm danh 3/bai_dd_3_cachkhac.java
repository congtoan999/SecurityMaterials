public class bai_dd_3_cachkhac {
    private String name;

    public bai_dd_3_cachkhac(String name) {
        this.name = name;
    }

    public int countWords() {
        String[] words = name.trim().split("\\s+");
        return words.length;
    }

    public String getFirstName() {
        String[] words = name.trim().split("\\s+");
        return words[words.length - 1];
    }

    public String getLastName() {
        String[] words = name.trim().split("\\s+");
        return words[0];
    }

    public String getMiddleName() {
        String[] words = name.trim().split("\\s+");
        String middleName = "";
        for (int i = 1; i < words.length - 1; i++) {
            middleName += words[i] + " ";
        }
        return middleName.trim();
    }

    public String capitalizeName() {
        String[] words = name.trim().split("\\s+");
        String capitalized = "";
        for (String word : words) {
            String firstChar = word.substring(0, 1);
            String rest = word.substring(1);
            capitalized += firstChar.toUpperCase() + rest.toLowerCase() + " ";
        }
        return capitalized.trim();
    }

    public String formalizeName() {
        String[] words = name.trim().split("\\s+");
        String formalized = "";
        for (String word : words) {
            formalized += word + " ";
        }
        return formalized.trim();
    }

    public static void main(String[] args) {
        bai_dd_3_cachkhac name = new bai_dd_3_cachkhac("  Nguyen   tran    minh Tuan   ");
        System.out.println("Count words: " + name.countWords()); // Count words: 4
        System.out.println("First name: " + name.getFirstName()); // First name: Tuan
        System.out.println("Last name: " + name.getLastName()); // Last name: Nguyen
        System.out.println("Middle name: " + name.getMiddleName()); // Middle name: Tran Minh
        System.out.println("Capitalized name: " + name.capitalizeName()); // Capitalized name: Nguyen Tran Minh Tuan
        System.out.println("Formalized name: " + name.formalizeName()); // Formalized name: Nguyen Tran Minh Tuan
    }
}
