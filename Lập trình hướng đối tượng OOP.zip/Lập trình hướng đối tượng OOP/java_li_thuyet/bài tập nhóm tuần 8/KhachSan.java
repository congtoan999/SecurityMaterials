class KhachSan extends DichVuLuuTru {
    private String tenKS;
    private int soSao;
    public KhachSan(String viTri, double giaCoBan, String tenKS, int soSao) {
        super(viTri, giaCoBan);
        this.tenKS = tenKS;
        this.soSao = soSao;
    }
    public double tinhGiaThueCoBan() {
        double giaThue = 0.0;
        if (soSao <= 2) {
            giaThue = giaCoBan;
        } else {
            giaThue = giaCoBan * 1.1;
        } 
        return giaThue + tinhThue() * giaThue;
    }
}