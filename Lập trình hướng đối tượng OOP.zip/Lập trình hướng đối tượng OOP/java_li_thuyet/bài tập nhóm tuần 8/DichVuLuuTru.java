abstract class DichVuLuuTru {
    protected String viTri;
    protected double giaCoBan;
    public DichVuLuuTru (String viTri, double giaCoBan) {
        this.viTri = viTri;
        this.giaCoBan = giaCoBan;
    }
    public double tinhThue() {
        double b = 0.0;
        if (viTri.equals("Vung Tau") == true || viTri.equals("Nha Trang") == true) {
            b = 0.1;
        } else b = 0.05;
        return b;
    }
    public abstract double tinhGiaThueCoBan();

    
}