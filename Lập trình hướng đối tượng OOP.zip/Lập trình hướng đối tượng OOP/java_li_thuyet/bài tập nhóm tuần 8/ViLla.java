class ViLla extends DichVuLuuTru {
    private String tenViLla;
    private int soPhongNgu;
    public ViLla(String viTri, double giaCoBan, String tenViLla, int soPhongNgu) 
    {
        super(viTri, giaCoBan);
        this.tenViLla = tenViLla;
        this.soPhongNgu = soPhongNgu;
    }
    public double tinhGiaThueCoBan() {
        double giaThueCoBan = 0.0;
        if (soPhongNgu <= 2) {
            giaThueCoBan = giaCoBan + 3000000;
        } else if (soPhongNgu <= 5) {
            giaThueCoBan = giaCoBan + 3000000 + (soPhongNgu - 3) * 2000000;
        } else {
            giaThueCoBan = giaCoBan + 3000000 + (soPhongNgu - 3) * 2000000 + (soPhongNgu - 5) * 1000000;
        }
        return giaThueCoBan;
    }
}