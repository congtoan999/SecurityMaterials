class Tivi{
    protected String maTV;
    protected String hang;
    protected int Soinche;
    protected int giaNhap;
    
    public Tivi(){
        this.maTV = "TV123";
        this.hang = "Sony";
        this.Soinche = 40 ;
    }  
    
    public Tivi(String maTV, String hang, int Soinche, int giaNhap){
        this.maTV = maTV ;
        this.hang = hang ;
        if (Soinche != 32 && Soinche != 40 && Soinche != 43 && Soinche != 49 && Soinche != 50 && Soinche != 55){ //&& do de use dau phay
            this.Soinche = 32;
        }else{
            this.Soinche = Soinche;
        }
        this.giaNhap = giaNhap;
    }

    public String toString (){
        return "[ "+maTV+", " + hang+", " + Soinche+", " + giaNhap + " ]";
    }
}