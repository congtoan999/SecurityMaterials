class TiviTM extends Tivi{
    private int heMau;
    private String mauHinh;

    public TiviTM(){
        this.maTV = "TV123";
        this.hang = "Sony";
        this.Soinche = 40 ;
        this.heMau = 8;
        this.mauHinh = "4K";
    
    }

    public TiviTM (String maTV, String hang, int Soinche,int giaNhap , int heMau, String mauHinh){
        super (maTV,hang,Soinche,giaNhap);
        if (heMau == 8 || heMau == 16 || heMau == 32){
            this.heMau = heMau;
        }
        else{
            this.heMau = 32;
        }
        this.mauHinh = mauHinh;
    }

    public String toString(){
        return "[ " + maTV+", " + hang+", " + Soinche+", " + giaNhap +", "+heMau + ", "+ mauHinh +" ]"; 
    }
}