// kiem tra mot so xuat du lieu dung sai neu la so nguyen to
//  so nguyen to 2 3 5 7 ...

import java.util.Scanner;

public class ktra_so_nguyen_to {
    public static void main(String[] args) {
        int n, i, j;
        Scanner sc = new Scanner(System.in);
        System.out.print("nhap n = ");
        n = sc.nextInt();

        for (i = 2; i <= n; i++) {
            for (j = 2; j < i; j++) {
                if (i % j == 0) {
                    break;
                }
            }
            if (i == j) {
                System.out.print(" " + i);
            }

        }

    }
}
