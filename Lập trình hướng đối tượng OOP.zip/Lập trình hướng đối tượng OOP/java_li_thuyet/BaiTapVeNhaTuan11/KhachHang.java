abstract class KhachHang{
    protected String maKH,tenKH;
    protected int diemTichLuy;

    public KhachHang(String maKH, String tenKH , int diemTichLuy){
        this.maKH = maKH ;
        this.tenKH = tenKH;
        this.diemTichLuy = diemTichLuy;
    }

    public String toString(){
        return maKH +" - "+ tenKH + " - "+ diemTichLuy;
    }

    abstract void tinhDiemTichLuy(int money);

    public int getDiemTichLuy(){
        return diemTichLuy;
    }
}