class WrongClassOfCard extends Exception {
    public WrongClassOfCard() {
        super();
    }

    public WrongClassOfCard(String s) {
        super(s);
    }
}

class KHTT extends KhachHang {
    private String rank;

    public KHTT(String maKH, String tenKH, int diemTichLuy, String rank) throws WrongClassOfCard {
        super(maKH, tenKH, diemTichLuy);
        if (rank.equals("Kim Cuong") || rank.equals("Vang") || rank.equals("Bac")) {
            this.rank = rank;
        } else {
            throw new WrongClassOfCard(rank + " không hợp lệ");
        }
    }

    public void tinhDiemTichLuy(int money) {
        if (rank.equals("Kim Cuong")) {
            super.diemTichLuy += (money / 10000) + 4;
        } else if (rank.equals("Vang")) {
            super.diemTichLuy += (money / 10000) + 3;
        } else {
            super.diemTichLuy += (money / 10000) + 2;
        }
    }
}
