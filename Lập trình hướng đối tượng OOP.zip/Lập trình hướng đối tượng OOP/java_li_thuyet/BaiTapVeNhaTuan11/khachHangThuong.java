class KhachHangTHuong extends KhachHang{
    private int thangConLai;
    public KhachHangTHuong(String maKH, String tenKH, int diemTichLuy, int thangConLai){
        super(maKH,tenKH,diemTichLuy);
        this.thangConLai = thangConLai;
    }

    public void tinhDiemTichLuy(int tienMatHang){
        if(diemTichLuy >= 100 && thangConLai > 12){
            diemTichLuy += (tienMatHang/10000)*2;
        }
        else{
            diemTichLuy += tienMatHang/10000;
        }
    }
}