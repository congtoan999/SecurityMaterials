import java.util.ArrayList;

public class Test {
    public static void main(String[] args) {
        ArrayList<KhachHang> list = new ArrayList<KhachHang>();
        try {
            list.add(new KhachHangThuong("1", "A", 100, 2));
            list.add(new KHTT("2", "B", 100, "Vang"));
            list.add(new KHTT("3", "C", 200, "Bac"));
            list.add(new KHTT("4", "D", 300, "Kim Cuong"));
            list.add(new KhachHangThuong("5", "E", 300, 50, 4));
        } catch (WrongClassOfCard e) {
            System.out.println(e);
        }

        KhachHang a = null;
        int max = Integer.MIN_VALUE;

        for (KhachHang kh : list) {
            kh.tinhDiemTichLuy();
            if (kh.getDiemTichLuy() > max) {
                max = kh.getDiemTichLuy();
                a = kh;
            }
        }

        if (a != null) {
            System.out.println("KhachHang co diem tich luy cao nhat:");
            System.out.println("Ma: " + a.MaKH());
            System.out.println("Ten: " + a.tenKH());
            System.out.println("Diem tich luy: " + a.getDiemTichLuy());
        } else {
            System.out.println("Khong co KhachHang nao trong danh sach.");
        }
    }
}
