// 4/1 - 4/3 + 4/5 - 4/7 + ... - ... 

import java.util.Scanner;

public class tinh_toan {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n, i;
        double tong = 0;
        System.out.print("nhap n = ");
        n = sc.nextInt();
        sc.close();

        for (i = 0; i < n; i++) {
            // tong = 4.0 / (2*i+1);
            if (i % 2 == 0) {
                tong += 4.0 / (2 * i + 1);
            }
            if (i % 2 != 0) {
                tong += -4.0 / (2 * i + 1);
            }
        }
        System.out.print("tong = " + tong);

    }

}
