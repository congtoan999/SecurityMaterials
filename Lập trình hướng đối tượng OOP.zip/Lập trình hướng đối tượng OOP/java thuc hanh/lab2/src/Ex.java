import java.util.Scanner;
import java.util.Arrays;
import java.math.BigDecimal;

public class Ex {

    // cau 1
    public static int findMax(int arr[]) {

        int max = arr[0];
        for (int i = 0; i < arr.length; i++) {
            if (max < arr[i]) {
                max = arr[i];
            }

        }
        return max;
    }

    // cau 2
    public static int findMin(int arr[]) {
        int min = arr[0];
        for (int i = 0; i < arr.length; i++) {
            if (min > arr[i]) {
                min = arr[i];
            }

        }
        return min;
    }

    // cua 3
    public static int findTotalEven(int arr[]) {
        int tong = 0;
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] % 2 == 0) {
                tong += arr[i];
            }

        }
        return tong;
    }

    // cau 4
    public static int findSpecificElements(int arr[]) {
        return arr.length;
    }

    // cau 5
    public static boolean isPrime(int n) { // ktra 1 so co phai nguyen to khong
        if (n < 2) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(n); i++) {// n = 9 ==> i=2,3
            if (n % i == 0) {
                return false;
            }
        }
        return true;
    }

    public static int countPrime(int[] arr) {
        int count = 0;
        for (int i = 0; i < arr.length; i++) {
            if (isPrime(arr[i])) { // mac dinh la = true
                count++;
            }
        }
        return count;
    }

    // cau 6
    public static int find(int arr[], int k) {

        for (int i = 0; i < arr.length; i++) {
            if (k == arr[i]) {
                return i;
            }
        }
        return -1;
    }

    // cau 7
    public static void square(int arr[]) {
        for (int i = 0; i < arr.length; i++) {
            arr[i] = arr[i] * arr[i];
        }

    }

    // cau 8
    public static BigDecimal findMax(BigDecimal[] arr) {
        BigDecimal max = arr[0];
        for (int i = 1; i < arr.length; i++) {
            if (arr[i].compareTo(max) > 0) {
                max = arr[i];
            }

        }
        return max;
    }

    // cau 9
    public static int[] divisibleNumbers(int arr[], int k) {
        int count = 0;
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] % k == 0) {
                count++;
            }
        }

        int[] result = new int[count]; // tao mot mang nguyen moi co result co kich thuoc count
        int index = 0;
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] % k == 0) {
                result[index] = arr[i];
                index++;
            }
        }
        return result;
    }

    // cau 10
    public static int so_lon_thu_3(int[] arr) {
        // if (arr.length < 3)
        // {
        // System.out.println("kich thuoc mang nho hon 3 : ");
        // return -1 ;
        // }

        Arrays.sort(arr);
        return arr[arr.length - 3]; // arr.length -1 so nho thu 3 trong mang ko ke trung lap
    }

    public static void main(String[] args) {
        int[] arr = { 1, 0, 8, 4, 7, 2, 2, 2, 3, 2, 6, 3, 8, 8, 1, 1 }; // co the doi arr o day thanh bat ki chu gi
        // cau 1
        System.out.println("so max : " + findMax(arr));
        // cau 2
        System.out.println("ex2 so min : " + findMin(arr));

        // cau 3
        System.out.println("ex3 tong chan : " + findTotalEven(arr));

        // cau 4
        Scanner sc = new Scanner(System.in);
        System.out.println("ex4 : " + findSpecificElements(arr));

        // cau 5
        System.out.println("ex5 so lan xuat hien so nguyen to : " + countPrime(arr));

        // cau 6
        System.out.println("Nhap vao key = ");
        int k = sc.nextInt();
        System.out.println("ex6 vi tri " + k + " la : " + find(arr, k));

        // cau 7
        square(arr);
        System.out.println("cau 7 : " + Arrays.toString(arr));

        // cau 8
        BigDecimal[] ar = { BigDecimal.valueOf(3.14), BigDecimal.valueOf(2.71),
                // BigDecimal.valuaOf chuyen tu kieu double valuaOf thanh BigDecimal
                BigDecimal.valueOf(1.23),
                BigDecimal.valueOf(4.12), BigDecimal.valueOf(9.14), BigDecimal.valueOf(0.13)
        };
        System.out.println("ex8 maximum value is " + findMax(ar));

        // cau 9
        int[] arrr = { 1, 2, 3, 4, 5, 6, 7 };
        System.out.println("Nhap vao key = ");
        k = sc.nextInt(); // k chi duoc nhan kieu du lieu mot lan (int) thoi
        System.out.println("ex9 mang so chia het cho " + k + " la : ");
        for (int i = 0; i < divisibleNumbers(arrr, k).length; i++) {// leng khong () do tra ve mang so nguyen
            System.out.print(divisibleNumbers(arrr, k)[i] + " ");
        }
        sc.close();

        // cau 10
        System.out.println();
        System.out.println("ex 10 so lon thu 3 trong mang la : " + so_lon_thu_3(arr));
    }
}