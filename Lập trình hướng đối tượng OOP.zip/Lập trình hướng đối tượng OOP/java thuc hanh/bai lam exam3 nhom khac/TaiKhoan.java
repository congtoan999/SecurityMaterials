import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class TaiKhoan {
    private String tenDangNhap;
    private String matKhau;
    private String ngayTao;

    public TaiKhoan(String tenDangNhap, String matKhau, String ngayTao) {
        this.tenDangNhap = tenDangNhap;
        this.matKhau = matKhau;
        this.ngayTao = ngayTao;
    }

    public String getTenDangNhap() {
        return tenDangNhap;
    }

    public boolean kiemTraDangNhap(String matKhau) {
        return this.matKhau.equals(matKhau);
    }

    public boolean doiMatKhau(String matKhauCu, String matKhauMoi) {
        if (kiemTraDangNhap(matKhauCu)) {
            this.matKhau = matKhauMoi;
            return true;
        }
        return false;
    }

    public String toString() {
        return tenDangNhap + " - " + matKhau + " - " + ngayTao;
    }
}
