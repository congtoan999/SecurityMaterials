class XuLyTaiKhoan {
    private TaiKhoan taiKhoan;

    public XuLyTaiKhoan(String tenDangNhap, String matKhau) {
        QuanLyTaiKhoan qltk = new QuanLyTaiKhoan("danhSachTaiKhoan.txt");
        taiKhoan = qltk.dangNhap(tenDangNhap, matKhau);
    }

    public boolean kiemTraDangNhap() {
        return taiKhoan != null;
    }

    public boolean doiMatKhau(String matKhauCu, String matKhauMoi) {
        if (taiKhoan != null && taiKhoan.kiemTraDangNhap(matKhauCu)) {
            return taiKhoan.doiMatKhau(matKhauCu, matKhauMoi);
        }
        return false;
    }

    public boolean congDiemThuong(int diemThuong) {
        if (taiKhoan != null && taiKhoan instanceof TaiKhoanVIP) {
            TaiKhoanVIP tkVIP = (TaiKhoanVIP) taiKhoan;
            return tkVIP.congDiemThuong(diemThuong);
        }
        return false;
    }

    public String inThongTin() {
        if (taiKhoan != null) {
            return taiKhoan.toString();
        }
        return "Dang nhap that bai";
    }
}
