import java.text.SimpleDateFormat;

public class TaiKhoanVIP extends TaiKhoan {
    private int diemThuong;

    public TaiKhoanVIP(String tenDangNhap, String matKhau, String ngayTao) {
        super(tenDangNhap, matKhau, ngayTao);
        this.diemThuong = 0;
    }

    public int getDiemThuong() {
        return diemThuong;
    }

    public boolean congDiemThuong(int diem) {
        if (diem > 0) {
            diemThuong += diem;
            return true;
        }
        return false;
    }

    @Override
    public String toString() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        String ngayTaoFormatted = dateFormat.format(ngayTao);
        return tenDangNhap + " - " + matKhau + " - " + ngayTaoFormatted + " - " + diemThuong;
    }
}
