public class Test {
    public static void main(String[] args) {
        IceCream ic = new IceCream("Vanilla" , 200,4);
        IceCream ic1 = new IceCream("Mango" , 200,4);
        
        System.out.println(ic.totalCost(2));
        System.out.println(ic1.totalCost(3));
    }
}
