class nhap{
	public static int sumEvenPos(int a[]) {
        int count = 0;
		for (int i = 0 ; i<a.length;i++){
            if (i%2 == 0){
                count += a[i];
            }
        }
        return count;
	}
	
	public static String lowerCaseCharacters(String str){
		String s = str;
        String[] tu = s.split("\\s+");
        String kq = "";
        
        for (String word : tu){
           String first = word.substring(0,1);
           String last = word.substring(1);
           kq += first.toUpperCase() + last.toLowerCase() + " ";
        }
		return kq;
	} 
	
	public static void main(String[] args){		
		int a[] = {1,-2,3,1,-2,6};
		System.out.println(sumEvenPos(a));
		String s = "TrUOng DAi Hoc Ton DuC ThAnG";
		System.out.println(lowerCaseCharacters(s));
	}
}