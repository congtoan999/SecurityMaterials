class HaiSan extends MatHang{
    private String loaiHaiSan;

    public HaiSan(String maMH,String tenMH,double giaMH,String loaiHaiSan){
        super(maMH, tenMH, giaMH);
        this.loaiHaiSan = loaiHaiSan;
    }
    public double chietKhauUuDai(){
        if (loaiHaiSan.equals("Tom")  || loaiHaiSan.equals("Cua") ){
            return giaMH * 0.02;
        }
        return 0;

        
    }
    public double tinhKhuyenMai(int soLuong){
        if (soLuong<= 5){
            return 0.0;
        }
        return 0.05 * super.tinhGiaBan(soLuong) +chietKhauUuDai();
    }
}
