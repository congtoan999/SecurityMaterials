class NongSan extends MatHang{
    private String loaiNongSan;
    
    public NongSan(String maMH,String tenMH,double giaMH,String loaiNongSan){
        super(maMH, tenMH, giaMH);
        this.loaiNongSan = loaiNongSan;
    }
    public double tinhThue(){
        if (loaiNongSan.equals("Bap Cai" )|| loaiNongSan.equals("Ca Chua") ){
            return 0.1;
        }
        return 0.05;
    }
    public double tinhGiaBan(int soLuong){
        return super.tinhGiaBan(soLuong) + tinhThue()* super.tinhGiaBan(soLuong);
    }
    public double tinhKhuyenMai(int soLuong){
        return 0.1 * tinhGiaBan(soLuong);
    }
}