abstract class MatHang{
    protected String maMH;
    protected String tenMH;
    protected double giaMH;
    public MatHang(String maMH,String tenMH , double giaMH){
        this.maMH = maMH;
        this.tenMH = tenMH;
        this.giaMH = giaMH;
    }
    public double tinhGiaBan(int soLuong){
        return giaMH * soLuong;
    }
    public abstract double tinhKhuyenMai(int soLuong);
    
    public double tinhTongGiaBan(int soLuong){
        if(maMH.charAt(0) == 'T' && maMH.charAt(1) == 'K'){
            return tinhGiaBan(soLuong)- tinhKhuyenMai(soLuong) -0.02*(tinhGiaBan(soLuong)-tinhKhuyenMai(soLuong));
        }
        return tinhGiaBan(soLuong) - tinhKhuyenMai(soLuong);
    }
}
