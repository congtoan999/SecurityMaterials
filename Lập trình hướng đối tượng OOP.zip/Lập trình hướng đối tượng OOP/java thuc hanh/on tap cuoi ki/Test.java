class Test{
    public static void main(String[] args){
        GiaiKhat g = new GiaiKhat("01a","cola","thung",12,23.4);
        System.out.println(g.toString());
    }
}