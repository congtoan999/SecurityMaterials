public class ok {
    protected int i;

    public void mai() {
        System.out.print("xin chao");

    }
    public class k {
        int i = 0;
        public void d() {
           
            mai();
        }
    }
}