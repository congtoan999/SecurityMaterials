class KH{
    protected String maKH;
    protected String tenKH;
    protected String sex;
    protected String diaChi;
    protected int soLuong;
    protected double donGia;

    public KH(){
        maKH = "";
        tenKH = "";
        sex = "";
        diaChi = "";
        soLuong = 0;
        donGia = 0;
    }

    public KH(String maKH, String tenKH, String sex, String diaChi, int soLuong, double donGia){
        this.maKH = maKH;
        this.tenKH = tenKH;
        this.sex = sex;
        this.diaChi = diaChi;
        this.soLuong = soLuong;
        this.donGia = donGia;
    }

    public String getMaKH(){
        return maKH;
    }

    public String getTenKH(){
        return tenKH;
    }

    public String getSex(){
        return sex;
    }
    public String getDiaChi(){
        return diaChi;
    }
    public int getSoLuong(){
        return soLuong;
    }

    public double getDonGia(){
        return donGia;
    }

    
    public void setMaKH(String maKH){
        this.maKH = maKH;
    }

    public void setTenKH(String tenKH){
        this.tenKH = tenKH;
    }

    public void setSex(String sex){
        this.sex = sex;
    }

    public void setDiaChi(String diaChi){
        this.diaChi = diaChi;
    }
    public void setSoLuong(int soLuong){
        this.soLuong = soLuong;
    }
    public void setDonGia(double donGia){
        this.donGia = donGia;
    }

    public String toString(){
        return maKH +" - "+ tenKH +" - "+ sex+" - "+ diaChi +" - "+soLuong +" - "+donGia;
    }
}