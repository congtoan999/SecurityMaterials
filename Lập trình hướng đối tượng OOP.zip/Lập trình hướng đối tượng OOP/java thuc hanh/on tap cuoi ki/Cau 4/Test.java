import java.util.ArrayList;


public class Test {
    public static void main(String[] args) {
        ArrayList<KH> lst = new ArrayList<>();

        // Thêm khách hàng mới
        KHMoi newCustomer = new KHMoi("CUS001", "Nguyen Van A", "Male", "123 Street, HCM City", 10, 2000);
        lst.add(newCustomer);


        // Thêm khách hàng thân thiết
        KHThanThiet loyalCustomer = new KHThanThiet("CUS002", "Nguyen Thi B", "Female", "456 Street, HCM City", 40, 1500);
        lst.add(loyalCustomer);

        // Thêm khách hàng VIP
        KHVip vipCustomer = new KHVip("CUS003", "Tran Van C", "Male", "789 Street, HCM City", 50, 1800);
        lst.add(vipCustomer);

        System.out.println("Danh sách khách hàng:");
        for (KH khachHang : lst) {
            System.out.println(khachHang.toString());
        }
    }
}