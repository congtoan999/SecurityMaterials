class KHMoi extends KH{
    public KHMoi(String maKH, String tenKH, String sex, String diaChi, int soLuong, double donGia){
        super(maKH, tenKH, sex,  diaChi, soLuong, donGia);
    }
    public double thanhTien(){
        return super.soLuong *super.donGia;
    }

    public String toString(){
        return super.toString() +" - "+thanhTien();
    }
}