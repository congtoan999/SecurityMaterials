class KHThanThiet extends KH{
    public KHThanThiet(String maKH, String tenKH, String sex, String diaChi, int soLuong, double donGia){
        super(maKH, tenKH, sex, diaChi, soLuong, donGia);
    }

    public double tongTien(){
        if(super.soLuong == 30){
            return 29 * super.donGia;
        }
        return super.soLuong * super.donGia;
    }

    public double thanhTien(){
        double thanhTien = 0;
        while(super.soLuong > 30){
            thanhTien = 29 *  super.donGia;
            super.soLuong -= 30;
        }
        return super.soLuong * super.donGia;
    }

    public double sauChietKhau(){
        return thanhTien() - thanhTien() * 0.05;
    }

    public String toString(){
        return super.toString() +" - "+tongTien() +" -" +thanhTien() + " - "+sauChietKhau();
    }
}   