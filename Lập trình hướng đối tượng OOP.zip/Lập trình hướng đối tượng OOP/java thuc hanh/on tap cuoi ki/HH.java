class HH{
    protected String maH;
    protected String tenHang;
    
    public HH(){
        this.maH = "";
        this.tenHang = "";
    }

    public HH(String maH , String tenHang){
        if(isĐK(maH)){
            this.maH = maH;
        }
        else{
            this.maH = "HH001";
        }
        this.tenHang = tenHang;
    }

    private boolean isĐK(String maH){
        if(maH.length()  == 5){
            return true;
        }
        else if(maH.substring(0,2).equals("HH")){
            return true;
        }
        try{
            int num = Integer.parseInt(maH.substring(2));
            return true;
        }
        catch(Exception e){
            return false; 
        }
    }

    public String toString(){
        return maH +" - "+ tenHang;
    }
}