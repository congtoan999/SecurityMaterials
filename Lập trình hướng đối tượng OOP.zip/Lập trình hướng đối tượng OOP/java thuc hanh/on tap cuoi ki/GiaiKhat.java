class GiaiKhat extends HH{
    private String donVi;
    private int soLuong;
    private double donGia;

    public GiaiKhat(String maH, String tenHang, String donVi,int soLuong, double donGia){
        super(maH,tenHang);
        if(donVi.equals("ket") || donVi.equals("thung") || donVi.equals("chai") || donVi.equals("lon")){
            this.donVi = donVi;
        }else{
            this.donVi = "ket";

        }
        this.soLuong = soLuong;
        this.donGia = donGia;

       
    }
    public String toString(){
        return super.toString() + " - "+ donVi+" - "+ soLuong+" - "+ donGia+" - "+ tongTien(donVi);
    }

    public double tongTien(String donVi){
        double thanhTien = 0;
        double tiLeChietKhau = 0.5;
        if(donVi.equals("ket")|| donVi.equals("thung")){
            thanhTien = soLuong * donGia;
        }
        else if(donVi.equals("chai")){
            thanhTien = soLuong * donGia / 20.0;
        }
        else if(donVi.equals("lon")){
            thanhTien = soLuong * donGia /24.0;
        }
        return thanhTien + tiLeChietKhau;
    }
}