package anonymousClass;

public class Main {
    public static void main(String[] args) {
        Run r = new Run() {
            public void run() {
                System.out.println("dang chay !!!");
            }
        };
        Animal a = new Animal() {
            public void keu() {
                System.out.println("gau gau !!");
            }
        };

        r.run();
        a.keu();
    }
}

interface Run {
    public void run();
}

abstract class Animal {
    public abstract void keu();
}
