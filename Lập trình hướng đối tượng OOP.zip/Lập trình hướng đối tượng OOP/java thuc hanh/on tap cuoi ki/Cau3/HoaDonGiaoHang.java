package Cau3;

public class HoaDonGiaoHang extends HoaDon {
    private String diaChi;
    private double khoangCach;
    private double thoiGianGiao;

    public HoaDonGiaoHang() {
        super();
        this.diaChi = "Q.Tan Phu";
        this.khoangCach = 20;
        this.thoiGianGiao = 24;
    }

    public double tinhThanhTien() {
        if (thoiGianGiao < 24) {
            if (khoangCach < 10) {
                return super.tinhThanhTien() + 20 * khoangCach * super.soLuong;
            }
            if (khoangCach >= 10) {
                return super.tinhThanhTien() + 18 * khoangCach * super.soLuong;
            }
        }
        return super.tinhThanhTien() + 150000;
    }

    public String xuatThongTin() {
        return super.xuatThongTin() + " - " + diaChi + " - " + khoangCach + " - " + thoiGianGiao + " - "
                + tinhThanhTien();
    }
}
