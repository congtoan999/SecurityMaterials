package Cau3; /// bo ngoai packed chay duoc het

public class Test {
    public static void main(String[] args) {
        HoaDon hoaDon = new HoaDon();
        hoaDon.xuatThongTin();
        System.out.println(hoaDon.xuatThongTin());

        System.out.println("----------------------");

        HoaDonGiaoHang hoaDonGiaoHang = new HoaDonGiaoHang();
        hoaDonGiaoHang.xuatThongTin();
        System.out.println(hoaDonGiaoHang.xuatThongTin());
    }
}
