package Cau3;

public class HoaDon {
    protected String maHoaDon;
    protected String ngayLapHoaDon;
    protected String nguoiBan;
    protected String nguoiMua;
    protected String tenSanPham;
    protected int soLuong;
    protected double donGia;

    public HoaDon() {
        maHoaDon = "HD001";
        nguoiBan = "Nguyen Hoang";
        nguoiMua = "Nguyen Cong Toan";
        tenSanPham = "But bi Thien Long";
        soLuong = 20;
        donGia = 2500;
    }

    public double tinhThanhTien() {
        if (soLuong > 1000) {
            return soLuong * donGia - 0.04 * donGia * soLuong;
        }
        return soLuong * donGia;
    }

    public double tinhThue() {
        return tinhThanhTien() * 0.1;
    }

    public double tinhTongTien() {
        return tinhThanhTien() - tinhThue();
    }

    public String xuatThongTin() {
        return maHoaDon + " - " + tenSanPham + " - " + nguoiMua + " - " + soLuong + " - " + donGia + " - "
                + tinhThanhTien() + " - " + tinhThue() + " - " + tinhTongTien();
    }
}