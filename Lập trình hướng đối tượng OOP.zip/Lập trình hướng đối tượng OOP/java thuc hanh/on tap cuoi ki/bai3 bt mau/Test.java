class Test{
    public static void main(String[] args){
        Student s = new Student(23,"Nguyen","Toan");

        System.out.println(s.toString());
    }
}