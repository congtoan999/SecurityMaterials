class Tinh{
    public static void main(String[] args)
{
 int i=1, k=0;
 for (; i<5; i++)
k++;
 System.out.println(k);
}
}