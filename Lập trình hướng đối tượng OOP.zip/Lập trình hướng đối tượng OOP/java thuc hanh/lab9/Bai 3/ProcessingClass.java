import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
class ProcessingClass {
    public static ArrayList<Student> findStudent(ArrayList<Student> l) {
        ArrayList<Student> result = new ArrayList<>();

        for (Student student : l) {
            String rank = student.getRank();

            if (rank.equals("A") || rank.equals("Passed")) {
                result.add(student);
            }
        }
        return result;
    }

    public static <E> boolean writeFile(String path, ArrayList<E> lst) {//writeFile là mot phương thuc tinh (static) trong lớp ProcessingClass
        //lst là một ArrayList generic chứa các đối tượng kiểu E (bất kỳ kiểu dữ liệu nào)
        
        try {
            FileWriter writer = new FileWriter(path);//thuc hien viec ghi du lieu lst vao path

            for (E item : lst) {
                writer.write(item.toString() + "\n");
            }

            writer.close();//dong doi tuong writer
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static void main(String[] args) {
        ArrayList<Student> l = new ArrayList<>();
        l.add(new ITStudent("Alice", 9.0, 12345));
        l.add(new MathStudent("Bob", 4.5, "M123"));

        ArrayList<Student> result = findStudent(l);

        if (writeFile("output.txt", result)) {
            System.out.println("Write to file successful.");
        } else {
            System.out.println("Error writing to file.");
        }
    }
}