import java.util.*;
import java.io.*;


class Main{
    public static void main(String[] args){
        try{
            File inputFile = new File("input.txt");//File thuoc lop java.io
            
            Scanner sc = new Scanner(inputFile);//inputFile là một đối tượng của lớp File
                                                     //System.in su dung cung voi Scanner de doc du lieu
                 
            StringBuilder stringBuilder = new StringBuilder();//StringBuilder nam trong goi java.lang
            // StringBuilder cung cấp các phương thức để thay đổi nội dung của chuỗi một cách hiệu quả
            // mà không tạo ra các đối tượng chuỗi mới mỗi lần thực hiện thay đổi
            //Điều này giúp tăng hiệu suất so với việc sử dụng String thông thường.
           
            while(sc.hasNextLine()){//hasNextLine() là một phương thức Scanner
                // trả về true nếu có dòng dữ liệu tiếp theo, và false nếu không còn dòng dữ liệu

                String line = sc.nextLine();
                stringBuilder.append(line.toUpperCase());
                stringBuilder.append("\n");
                // append() cũng ném ra ngoại lệ IOException nếu có lỗi 
            }
            sc.close();

            File outputFile = new File("output.txt");
            outputFile.createNewFile();//creatNewFile co tac dung tao tep tin moi 
            //neu da ton tai tra ve flase , khong true
            
            FileWriter f = new FileWriter(outputFile);
            f.write(stringBuilder.toString());
            f.close();

            System.out.println("da viet hoa tat ca noi dung tu tep ");
        
        }  catch(IOException e){
            System.out.println("loi: "+e.getMessage());
        }          
    }
}