public class CalculatorTest {
    public static void main(String[] args) {
        Calculator calculator = new Calculator();

        try {// try-catch dung de xu li cac ngoai le
            double result = calculator.divide(10, 2);
            System.out.println("Result: " + result);
        } catch (ArithmeticException e) {//e dung de truy cap thong tin ve ngoai le
            System.out.println("Exception: " + e.getMessage());
        } catch (NumberOutOfRangeException e) {
            System.out.println("Exception: " + e.getMessage());
        }

        try {
            double result = calculator.divide(5, 0);
            System.out.println("Result: " + result);
        } catch (ArithmeticException e) {
            System.out.println("Exception: " + e.getMessage());
        } catch (NumberOutOfRangeException e) {
            System.out.println("Exception: " + e.getMessage());
        }

        try {
            double result = calculator.divide(2000, 500);
            System.out.println("Result: " + result);
        } catch (ArithmeticException e) {
            System.out.println("Exception: " + e.getMessage());
        } catch (NumberOutOfRangeException e) {
            System.out.println("Exception: " + e.getMessage());
        }
    }
}