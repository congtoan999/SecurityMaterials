class Calculator {
    public double divide(int a, int b) throws ArithmeticException, NumberOutOfRangeException {//throws de thong bao mot phương thuc gay ngoai le
        if (b == 0) {
            throw new ArithmeticException("Loi chia cho 0");//throw dung de nem mot ngoai le tu vi tri nhat dinh(la thong bao)
            //ArithmeticException la mot ngoai le co san trong java
        }
        if (a < -1000 || a > 1000 || b < -1000 || b > 1000) {
            throw new NumberOutOfRangeException("Gia tri dau vao nam ngoai pham vi tinh toan");
        }
        return (double) a / b;
    }
}


