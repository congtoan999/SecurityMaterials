public class NumberOutOfRangeException extends Exception {// lop Exception la lop co san trong java dung de lam viec voi ngoai le
    public NumberOutOfRangeException(String message) {//thong diep duoc nem vao thuoc tinh message
        super(message);
    }
}
