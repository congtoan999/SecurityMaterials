import java.io.*;//doc va ghi vao tep tin, luong va cac nguon i/o

public class FileManipulation {

    public static void main(String[] args) {

        // Thư mục cần truy cập
        String folderPath = "D:\\Java\\java thuc hanh";   //folderPatch : duong dan folder

        // Các tiện ích mở rộng của tệp cần truy cập
        String[] fileExtensions = {".txt", ".docx"};     //fileExtensions : file mở rộng

        // Kiểm tra xem thư mục tồn tại hay không
        File folder = new File(folderPath);
        if (!folder.exists()) {   //exists ktra xem file ton tai k tra ve true false
            System.out.println("Thư mục không tồn tại");
            return;
        }

        // Lấy danh sách các tệp cụ thể trong thư mục
        File[] files = folder.listFiles(new FilenameFilter() {  //listFiles là pthuc cua file tra ve mot mang doi tuong "File" đai dien cho tep
            @Override
            public boolean accept(File dir, String name) {
                if (fileExtensions.length == 0) {
                    return true; // Trả về tất cả các tệp nếu không có tiện ích mở rộng được chỉ định
                }
                for (String extension : fileExtensions) {
                    if (name.endsWith(extension)) {
                        return true;
                    }
                }
                return false;
            }
        });

        // Kiểm tra loại của tệp được chỉ định bởi tên đường dẫn
        String filePath = "D:\\Java\\java thuc hanh\\file.txt";  //filePatch : duong dan file
        File file = new File(filePath);
        if (file.isDirectory()) {
            System.out.println("Đây là thư mục");
        } else if (file.isFile()) {
            System.out.println("Đây là tệp");
        } else {
            System.out.println("Tệp không tồn tại");
        }

        // Nối văn bản vào một tập tin hiện có
        String appendText = "Đây là nội dung cần được nối vào tệp.";
        try (FileWriter writer = new FileWriter(filePath, true)) {
            writer.write(appendText);
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Tìm từ dài nhất trong một tệp văn bản
        String longestWord = "";
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] words = line.split("\\s+");
                for (String word : words) {
                    if (word.length() > longestWord.length()) {
                        longestWord = word;
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();//nguyên nhân cụ thể và vị trí ngoại lệ xảy ra trong chương trình
        }
        System.out.println("Từ dài nhất trong tệp là: " + longestWord);
    }
}
