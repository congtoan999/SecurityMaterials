import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class SumFromFile {
    public static void main(String[] args) {
        // Khởi tạo đối tượng Scanner để đọc tệp input.txt
        Scanner scanner = null;
        try {
            scanner = new Scanner(new File("input.txt"));
        } catch (FileNotFoundException e) {
            System.out.println("File not found.");
            System.exit(0);
        }

        // Tính tổng các số nguyên trong tệp
        int sum = 0;
        while (scanner.hasNextInt()) {
            sum += scanner.nextInt();
        }

        // Ghi kết quả vào tệp output.txt
        PrintWriter writer = null;
        try {
            writer = new PrintWriter(new File("output.txt"));
        } catch (FileNotFoundException e) {
            System.out.println("File not found.");
            System.exit(0);
        }
        writer.print(sum);
        writer.close();

        System.out.println("Done.");
    }
}
