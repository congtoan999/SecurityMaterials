import java.util.Scanner;

public class bai4 {
    public static int so_tu(String c2) {
        String[] tu = c2.trim().split("\\s+");
        return tu.length; // dem so tu chuoi dau vao
    }

    public static boolean isPalindrome(String c1) {
        for (int i = 0; i < c1.length() -1; i++) {
            if (c1.charAt(i) != c1.charAt(c1.length() - i - 1)) {
                return false;  // return nguoc lai la sai het bai 
            }
        }
        return true;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("nhap chuoi 1 : ");
        String c1 = sc.nextLine();
        System.out.println("nhap chuoi 2 : ");
        String c2 = sc.nextLine();
        sc.close();

        // tim do dai cua chuoi
        int do_dai = c1.length();
        System.out.println("do dai cua chuoi la : " + do_dai);

        // tim so tu cua mot chuoi
        System.out.println("so tu chuoi 1 la : " + so_tu(c2));

        // noi chuoi 1 voi chuoi 2
        System.out.println("chuoi sau khi noi la : " + c1 + " " + c2);

        // co phai la chuoi doi xung khong
        System.out.println(c1 + " la chuoi doi xung : " + isPalindrome(c1));
    }

}
