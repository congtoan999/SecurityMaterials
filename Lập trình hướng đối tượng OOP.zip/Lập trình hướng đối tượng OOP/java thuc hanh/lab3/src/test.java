class test {
    public static void main(String[] args) {
        String a = "thoang ggnaoht";
        
        System.out.println(dem(a));
        System.out.println(isPalindrome(a));
        
    }

    public static int dem(String a){
        String[] tu = a.split("\\s+");
        int count = 0;
        for (String word : tu){
            count++;
        }
        return count;
    }
    public static boolean isPalindrome(String a){
        
        for (int i = 0;i<a.length()-1;i++)
        {
            if (a.charAt(i) != a.charAt(a.length()-i-1) )
            {
                return false;
            }
        }
        return true;
    }



}