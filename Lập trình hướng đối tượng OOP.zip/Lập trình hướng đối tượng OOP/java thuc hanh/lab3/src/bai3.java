public class bai3 {
    public static String ho(String ho_ten) { // tat ca String khong co []
        String[] tu = ho_ten.split(" ");     // String[] dung de luu tru mot mang cac chuoi
        return tu[0];
    }

    public static String ten(String ho_ten) {
        String[] tu = ho_ten.split(" ");
        return tu[tu.length - 1];
    }

    public static String ten_Dem(String ho_ten) {
        String tu[] = ho_ten.split(" ");
        String middleName = ""; // "" de chen khoan cach khi can thiet
        int i;
        for (i = 1; i < tu.length - 1; i++) {
            middleName += tu[i] + " ";
        }
        return middleName;
    }

    public static String viet_Hoa_Chu_Cai_Dau(String ho_ten_2) {
        String tu[] = ho_ten_2.split("\\s+");
        String viethoa = ""; // "" de chen khoan cach khi can thiet
        for (String word : tu) {
            String firstChar = word.substring(0, 1);
            String rest = word.substring(1);
            viethoa += firstChar.toUpperCase() + rest.toLowerCase() + " ";
        }
        return viethoa;
    }

    public static String viet_Hoa_Nguyen_Am(String ho_ten) {
        String kq = "";
        for (int i = 0; i < ho_ten.length(); i++) {
            char ch = ho_ten.charAt(i);
            if (ch == 'u' || ch == 'e' || ch == 'o' || ch == 'a' || ch == 'i') {
                kq += Character.toUpperCase(ch);
            } else if (Character.isLetter(ch)) { // ísLetter kiem tra xem co phai chu cai hay khong
                                                 // bat buoc phai else if
                kq += Character.toLowerCase(ch);
            } else {
                kq += ch;
            }
        }
        return kq;
    }

    public static void main(String[] args) {
        String ho_ten = "Nguyen Van Chien";
        String ho_ten_2 = "nguyen van chien";
        System.out.println("ten bo dem la : " + ho(ho_ten) + " " + ten(ho_ten));
        System.out.println("ten dem la :" + ten_Dem(ho_ten));
        System.out.println("ho ten viet hoa chu cai dau la :" + viet_Hoa_Chu_Cai_Dau(ho_ten_2));
        System.out.println("viet ho nguyen am va viet thuong phu am : " + viet_Hoa_Nguyen_Am(ho_ten));

    }
}
