public class bai2 {
    public static void main(String[] args) {
        int[][] ma_tran_1 = { { 1, 2 }, { 3, 4 } };
        // System.out.println(ma_tran_1.length);    
        int[][] ma_tran_2 = { { 5, 6 }, { 7, 8 } };

        System.out.println("Ma tran 1: ");
        in_ma_tran(ma_tran_1); // in ma tran duoi dang ma tran

        System.out.println("Ma tran 2: ");
        in_ma_tran(ma_tran_2); // in ma tran duoi dang ma tran

        int[][] sumMatrix = cong_ma_tran(ma_tran_1, ma_tran_2);
        System.out.println("Tong hai ma tran: ");
        in_ma_tran(sumMatrix);

        int scalar = 2;
        int[][] scalarMatrix = nhan_ma_tran_voi_1_so(ma_tran_1, scalar);
        System.out.println("Ma tran 1 nhan voi mot so: ");
        in_ma_tran(scalarMatrix); // in ma tran 1 nhan voi mot so
    }

    public static int[][] cong_ma_tran(int[][] ma_tran_1, int[][] ma_tran_2) {
        int rows = ma_tran_1.length; // hang ngang
        int cols = ma_tran_1[0].length; // hang doc
        int[][] result = new int[rows][cols];

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                result[i][j] = ma_tran_1[i][j] + ma_tran_2[i][j];
            }
        }

        return result;
    }

    public static int[][] nhan_ma_tran_voi_1_so(int[][] ma_tran, int scalar) {
        int rows = ma_tran.length;
        int cols = ma_tran[0].length;
        int[][] result = new int[rows][cols];

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                result[i][j] = ma_tran[i][j] * scalar;
            }
        }
        return result;
    }

    public static void in_ma_tran(int[][] ma_tran) {
        int rows = ma_tran.length;
        int cols = ma_tran[0].length;

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                System.out.print(ma_tran[i][j] + " ");
            }
            System.out.println();
        }
        System.out.println();
    }
}