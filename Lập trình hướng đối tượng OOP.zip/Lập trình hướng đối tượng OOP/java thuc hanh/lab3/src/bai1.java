import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;

public class bai1 {
    public static void main(String[] args) {

        // cau 1: xoa mot phan tu va tra ve gia tr true false
        int[] arr = { 1, 2, 4, 3 };

        Scanner sc = new Scanner(System.in);
        System.out.print("Nhập phần tử cần xóa: ");
        int val = sc.nextInt();
        sc.close();
        System.out.println(removeFirstOccurrence(arr, val));

        // de hien thi ket qua cac phan tu con lai sau khi xoa

        // boolean removed = removeFirstOccurrence(arr, val);
        // if (removed) {
        // System.out.print("Mảng sau khi xóa: ");
        // for (int i = 0; i < arr.length - 1; i++) {
        // System.out.print(arr[i] + " ");
        // }
        // } else {
        // System.out.println("Phần tử " + val + " không tồn tại trong mảng.");
        // }

        // cau 2 : chen phan tu vao vi tri cau mang
        int[] a = { 1, 2, 4, 3 };
        int x = 5;
        int pos = 2;

        insertElement(a, x, pos);

        for (int i = 0; i < a.length; i++) {
            System.out.print(a[i] + " ");
        }
        System.out.println();
        // cau 3 : viet lai mang cac gia tri trung lap
        int[] a3 = { 1, 3, 1, 3, 2, 4 };
        List<Integer> duplicates = findDuplicates(a3); // duplicates dung viet lai ca phan tu da trung trc do bo cac
                                                       // phan tu khong trung di 
        System.out.println(duplicates);

        // cau 4 : viet lai mang gom cac gia tri khong trung lap
        int[] a4 = { 1, 3, 1, 3, 2, 4 };
        int[] result = removeDuplicates(a4);
        for (int i = 0; i < result.length; i++) {
            System.out.print(result[i] + " ");
        }

    }

    public static boolean removeFirstOccurrence(int[] arr, int val) {
        int index = -1;
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == val) {
                index = i;
                break;
            }
        }
        if (index == -1) {
            return false;
        } else {
            for (int i = index; i < arr.length - 1; i++) {
                arr[i] = arr[i + 1];
            }
            arr[arr.length - 1] = 0; // phan tu cuoi cung bang 0
            return true;
        }
    }
///
    public static void insertElement(int[] a, int x, int pos) {
        for (int i = a.length - 1; i > pos; i--) { //chay tu vi tri thu 4 den vi tri 0 theo chieu phai sang trai
                                                     //ar.length-1 đưa về vị trí i cuoi cua mang khong phai gia tri cụ the la 5
            a[i] = a[i - 1];    //vi tri arr[3]  = arr[2]
        }
        a[pos] = x;
    }
///
    public static List<Integer> findDuplicates(int[] arr) {
        List<Integer> result = new ArrayList<>();
        for (int i = 0; i < arr.length; i++) {
            for (int j = i + 1; j < arr.length; j++) {
                if (arr[i] == arr[j] && !result.contains(arr[i])) {
                    result.add(arr[i]);
                    break;
                }
            }
        }
        return result;
    }

    public static int[] removeDuplicates(int[] arr) {
        int n = arr.length;
        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                if (arr[i] == arr[j]) {
                    for (int k = j; k < n - 1; k++) {
                        arr[k] = arr[k + 1];
                    }
                    n--;
                    j--;
                }
            }
        }
        int[] result = new int[n];
        for (int i = 0; i < n; i++) {
            result[i] = arr[i];
        }
        return result;
    }
}
