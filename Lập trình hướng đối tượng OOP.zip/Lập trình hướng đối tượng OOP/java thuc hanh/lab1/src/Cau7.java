import java.util.Scanner;

public class Cau7 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Nhap mot ki tu : ");
        char c = scanner.next().charAt(0);
        if (isLowerCase(c)) {
            System.out.println(c + " la chu thuong hoac chu hoa hoac so");
        } else {
            System.out.println(c + " khong la chu thuong hoac hoa hoac so");
        }
    }

    public static boolean isLowerCase(char c) {
        return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9');
    }
}