public class Cau2 {
    public static void main(String[] args) {
        double height = 2;
        double base = 3;
        double S = 0;
        S = (1.0 / 2) * base * height;
        System.out.println("dien tich la : " + S);
    }
}