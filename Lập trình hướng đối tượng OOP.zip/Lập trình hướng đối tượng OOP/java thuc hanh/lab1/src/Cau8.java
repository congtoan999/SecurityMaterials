import java.util.Scanner;

public class Cau8 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("nhap n : ");
        int n = sc.nextInt();
        System.out.println("kq cau a = " + Cau_a(n));
        System.out.println("kq cau b = " + Cau_b(n));
        System.out.println("kq cau c = " + Cau_c(n));
        System.out.println("kq cau d = " + Cau_d(n));
        System.out.println("kq cau e = " + Cau_e(n));
    }

    public static int Cau_a(int n) {
        int a = 0;
        for (int i = 0; i <= n; i++) {
            a += i;
        }
        return a;
    }

    public static int Cau_b(int n) {
        int b = 1;
        for (int i = 1; i <= n; i++) {
            b *= i;
        }
        return b;
    }

    public static int Cau_c(int n) {
        int c = 1;
        for (int i = 0; i <= n; i++) {
            c += Math.pow(2, i);
        }
        return c;
    }

    public static double Cau_d(int n) {
        double d = 1;
        for (int i = 1; i <= n; i++) {
            d += 1.0 / (2 * i);
        }
        return d;
    }

    public static int Cau_e(int n) {
        int e = 1;
        for (int i = 1; i <= n; i++) {
            e += Math.pow(i, 2);
        }
        return e;
    }
}