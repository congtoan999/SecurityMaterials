import java.util.Scanner;

public class Cau14 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n;

        do {
            System.out.println("--Menu-- ");
            System.out.println("1. Coca ");
            System.out.println("2. Pepsi ");
            System.out.println("3. Sprite ");
            System.out.println("4. Snack ");
            System.out.println("5. Shutdown Machine ");
            System.out.println("please enter the number : ");
            n = sc.nextInt();
            sc.close();
            switch (n) {

                case 1: {
                    System.out.println("the price of Coca is : 2$, please enter the amount of money : ");
                    int coca = sc.nextInt();
                    if (coca >= 2) {
                        Double tien_thoi = (double) coca - 2;
                        System.out.println("your change is : " + tien_thoi + " $");
                    } else {
                        System.out.println("not enough money buy this item. please select again");
                    }

                    break;
                }
                case 2: {
                    System.out.println("the price of Coca is : 5$, please enter the amount of money : ");
                    int Pepsi = sc.nextInt();
                    if (Pepsi >= 5) {
                        Double tien_thoi = (double) Pepsi - 5;
                        System.out.println("your change is : " + tien_thoi + " $");
                    } else {
                        System.out.println("not enough money buy this item. please select again");
                    }
                    break;
                }
                case 3: {
                    System.out.println("the price of Coca is : 1$, please enter the amount of money : ");
                    int Sprite = sc.nextInt();
                    if (Sprite >= 1) {
                        Double tien_thoi = (double) Sprite - 1;
                        System.out.println("your change is : " + tien_thoi + " $");
                    } else {
                        System.out.println("not enough money buy this item. please select again");
                    }
                    break;
                }
                case 4: {
                    System.out.println("the price of Coca is : 9$, please enter the amount of money : ");
                    int Snack = sc.nextInt();
                    if (Snack >= 9) {
                        Double tien_thoi = (double) Snack - 9;
                        System.out.println("your change is : " + tien_thoi + " $");
                    } else {
                        System.out.println("not enough money buy this item. please select again");
                    }
                    break;
                }
                case 5: {
                    System.out.println("Machine is shutting out");
                    break;
                }

            }

        } while (n != 5);
    }
}