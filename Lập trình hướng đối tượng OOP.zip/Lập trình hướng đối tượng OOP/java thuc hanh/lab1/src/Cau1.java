import java.util.Scanner;

public class Cau1 {
    public static void main(String[] args) {
        int sinh, mssv;
        String ten;
        Scanner sc = new Scanner(System.in);
        System.out.print("nhap ho va ten : ");
        ten = sc.nextLine();
        System.out.println("ho va ten la : " + ten);

        System.out.print("nhap ngay sinh : ");
        sinh = sc.nextInt();
        System.out.println("ngay sinh la : " + sinh);

        System.out.print("nhap mssv : ");
        mssv = sc.nextInt();
        System.out.println("mssv la : " + mssv);
    }
}