import java.util.Scanner;

public class Cau12 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("nhap n = ");
        int n = sc.nextInt();
        System.out.print("so dao nguoc la : " + daonguoc(n));
    }

    public static int daonguoc(int n) {
        int dao = 0;
        while (n > 0) {
            // n =234
            int tam = n % 10;
            dao = dao * 10 + tam;
            n = n / 10;
        }
        return dao;
    }
}