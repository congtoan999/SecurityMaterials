import java.util.Scanner;

public class Cau10 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("nhap n = ");
        int n = sc.nextInt();
        System.out.println("ket qua la : " + tong(n));
    }

    public static int tong(int n) {
        int last = n % 10;
        while (n >= 10) {
            n /= 10;
        }
        int first = n;

        return first + last;
    }
}