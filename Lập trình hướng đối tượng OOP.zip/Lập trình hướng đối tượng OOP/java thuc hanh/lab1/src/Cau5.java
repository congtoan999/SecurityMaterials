public class Cau5 {
    public static void main(String[] args) {
        boolean Kt = Kt(100);
        System.out.println("do la nam nhuan : " + Kt);
    }

    public static boolean Kt(int nam) {
        if (((nam % 4 == 0) && (nam % 100 != 0)) || (nam % 400 == 0)) {
            return true;
        }
        return false;
    }
}