import java.util.Scanner;

public class Cau11 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("nhap n = ");
        int n = sc.nextInt();
        System.out.print("n co " + chuso(n) + " chu so");
    }

    public static int chuso(int n) {
        int cout = 1;
        while (n >= 10) {
            n = n / 10;
            cout++;
        }
        return cout;
    }
}