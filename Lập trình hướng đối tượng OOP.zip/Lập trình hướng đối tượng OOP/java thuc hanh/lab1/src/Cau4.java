public class Cau4 {
    public static void main(String[] args) {
        double C_sang_F = C_sang_F(2);
        double F_sang_C = F_sang_C(40);
        System.out.println("do c la : " + F_sang_C);
        System.out.println("do f la : " + C_sang_F);
    }

    public static double C_sang_F(double c) {
        return 9.0 / 5 * c + 32;
    }

    public static double F_sang_C(double f) {
        return 5.0 / 9 * (f - 32);
    }
}