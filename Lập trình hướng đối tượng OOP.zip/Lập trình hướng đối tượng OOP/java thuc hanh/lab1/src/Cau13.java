import java.util.Scanner;

public class Cau13 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("nhap n = ");
        int n = sc.nextInt();
        System.out.print("is a palindrome : " + dx(n));
    }

    public static boolean dx(int n) {
        int dao = 0, tem = n;
        while (n > 0) {
            int tam = n % 10;
            dao = dao * 10 + tam;
            n = n / 10;
        }
        if (dao == tem) {
            return true;
        }
        return false;
    }
}