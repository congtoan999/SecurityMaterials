import java.util.Scanner;

class test {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n;
        do {
            System.out.println("--MENU--");
            System.out.println("1.Coca");
            System.out.println("2.Pepsi");
            System.out.println("3.Sprite");
            System.out.println("4.Snack");
            System.out.println("5.Shutdown Machine");
            System.out.println("please enter the number : ");
            n = sc.nextInt();

            switch (n) {
                case 1: {
                    System.out.println("the price of Coca is : 2$ , please enter the amount of money : ");
                    float tien = sc.nextInt();
                    if (tien >= 2) {
                        tien = tien - 2;
                        System.out.println("Your change is " + tien + "$");
                    } else {
                        System.out.println("Not enough money to buy this item. Please select again.");
                    }
                    break;
                }
                case 5: {
                    System.out.println("Machine is shutting down.");
                    break;
                }

            }

        } while (n != 5);
        sc.close();
    }
}