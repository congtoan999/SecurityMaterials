public class Cau6 {
    public static int min(int a, int b, int c) {
        int nn = a;
        if (nn > b) {
            nn = b;
        }
        if (nn > c) {
            nn = c;
        }
        return nn;
    }

    public static void main(String[] args) {
        System.out.println("so nho nhat tring ba so la : " + min(5, 6, 4));

    }
}
