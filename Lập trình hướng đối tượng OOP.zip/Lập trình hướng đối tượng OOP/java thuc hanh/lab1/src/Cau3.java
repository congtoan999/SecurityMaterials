public class Cau3 {
    public static void main(String[] args) {
        double Du = Du(6, 5);
        System.out.println("du la : " + Du);
    }

    public static double Du(double a, double b) {

        return a % b;
    }
}