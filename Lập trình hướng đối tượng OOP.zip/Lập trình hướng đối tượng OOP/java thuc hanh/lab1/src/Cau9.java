import java.util.Scanner;

public class Cau9 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("nhap n = ");
        int n = sc.nextInt();
        System.out.println("kq la : " + chan(n));
    }

    public static double chan(int n) {
        if (n % 2 == 0) {
            return n / 2.0;
        } else {
            return n * 3 + 1;
        }
    }
}