class Circle implements GeometricObject{
    protected double radius;      
    
    public Circle(){
        this.radius = 0.0;
    }
    
    public double getArea(){
        return radius * radius * Math.PI;
    }
    
    public double getPerimeter(){
        return 2 * radius * Math.PI;
    }
}