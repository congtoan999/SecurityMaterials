class Test{
    public static void main(String[] args) {
        Circle circle = new Circle();
        circle.radius = 5.0;
        System.out.println("Circle radius: "    + circle.radius);
        System.out.println("Circle area: "      + circle.getArea());
        System.out.println("Circle perimeter: " + circle.getPerimeter());
    }
}