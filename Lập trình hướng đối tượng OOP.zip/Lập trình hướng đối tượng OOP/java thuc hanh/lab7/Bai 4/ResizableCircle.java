class ResizableCircle extends Circle {
    public ResizableCircle() {
        super();
    }

    public void resize(int percent) {
        double newRadius = radius * (1 + percent / 100.0);
        radius = newRadius;
    }
}
