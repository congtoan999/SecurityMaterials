abstract class Shape{//abstract chi anh huong test main con lai khong anh huong den lop nho khac
    protected String color;
    protected boolean filled;
    
    public Shape(){
        this.color = "";
        this.filled = true;
    }
    public Shape(String color,boolean filled){
        this.color = color;
        this.filled = filled; 
    }

    public String getColor(){
        return "";
    }
    public void setColor(String color){
        this.color = color;
    }
    public boolean isFilled(){
        return filled;
    }
    public void setFilled(boolean filled){
        this.filled = filled;
    }

    public boolean equals(Shape s){
        if(s instanceof Shape){
            Shape r  = (Shape) s;
            if(this.getColor() == r.getColor()){
                return true;
            }
        }
        return false;
    }

    public abstract double getArea();
    public abstract double getPerimeter();

    public String toString(){
        return color + " - "+ filled + " - "+getArea() + " - " + getPerimeter();
    }

}