class Rectangle extends Shape{
    private double length;
    private double width;

    public Rectangle(){
        super();
        this.length = 0;
        this.width = 0;
    }

    public Rectangle(double length,double width, String color){
        super(color);
        this.length = length;
        this.width = width;
    }

    public double getArea(){
        return length * width;
    }

    public double getPerimeter(){
        return (length + width) * 2;
    }

    public String toString(){
        return "Rectangle{" + length + " - "+ width + " - "+ color+"}";
    }
}  