public class Test{
    public static void main (String[] args){
        Shape s = new Rectangle(3,4,"white");
        Rectangle s1 = new Rectangle(3,4,"white");  //neu Shape o dau khong duoc do khong co phuong thuc o do
        System.out.println(s.toString());
        System.out.println(s.getArea());
        System.out.println(s1.getPerimeter());

        System.out.println();
        Shape s5 = new Triangle(2,5,"trang");// su dung abstract
        System.out.println(s5.getArea());
    }
}