class MovablePoint implements Movable{
    int x;
    int y;
    int xSpeed;
    int ySpeed;
    public MovablePoint(int x,int y,int xSpeed,int ySpeed){
        this.x = x;
        this.y = y;
        this.xSpeed = xSpeed;
        this.ySpeed = ySpeed;
    }
    public String toString(){
        return "MovablePoint: "+ x+ " - "+ y + " - "+ xSpeed + " - "+ ySpeed ;
    }
    public void moveUp(){        //bat buoc phai co dong 15 --> 26 neu khong chuong trinh loi
        y += ySpeed;
    }
    public void moveDown(){
        y-=ySpeed;
    }
    public void moveLeft(){
        x+=xSpeed;
    }
    public void moveRight(){
        x-=xSpeed;
    }
}