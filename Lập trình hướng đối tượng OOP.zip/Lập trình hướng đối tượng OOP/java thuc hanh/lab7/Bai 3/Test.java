class Test{
    public static void main(String[] args){
        MovableCircle m1 = new MovableCircle(4,5,2,3,2);
        Movable m2 = new MovableCircle(6,2,3,6,9);
        MovablePoint m3 = new MovablePoint(2,5,7,2);
        System.out.println(m1.toString());
        System.out.println(m2.toString());
        System.out.println(m3.toString());
        MovablePoint point = new MovablePoint(3, 5, 2, 2);
        System.out.println("Starting point: " + point.toString());
        point.moveUp();
        System.out.println("After moving up: " + point.toString());
    }
}