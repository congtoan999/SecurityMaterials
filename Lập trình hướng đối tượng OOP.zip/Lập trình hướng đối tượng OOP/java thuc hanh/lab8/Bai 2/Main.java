import java.util.ArrayList;

class Main{
    public static void main(String[] args){
        ArrayList<Point> p = new ArrayList<>();// ds p chua doi tuong Point
        p.add(new Point(0.5,0.6));
        p.add(new Point(0.5,0.5));
        p.add(new Point(-3.4,-2.6));
        p.add(new Point(1,1));
        p.add(new Point(2,2));

        ArrayList<Point> p1 = new ArrayList<>();
        for (Point p0 : p){
            if (p0.distanceFromO()<=1){
                p1.add(p0);
            }
        }

        System.out.println("cac diem ben trong duong tron: ");
        for (Point p0 : p1){
            System.out.println(p0.toString());
        }
    }
}