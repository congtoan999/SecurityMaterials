import java.util.ArrayList; //chúng ta có thể tạo một đối tượng ArrayList, thêm các phần tử vào danh sách,
// lặp qua danh sách để truy cập và thao tác với các phần tử, và thực hiện nhiều hoạt động khác trên danh sách ArrayList

class Point{
    private double x;
    private double y;
    public Point(){
        this.x = 0;
        this.y = 0;
    }
    public Point(double x, double y){
        this.x = x;
        this.y = y;
    }
    public double getX(){
        return x;
    }
    public void setX(double x){
        this.x = x;
    }
    public double getY(){
        return y;
    } 
    public void setY(double y){
        this.y = y;
    }
    public String toString(){
        return x +" , "+ y;
    }
    public double distanceFromO(){
        return Math.sqrt(Math.pow(x,2)+Math.pow(y,2));
    }

}