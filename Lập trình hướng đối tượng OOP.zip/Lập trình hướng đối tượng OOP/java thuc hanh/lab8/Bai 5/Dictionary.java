import java.util.HashMap; //ton tai theo cap tieng Anh Viet
import java.util.Scanner;

class Dictionary{
    private HashMap<String,String> dict;//luu tru tu va nghia A-Viet vao dict

    public Dictionary(){
        dict = new HashMap<String,String>();
        dict.put("apple","trái táo");//put là phuong thuc cua HashMap
        dict.put("dog","con chó");
        dict.put("cat","con mèo");
        dict.put("banana","trái chuối");
        dict.put("elephant","con voi");
    }
    public boolean containsWord(String word){
        return dict.containsKey(word);  //containsKey pthuc cua HashMap neu co trong tu dien tra ve true ,ng lai tra ve false
    }

    public String getMeaning(String word){
        return dict.get(word);//tra ve nghia tu TA bang cach use pthuc get() cua hashMap,khong co tra ve "NULL" 
    }

    public static void main(String[] args){
        Dictionary dict = new Dictionary();
        Scanner sc = new Scanner(System.in);

        System.out.print("nhap tu can tra: ");
        String word = sc.nextLine();

        if (dict.containsWord(word)){
            System.out.println("nghia cua tu "+word+" la: "+dict.getMeaning(word));
        }
        else{
            System.out.println("khong tim thay tu trong tu dien !!!!!");
        }
    }
}
