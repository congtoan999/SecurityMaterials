import java.util.HashMap;

class Dictionary_kieu_thay{
    private HashMap<String,String> dict = new HashMap<String,String>();

    public boolean addWord(String word, String meaning){// addWord them tu moi vao tu dien
        if(!isExist(word.toLowerCase())){//neu khong ton tai roi
            dict.put(word.toLowerCase(), meaning);//put() là một phương thức được sử dụng để thêm một cặp key-value vào một đối tượng Map
            return true;
        }
        return false;
    }

    public boolean isExist(String word){
        return dict.containsKey(word.toLowerCase());//ktra word co ton tai trong dict khong
    }

    public String getMeaning(String word){
        if(!isExist(word.toLowerCase())){//neu chu viet thuong khong ton tai
            return "Word is not exist";//hien dong nay
        }
        return dict.get(word.toLowerCase());//neu co nghia lay du lieu dong nay
    }
}

class Test_cach_thay {
    public static void main(String[] args){
        Dictionary_kieu_thay d = new Dictionary_kieu_thay();
        d.addWord("Hello","Xin chao");
        d.addWord("agree","Dong y");
        d.addWord("hello","Xin chao");

        System.out.println(d.getMeaning("Hello"));
        System.out.println(d.getMeaning("hello"));
        System.out.println(d.getMeaning("agree"));
    }
}
