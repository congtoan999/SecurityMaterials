import java.util.ArrayList;
class Main{
    public static void main(String[] args){
        ArrayList<Student> s = new ArrayList<Student>();
        s.add(new ITStudent(5220000,"A",9));
        s.add(new ITStudent(5220001,"B",4));
        s.add(new MathStudent("C52200","C",5));
        System.out.println(Student.findStudent(s));
    }
}