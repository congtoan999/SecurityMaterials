class MathStudent extends Student{
    private String sID;

    public MathStudent(){
        super();
        this.sID = "";
    }
    public MathStudent(String sID,String sName,double gpa){
        super(sName,gpa);
        this.sID = sID;
    }

    public String getRank(){
        if(gpa>=5){
            return "Passed";
        }
        return "Falsed";
    }
}