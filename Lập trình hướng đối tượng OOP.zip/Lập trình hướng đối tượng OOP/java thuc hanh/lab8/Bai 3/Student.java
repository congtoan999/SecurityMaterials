import java.util.ArrayList;

abstract class Student{
    protected String sName;
    protected double gpa;

    public Student(){
        this.sName = "";
        this.gpa = 0.0;
    }
    public Student(String sName, double gpa){
        this.sName=sName;
        this.gpa = gpa;
    }

    public abstract String getRank();

    public static ArrayList<Student> findStudent(ArrayList<Student> l){
        ArrayList<Student> result = new ArrayList<Student>();
        
        for(Student temp : l){
            if(temp.getRank().equals("A") || temp.getRank().equals("Passed")){ //neu hang la A hoac Pass thi them vao result
                result.add(temp);
            }
        }
        return result;
    }
    
    public String toString(){
        return  sName + " - " + gpa;
    }
}