import java.util.ArrayList;

class PersonModel{
    private ArrayList<Student>students = new ArrayList<Student>();  //students la mot danh sach chua doi tuong Student
    private ArrayList<Employee>employees = new ArrayList<Employee>();
    private ArrayList<Person>people = new ArrayList<Person>();

    public void add(Student student){
        students.add(student);// doi tuong student duoc them vao students   
    }
    public void add(Employee employee){
        employees.add(employee);
    }
    public void add(Person person){
        people.add(person);
    }

    public void displayStudent(){
        for(Student student : students){ // students vao student
            System.out.println(student.toString());
        }
    }
    public void displayEmployee(){
        for(Employee employee : employees){
            System.out.println(employee.toString());
        }
    }
    public void displayPeople(){
        for(Person person : people){
            System.out.println(person.toString());
        }
    }
}