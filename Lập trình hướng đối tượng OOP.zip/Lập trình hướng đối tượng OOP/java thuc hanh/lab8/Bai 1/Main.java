class Main{
    public static void main(String[] args){
        PersonModel p = new PersonModel();
        
        // them 2 
        Student s1 = new Student("Toan",2003,"01",8.4);
        Student s2 = new Student("Tien",2005,"02",7.4);
        p.add(s1);
        p.add(s2);
        
        Employee e1 = new Employee("Thinh",2004,"03",4.1);
        Employee e2 = new Employee("Thi",2004,"04",9.1);
        p.add(e1); 
        p.add(e2); 
        
        Person p1 = new Person("Thin",2002);
        Person p2 = new Person("Toi",2007);
        p.add(p1); //them p1 vao p
        p.add(p2); 
        

        //hien thi 2 student
        p.displayStudent(); // lay toString
        p.displayEmployee();
        p.displayPeople();


    }
}