import java.util.Scanner;
import java.util.Vector;

class Main{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);

        System.out.print("nhap do dai cua vecto: ");
        int n = sc.nextInt();

        Vector<Integer> X = new Vector <>(n);  //vector X co kieu du lieu Integer  co do dai n
        System.out.println("nhap cac phan tu cua vecto X: ");
        for(int i = 0;i<n;i++){
            int x = sc.nextInt();
            X.add(x);  //them x vao X
                       //add la phuong thuc cua vector
        }

        Vector<Integer> Y = new Vector<>(n);
        for(int i = 0;i<n;i++){
            int x = X.get(i);  //lay gia tri hien tai thu i trong doi tuong Vector X gán vào x
            int y = 2*x*x+1;
            Y.add(y);  //them y vao Y
        }

        System.out.println("gia tri vector Y: ");
        for(int i = 0 ; i<n;i++){
            System.out.print(Y.get(i)+ " ");
        }    
    }
}