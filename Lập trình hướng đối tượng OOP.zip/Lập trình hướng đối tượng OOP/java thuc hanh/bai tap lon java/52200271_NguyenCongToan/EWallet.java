public class EWallet implements Payment, Transfer {
	private int sDT;
	private double soDuTK;

	public EWallet(int sDT) {
		this.sDT = sDT;
		this.soDuTK = 0;
	}

	public boolean pay(double amount) {
		double soTienCanTT = amount;
		if (soTienCanTT <= soDuTK) {
			soDuTK -= soTienCanTT;
			return true;
		}
		return false;
	}

	public boolean transfer(double amount, Transfer to) {
		if (to.getClass() == EWallet.class) {
			EWallet e = (EWallet) to;
			double phiTong = amount + amount * transferFee;
			if (soDuTK >= phiTong) {
				soDuTK -= phiTong;
				e.topUp(amount);
				return true;
			}
		}
		if (to.getClass() == BankAccount.class) {
			BankAccount b = (BankAccount) to;
			double phiTong = amount + amount * transferFee;
			if (soDuTK >= phiTong) {
				soDuTK -= phiTong;
				b.topUp(amount);
				return true;
			}
		}

		return false;
	}

	public String toString() {
		return String.format("%d,%.1f", sDT, soDuTK);
	}

	public double checkBalance() {
		return soDuTK;
	}

	public void topUp(double amount) {
		soDuTK += amount;
	}

	public int getSDT() {
		return sDT;
	}
}
