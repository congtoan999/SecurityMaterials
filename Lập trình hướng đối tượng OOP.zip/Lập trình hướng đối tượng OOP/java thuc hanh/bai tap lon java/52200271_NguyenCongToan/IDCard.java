public class IDCard {

      private int soDinhDanh;
      private String hoTen;
      private String gioiTinh;
      private String ngayThangNamSinh;
      private String diaChi;
      private int sDT;

      public IDCard(int soDinhDanh, String hoTen, String gioiTinh, String ngayThangNamSinh, String diaChi, int sDT) {
            this.soDinhDanh = soDinhDanh;
            this.hoTen = hoTen;
            this.gioiTinh = gioiTinh;
            this.ngayThangNamSinh = ngayThangNamSinh;
            this.diaChi = diaChi;
            this.sDT = sDT;
      }

      public int getSoDinhDanh() {
            return soDinhDanh;
      }

      public void setSoDinhDanh(int soDinhDanh) {
            this.soDinhDanh = soDinhDanh;
      }

      public String getHoTen() {
            return hoTen;
      }

      public void setHoTen(String hoTen) {
            this.hoTen = hoTen;
      }

      public String getGioiTinh() {
            return gioiTinh;
      }

      public void setGioiTinh(String gioiTinh) {
            this.gioiTinh = gioiTinh;
      }

      public String getNgayThangNamSinh() {
            return ngayThangNamSinh;
      }

      public void setNgayThangNamSinh(String ngayThangNamSinh) {
            this.ngayThangNamSinh = ngayThangNamSinh;
      }

      public String getDiaChi() {
            return diaChi;
      }

      public void setDiaChi(String diaChi) {
            this.diaChi = diaChi;
      }

      public int getSDT() {
            return sDT;
      }

      public void setSDT(int sDT) {
            this.sDT = sDT;
      }

      public String toString() {
            return String.format("%06d,%s,%s,%s,%s,%07d", soDinhDanh, hoTen, gioiTinh, ngayThangNamSinh, diaChi, sDT);
      }
}
