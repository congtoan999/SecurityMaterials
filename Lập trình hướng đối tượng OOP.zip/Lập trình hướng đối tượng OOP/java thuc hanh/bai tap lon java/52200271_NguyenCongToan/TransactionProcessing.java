import java.util.*;
import java.io.*;

public class TransactionProcessing {
    private ArrayList<Payment> paymentObjects;
    private IDCardManagement idcm;

    public TransactionProcessing(String idCardPath, String paymentPath) {
        idcm = new IDCardManagement(idCardPath);
        readPaymentObject(paymentPath);

    }

    public ArrayList<Payment> getPaymentObject() {
        return this.paymentObjects;
    }

    // Requirement 3
    public boolean readPaymentObject(String path) {
        ArrayList<IDCard> ID = idcm.getIDCards();
        paymentObjects = new ArrayList<>();
        File file = new File(path);
        if (file.exists()) {
            try {
                Scanner read = new Scanner(file);
                while (read.hasNextLine()) {
                    String dong = read.nextLine();
                    String[] tu = dong.trim().split("\\s*,\\s*");
                    int num = Integer.parseInt(tu[0]);

                    if (tu.length == 2) {
                        double laiSuat = Double.parseDouble(tu[1]);
                        paymentObjects.add(new BankAccount(num, laiSuat));
                    } else if (tu[0].length() == 7) {
                        paymentObjects.add(new EWallet(num));

                    } else {
                        for (IDCard c : ID) {
                            if (num == c.getSoDinhDanh()) {
                                paymentObjects.add(new ConvenientCard(c));
                            }
                        }
                    }
                }
                read.close();
            } catch (Exception e) {
                System.out.println(" loi !!! " + e.getMessage());
            }
        }
        return true;
    }

    // Requirement 4
    public ArrayList<ConvenientCard> getAdultConvenientCards() {
        ArrayList<ConvenientCard> theNguoiLon = new ArrayList<>();
        for (Payment p : paymentObjects) {
            try {
                if (p.getClass() == ConvenientCard.class) {
                    ConvenientCard c = (ConvenientCard) p;
                    if (c.getType().equalsIgnoreCase("Adult")) {
                        theNguoiLon.add(c);
                    } else {
                        System.out.println();
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return theNguoiLon;
    }

    // Requirement 5
    public ArrayList<IDCard> getCustomersHaveBoth() {
        ArrayList<IDCard> kq = new ArrayList<>();
        ArrayList<IDCard> ID = idcm.getIDCards();

        for (IDCard id : ID) {
            int b = 0;
            int c = 0;
            int e = 0;

            for (Payment p : paymentObjects) {
                if (p.getClass() == BankAccount.class) {
                    BankAccount bankAccount = (BankAccount) p;
                    if (bankAccount.getSoTK() == id.getSoDinhDanh()) {
                        b = 1;
                    }
                } else if (p.getClass() == EWallet.class) {
                    EWallet eWallet = (EWallet) p;
                    if (eWallet.getSDT() == id.getSoDinhDanh()) {
                        e = 1;
                    }
                } else if (p.getClass() == ConvenientCard.class) {
                    ConvenientCard convenientCard = (ConvenientCard) p;
                    if (convenientCard.getTheDinhDanh().getSoDinhDanh() == id.getSoDinhDanh()) {
                        c = 1;
                    }
                } else {
                    System.out.println("khong dap ung dieu kien !!!");
                }
            }

            if ((b == 1 && c == 1) || (e == 1 && b == 1)
                    || (e == 1 && c == 1)) {
                kq.add(id);
            }
        }
        return kq;
    }

    // Requirement 6
    public void processTopUp(String path) {
        paymentObjects = getPaymentObject();
        File file = new File(path);
        if (file.exists()) {
            try {
                Scanner r = new Scanner(file);
                while (r.hasNextLine()) {
                    String dong = r.nextLine();
                    String[] tu = dong.trim().split("\\s*,\\s*");

                    String tuDau = tu[0];
                    int num = Integer.parseInt(tu[1]);
                    double amount = Double.parseDouble(tu[2]);

                    for (Payment p : paymentObjects) {
                        if (p.getClass() == EWallet.class) {
                            EWallet e = (EWallet) p;
                            if (tuDau.equalsIgnoreCase("EW") && e.getSDT() == num) {
                                e.topUp(amount);
                            }
                        } else if (p.getClass() == BankAccount.class) {
                            BankAccount b = (BankAccount) p;
                            if (tuDau.equalsIgnoreCase("BA") && b.getSoTK() == num) {
                                b.topUp(amount);
                            }
                        } else if (p.getClass() == ConvenientCard.class) {
                            ConvenientCard c = (ConvenientCard) p;
                            if (tuDau.equalsIgnoreCase("CC") && c.getTheDinhDanh().getSoDinhDanh() == num) {
                                c.topUp(amount);
                            }
                        } else {
                            System.out.println("khong dap ung dieu kien !!!");
                        }
                    }
                }
                r.close();
            } catch (Exception e) {
                System.out.println(" loi !!! " + e.getMessage());
            }
        }
    }

    // Requirement 7
    public ArrayList<Bill> getUnsuccessfulTransactions(String path) {
        // code here
        return null;
    }

    // Requirement 8
    public ArrayList<BankAccount> getLargestPaymentByBA(String path) {
        // code here
        return null;
    }

    // Requirement 9
    public void processTransactionWithDiscount(String path) {
        // code here
    }
}
