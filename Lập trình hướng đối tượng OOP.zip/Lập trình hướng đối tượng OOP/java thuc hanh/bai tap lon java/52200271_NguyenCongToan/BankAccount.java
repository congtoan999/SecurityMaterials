public class BankAccount implements Payment, Transfer {
	private int soTK;
	private double laiSuat;
	private double soDuTK;

	public BankAccount(int soTK, double laiSuat) {
		this.soTK = soTK;
		this.laiSuat = laiSuat;
		this.soDuTK = 50;
	}

	public boolean pay(double amount) {
		double soTienCanTT = amount;
		if ((soTienCanTT + 50) <= soDuTK) {
			soDuTK -= soTienCanTT;
			return true;
		}
		return false;
	}

	public boolean transfer(double amount, Transfer to) {
		if (to.getClass() == BankAccount.class) {
			BankAccount b = (BankAccount) to;
			double phiTong = amount + amount * transferFee;
			if (soDuTK >= (phiTong + 50)) {
				soDuTK -= phiTong;
				b.topUp(amount);
				return true;
			}
		}
		if (to.getClass() == EWallet.class) {
			EWallet e = (EWallet) to;
			double phiTong = amount + amount * transferFee;
			if (soDuTK >= (phiTong + 50)) {
				soDuTK -= phiTong;
				e.topUp(amount);
				return true;
			}
		}
		return false;
	}

	public double checkBalance() {
		return soDuTK;
	}

	public void topUp(double amount) {
		soDuTK += amount;
	}

	public String toString() {
		return String.format("%d,%.2f,%.1f", soTK, laiSuat, soDuTK);
	}

	public int getSoTK() {
		return soTK;
	}
}
