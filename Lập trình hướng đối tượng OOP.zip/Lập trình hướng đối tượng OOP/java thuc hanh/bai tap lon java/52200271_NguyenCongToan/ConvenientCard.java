import java.time.*;

public class ConvenientCard implements Payment {

	private String type;
	private IDCard theDinhDanh;
	private double soDuTK;

	public ConvenientCard(IDCard theDinhDanh) throws CannotCreateCard {
		this.theDinhDanh = theDinhDanh;
		this.soDuTK = 100;

		int tuoi = tinhAge(theDinhDanh.getNgayThangNamSinh());
		if (tuoi < 12) {
			throw new CannotCreateCard("Not enough age");
		}
		if (tuoi <= 18) {
			type = "Student";
		} else {
			type = "Adult";
		}
	}

	public int tinhAge(String ngayThangNamSinh) {
		String[] s = ngayThangNamSinh.split("/");
		int namSinh = Integer.parseInt(s[2]);
		int namHienTai = Year.now().getValue();
		int tuoi = namHienTai - namSinh;
		return tuoi;
	}

	public boolean pay(double amount) {
		double soTienCanTT = 0;

		if (type.equals("Student")) {
			soTienCanTT = amount;
		}
		if (type.equals("Adult")) {
			soTienCanTT = amount + amount * 0.01;
		}

		if (soTienCanTT <= soDuTK) {
			soDuTK -= soTienCanTT;
			return true;
		}

		return false;
	}

	public double checkBalance() {
		return soDuTK;
	}

	public void topUp(double amount) {
		soDuTK += amount;
	}

	public String toString() {
		return String.format("%s,%s,%.1f", theDinhDanh.toString(), type, soDuTK);
	}

	public String getType() {
		return this.type;
	}

	public IDCard getTheDinhDanh() {
		return this.theDinhDanh;
	}

}
