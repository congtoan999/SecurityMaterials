class Student {
    private String name;
    private String address;
    private String sex;
    private int score;

    public Student(String name, String address, String sex, int score) {
        this.name = name;
        this.address = address;
        this.sex = sex;
        this.score = score;
    }

    class StudentOperator {
        public void print() {
            System.out.println("[ " + name + " , " + address + " , " + sex + " , " + score + " ]");
        }

        public String type() {
            if (score > 8) {
                return "A";
            }
            if (score >= 5) {
                return "B";
            }
            return "C";
        }
    }
}
