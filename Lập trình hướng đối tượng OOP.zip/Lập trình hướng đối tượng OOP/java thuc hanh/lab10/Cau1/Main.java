class Main{
    public static void main(String[] args) {
        Student s = new Student("Alice", "123 Main St.", "female", 7);
        Student.StudentOperator o = s.new StudentOperator();
        o.print();
        System.out.println(o.type());
    }
}