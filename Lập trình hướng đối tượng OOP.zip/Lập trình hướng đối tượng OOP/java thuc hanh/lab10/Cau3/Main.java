public class Main{
    public static void main(String[] args){
        VegetableFactory g1 = new VegetableFactory();

        // tạo một đối tượng Carrot
        Vegetable carrot = g1.getVegetable("Carrot");
        System.out.println(carrot.getInfo());
    }
}