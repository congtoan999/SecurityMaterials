class Cabbage implements Vegetable{
    protected String type;
    protected double weight;

    public Cabbage(){
        this.type = "Cabbage";
        this.weight = 0;
    }

    public String getInfo(){
        return "this is a: "+ type +" - "+ weight;
    }
}