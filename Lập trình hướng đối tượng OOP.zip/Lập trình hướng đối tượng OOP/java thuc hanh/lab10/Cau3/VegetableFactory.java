class VegetableFactory{
    public Vegetable getVegetable(String type){
        switch(type) {
            case "Carrot":
                return new Carrot();
            case "Pumpkin":
                return new Pumpkin();
            case "Cabbage":
                return new Cabbage();
            default:
                throw new IllegalArgumentException("Invalid vegetable type: " + type);
        }
    }
}