interface Vegetable{
    public String getInfo();
}