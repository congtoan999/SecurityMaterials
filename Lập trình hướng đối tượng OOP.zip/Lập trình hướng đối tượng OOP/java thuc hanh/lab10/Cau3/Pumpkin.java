class Pumpkin implements Vegetable{
    protected double weight;

    public Pumpkin(){
        this.weight = 0;
    }

    public String getInfo(){
        return "can nang la: "+weight;
    }
}