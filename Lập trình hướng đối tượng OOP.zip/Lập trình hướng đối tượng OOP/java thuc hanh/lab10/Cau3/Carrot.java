class Carrot implements Vegetable{
    protected String type;
     
    public Carrot(){
        this.type = "carot";
    }
    public String getInfo(){
        return "this is a: " + type ;
    }
}