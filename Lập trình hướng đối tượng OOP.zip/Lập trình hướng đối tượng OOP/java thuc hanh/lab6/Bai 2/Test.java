public class Test {
    public static void main(String[] args) {
        Student s = new Student("Ngoc", "HCM", "IT", 2, 5000.0);

        System.out.println(s.toString());

        s.setProgram("Software Engineering");
        s.setYear(3);
        s.setFee(6000.0);

        System.out.println(s.toString());
    }
}
