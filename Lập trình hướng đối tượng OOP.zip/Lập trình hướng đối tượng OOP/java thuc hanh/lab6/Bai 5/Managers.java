class Managers extends Employee {
    private String position;  //chuc vu
    private String department;//phong ban
    private double salaryCoefficientPosition;  //he so luong theo chuc vu
    public Managers(){
        super();
        this.position = "truong phong hanh chinh";
        this.department = "";
        this.salaryCoefficientPosition = 5.0;
    } 
    public Managers(String ID,String fullName,double coefificientsSalary, String position, double salaryCoefficientPosition){
        super(ID,fullName,coefificientsSalary);
        this.position = position;
        this.salaryCoefficientPosition = salaryCoefficientPosition;
    }
    public Managers(String ID, String fullName , double coefificientsSalary , int yearJoined , int numDaysOff, String position , String department , double salaryCoefficientPosition ){
        super(ID,fullName,coefificientsSalary,yearJoined,numDaysOff);
        this.position = position ;
        this.department = department;
        this.salaryCoefficientPosition = salaryCoefficientPosition;
    }
    public String considerEmulation(){
        return "Nhan vien dc danh gia A.";
    }
    public double bonusByPosition(){//thuong theo chuc vu
        double basicSalary = 1150;  //luong co ban
        return basicSalary * salaryCoefficientPosition;
    }
    public double getSalary(){ //ghi de phuong thuc tinh luong nhan vien
        return super.getSalary() + bonusByPosition(); 
    }
}