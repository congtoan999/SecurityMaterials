public class Test {
    public static void main(String[] args) {
        Employee e1 = new Employee("1","Nguyen Cong Toan", 5.0 , 2010,2);
        System.out.println(e1.getSenioritySalary());
        System.out.println(e1.coiEmulation());
        System.out.println(e1.getSalary());
        System.out.println();
        Managers m1 = new Managers("1","Nguyen Cong Toan", 5.0 , 2010,2,"chu tich","CTHD",10.0);
        System.out.println(m1.considerEmulation());
        System.out.println(m1.bonusByPosition());
        System.out.println(m1.getSalary());
    }
}

