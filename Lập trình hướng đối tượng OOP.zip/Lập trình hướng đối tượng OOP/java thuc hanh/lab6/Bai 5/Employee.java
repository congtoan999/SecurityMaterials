class Employee {
    protected String ID;
    protected String fullName;
    protected int yearJoined; // nam tham gia
    protected double coefficientsSalary; //he so luong
    protected int numDaysOff;  // so ngay nghi trong thang
    public Employee(){
        this.ID = "0";
        this.fullName = "";
        this.yearJoined = 2020;
        this.coefficientsSalary = 1.0;
        this.numDaysOff = 0;   
    }
    public Employee(String ID,String fullName,double coefficientsSalary){
        this.ID = ID;
        this.fullName = fullName;
        this.coefficientsSalary = coefficientsSalary;
        this.yearJoined = 2020;
        this.numDaysOff = 0;   
    }
    public Employee(String ID,String fullName,double coefficientsSalary,int yearJoined,int numDaysOff){
        this.ID = ID;
        this.fullName = fullName;
        this.coefficientsSalary = coefficientsSalary;
        this.yearJoined = yearJoined;
        this.numDaysOff = numDaysOff;   
    }
    public double getSenioritySalary(){ //luong tham nien
        int yearOfWork = 2023-yearJoined; //so nam lm viec
        if(yearOfWork >5){
            return yearOfWork * coefficientsSalary /100;
        }
        else{
            return 0.0;
        }
    } 
    public String coiEmulation(){ //xep loai ngay nghi nhan vien
        if (numDaysOff <= 1){
            return "A";
        }
        if (numDaysOff <= 3 ){
            return "B" ;
        }
        return "C";
    }

    public double getSalary(){  //luong nhan vien
        double basicSalary = 1150;//luong co ban
        if (coiEmulation() == "A"){
            return basicSalary + basicSalary*(coefficientsSalary + 1.0 ) + getSenioritySalary();
        }
        if (coiEmulation() == "B"){
            return basicSalary + basicSalary*(coefficientsSalary + 0.75 ) + getSenioritySalary();
        }
        return basicSalary + basicSalary*(coefficientsSalary + 0.5 ) + getSenioritySalary();
    }
}