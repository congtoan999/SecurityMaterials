class Test{
    public static void main(String[] args) {
        Square square1 = new Square();
    
        System.out.println("Square 1:");
        System.out.println("Area: " + square1.getArea());
        System.out.println();
    
        Shape s = new Rectangle(); //ep kieu Shape ve Rectangle vi Shape khong co khong co kieu getWidth
        Rectangle r = (Rectangle) s;
        System.out.println(r.getWidth());

        Rectangle sq = new Square(9);
        System.out.println(sq);
        System.out.println(sq);

        Square sq1 = (Square) sq;
        sq1.setLength(10);
        System.out.println(sq1);
        System.out.println(sq1.getSide());
    }
}