class Test{
    public static void main(String[] args) {
        Point3D p1 = new Point3D(4.f, 2.f, 3.f);
        System.out.println(p1.getZ());
        float b[] = p1.getXYZ();
        System.out.println(b[0] + " , " + b[1] + " , "+ b[2]);
        System.out.println(p1.toString());
    }
}