public class Test {
    public static void main(String[] args) {
        Cylinder c1 = new Cylinder();
        Circle c2 = new Cylinder();  //chi su dung cac truong hop o lop cha
        System.out.println("Cylinder 1:");
        System.out.println("Radius: " + c1.getRadius());
        System.out.println("Height: " + c1.getHeight());
        System.out.println("Color: " + c1.getColor());
        System.out.println("Volume: " + c1.getVolume());
        System.out.println("Cylinder 2:");
        System.out.println("Radius: " + c2.getRadius());
        System.out.println("Color: " + c2.getColor());        
    }
}