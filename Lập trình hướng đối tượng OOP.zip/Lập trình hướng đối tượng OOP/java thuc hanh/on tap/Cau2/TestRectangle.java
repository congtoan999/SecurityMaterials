

class TestRectangle {
    public static void main(String[] args){
        Rectangle rec = new Rectangle("Ruby", "Red", 6, 8);
        Rectangle r1 = new Rectangle("haha", "blue", 2, 3);
        Rectangle r3 = new Rectangle("hkk", "snow", 3, 3);
        System.out.println(r1); 

        // Rectangle r2 = r1.resize(1.5); //hoac su dung cai nay thay dong duoi cung dc
        System.out.println(r1.resize(1.5)); 
        //In thong tin
        System.out.println(rec.toString());
        System.out.println(r3.isSquare());
        //SV tu kiem tra them cac phuong thuc khac
    }
}
