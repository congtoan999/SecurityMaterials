public class Rectangle{
    private String name;
    private String color;
    private double width;
    private double length;

    public Rectangle(String name, String color, double wid, double len){
        this.name = name;
        this.color = color;
        this.width = wid;
        this.length = len;
    }

    public String getName(){
        return this.name;
    }

    public String getColor(){
        return this.color;
    }

    public double getWidth(){
        return this.width;
    }
    public double getLength(){
        return this.length;
    }

    public void setName(String name){
        this.name = name;
    }

    public void setColor(String color){
        this.color = color;
    }

    public void setWidth(double width){
        this.width = width;
    }

    public void setLength(double length){
        this.length = length;
    }

    public double getPerimeter(){
        return (length + width) *2;
    }
    public double getDienTich(){
        return width* length;
    }

    public String getType(){
        double area = length * width;
        if(area>= 10){
            return "A";
        }
        else if(area>=5 || area<=10){
            return "B";
        }
        return "C";
    }
	
	public boolean isSquare(){
        if (width == length){
            return true;
        }
        return false;
    }

    public double calDiagonalLine(){
        return Math.sqrt(width*width+length*length);
    }

    public Rectangle resize(double rate) {
        double newLength = length * rate;
        double newWidth = width * rate;
        return new Rectangle(name,color,newLength, newWidth);  // bat buoc them name va color
    }

    public String toString(){
        return "Rectangle[" + name + ", " + length + ", " + width + ", "+ getDienTich()+ ", "+ getType()+"]";
    }
}