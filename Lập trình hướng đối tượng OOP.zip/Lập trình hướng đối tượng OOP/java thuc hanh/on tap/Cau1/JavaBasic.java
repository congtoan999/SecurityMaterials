import java.util.Scanner;
public class JavaBasic{
    public static int sumNegativeElements(int a[]){
        int tong = 0;
        for(int i  = 0 ;i<a.length;i++){
            if (a[i] <0){
                tong += a[i];
            }
        }
        return tong;
    }

    public static String uppercaseFirstVowels(String str){
        String s = str;
        String kq ="";
        for (int i = 0;i<s.length();i++){
            char ch = s.charAt(i);  // charAt[] ko co trong java
            if(ch == 'u'||ch == 'e'|| ch == 'o' || ch == 'a' || ch == 'i'){
                kq += Character.toUpperCase(ch);
            }
            else{
                kq += ch;
            }

        }
        return kq;
    }
	
	public static int findMinNegativeElement(int a[]){
        int min =-1; // min này la gia tri mac dinh danh dau chx co ptu am va la gia tri khong co so am trong mang theo yeu cau de bai
        for (int i = 0;i<a.length;i++){
            if (a[i]<0){
                if( min == -1 ||  a[i]<a[min]){//bat buoc phải co them min == 1 kiem tra xem co gia tri hay chua 
                                               //neu bo a[i]<a[min] thi tra ve gia tri dau tien cua mang
                                               //bat buoc min o dong 29 vs 32 giong nhau 
                                               //== đc dung de ss trong toan tu
                                               // chi bo dc min == -1 trong truong hop mang khong co so am và tra ve gia tri -1 theo de ycau
                    min = i;
                }
        
            }
        }
        return min ;
    }
    
	
	public static String getName(String str){
        String s1 =str;
        int index = s1.indexOf(':');  // tim vi tri xuat hien : lan dau
        if (index!=-1){    //-ngam hieu da tim thay :(co the thay -1 bang bat ki so nao nhung ngam hieu -1 la ko co)
            return s1.substring(index + 2);  //index + 2 bo qua : va khoang trang
        }
            return "";  //chuoi trong
    }

    public static int findFirstMod3Element(int[] a){
        for(int i = 0 ;i<a.length;i++){
            if (a[i] % 3 == 0)
            return i ;
        }
        return -1;
    }

    public static int countString(String str, String k){
        String s2 = str;
        int count = 0;
        String[] tu = s2.split("\\s+");
        for (int i = 0;i<tu.length;i++){ //hoac use for(String word : tu) deu đc
            if (tu[i].equalsIgnoreCase(k) ){  //khong su dung ==0 dc do 2 word va k nam ở 2 vi tri khac nhau 
                count ++;
            }
        }
        return count;
    }

    public static void main(String[] args){
        int[] a = {1,-2,3,4,-2,1,-9};
        System.out.println(sumNegativeElements(a));
        String s = "nguyen thi uyen an";
        System.out.println(uppercaseFirstVowels(s));
        System.out.println(findMinNegativeElement(a));
        
		String s1 = "Ho ten: Nguyen Thi Anh Dao";
		System.out.println(getName(s1));
		System.out.println(findFirstMod3Element(a));
        String s2 = "Nguyen Phuong Hoang Anh Phuong Oanh";
		Scanner sc = new Scanner(System.in);
        System.out.println("nhap k : ");
        String k = sc.nextLine();
        System.out.println(countString(s2,k));
    }

}