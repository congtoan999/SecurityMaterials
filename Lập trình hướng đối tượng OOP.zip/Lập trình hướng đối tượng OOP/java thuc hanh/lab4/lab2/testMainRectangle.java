public class testMainRectangle {
    public static void main(String[] args) {
        Rectangle r1 = new Rectangle(1, 2);
        Rectangle r2 = new Rectangle(3, 5);

        System.out.println(r1.getWidth());
        System.out.println(r2.getWidth());
        System.out.println(r2.getArea());
        System.out.println(r2.getPerimeter());
        System.out.println(r2.toString());
    }
}
