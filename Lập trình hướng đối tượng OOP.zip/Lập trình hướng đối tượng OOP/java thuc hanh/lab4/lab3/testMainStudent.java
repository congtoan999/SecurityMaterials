class testMainStudent {
    public static void main(String[] args) {
        Student s1 = new Student(1, "Nguyen", "Toan");
        Student s2 = new Student(2, "Nguyen", "Ba");

        System.out.println("ho la : " + s1.getFirstName());
        System.out.println("id la : " + s1.getID());
        System.out.println("ten la : " + s1.getLastName());
        System.out.println("ho ten la : " + s1.getName());
        System.out.println(s2.toString());
    }

}