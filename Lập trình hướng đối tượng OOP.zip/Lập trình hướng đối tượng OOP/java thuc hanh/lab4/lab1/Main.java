public class Main {
    public static void main(String[] args) {
        Point2D p1 = new Point2D(1.3f, 3.6f); // cai dau la x
        Point2D p2 = new Point2D(1.2f, 3.4f); // cai sau la y

        System.out.println(p1.getX());
        System.out.println(p2.getY());

    }
}