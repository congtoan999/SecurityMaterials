class testMainFraction{
    public static void main(String[] args){
        Fraction f = new Fraction(1,2);
        Fraction f1 = new Fraction(3,4);    
        System.out.println(f.add(f1));
        Fraction f2 = f.add(f1);
        f2.reducer();
        System.out.println(f2);
        System.out.println(f.mul(f1));
        System.out.println(f1.toString());
    }
}