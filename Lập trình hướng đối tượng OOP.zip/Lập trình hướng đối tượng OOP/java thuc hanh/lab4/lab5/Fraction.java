class Fraction {
    private int numerator;
    private int denominator;

    public Fraction() {
        this(1,1);  //do int num int den cung in nen khai bao z đc 
    }

    public Fraction(int num, int den) {
        this.numerator = num;
        if (den == 0) {
            this.denominator = 1;
        } 
        this.denominator = den;
    }

    public Fraction(Fraction f) {
        this.numerator = f.numerator;
        this.denominator = f.denominator;
    }

    public Fraction add (Fraction f){
        int n = this.numerator * f.denominator + this.denominator * f.numerator;
        int d = this.denominator * f.denominator;
        return new Fraction(n,d);
    }

    public Fraction mul(Fraction f){
        return new Fraction(this.numerator * f.numerator, this.denominator * f.denominator);
    }

    public static int gcd(int a, int b){ //7 , 9
        while (a!=b){
            if (a>b){       //7>2   5>2   3>2 
                a=a -b;     //a=5   a=3   a=1
            }
            else if (a<b){  //7<9              1<2
                b = b -a;   //b=2              b=1
            }
        }
        return a;
    }
    public void reducer(){
        int g = gcd(this.numerator,this.denominator);
        this.numerator = this.numerator/g;
        this.denominator = this.denominator/g;
    }

    public String toString(){
        return "Fraction[num= " + numerator  +",den = "+ denominator+"]"; 
    }
}
    