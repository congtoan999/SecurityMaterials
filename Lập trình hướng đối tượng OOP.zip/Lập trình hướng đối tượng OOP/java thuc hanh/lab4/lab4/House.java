public class House {
    private String houseCode;
    private int numOfBedRooms;
    private boolean hasSwimming;
    private double area;
    private double costPerSquareMeter;

    public House() {
        this.houseCode = "A01";
        this.numOfBedRooms = 2;
        this.hasSwimming = false;
        this.area = 0;
        this.costPerSquareMeter = 0;
    }

    public House(String houseCode, int numOfBedRooms, boolean hasSwimming, double area, double costPerSquareMeter) {
        this.houseCode = houseCode;
        this.area = area;
        this.costPerSquareMeter = costPerSquareMeter;
        this.hasSwimming = hasSwimming;
        this.numOfBedRooms = numOfBedRooms;
    }

    // get
    public String getHouseCode() {
        return houseCode;
    }

    public int getNumOfBedRooms() {
        return numOfBedRooms;
    }

    public boolean getHasSwimming() {
        return hasSwimming;
    }

    public double getArea() {
        return area;
    }

    public double getCostPerSquareMeter() {
        return costPerSquareMeter;
    }

    // set
    public void setHouseCode(String houseCode) {
        this.houseCode = houseCode;
    }

    public void setNumOfBedRooms(int numOfBedRooms) {
        this.numOfBedRooms = numOfBedRooms;
    }

    public void setHasSwimming(boolean hasSwimming) {
        this.hasSwimming = hasSwimming;
    }

    public void setArea(double area) {
        this.area = area;
    }

    public void setCostPerSquareMeter(double costPerSquareMeter) {
        this.costPerSquareMeter = costPerSquareMeter;
    }

    // tinh tien mua nha
    public double calculateSellingPrice() {
        double subtotal = area * costPerSquareMeter;
        if (hasSwimming) {
            subtotal = subtotal + subtotal * 0.1;
        }
        double sellingPrice = subtotal + subtotal *0.15 ;
        return sellingPrice;
    }
}
