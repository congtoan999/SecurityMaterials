public class mainHouse {
    public static void main(String[] args) {
        House h1 = new House("A02", 2, true, 100, 2500000);
        System.out.println(h1.calculateSellingPrice());
    }
}
