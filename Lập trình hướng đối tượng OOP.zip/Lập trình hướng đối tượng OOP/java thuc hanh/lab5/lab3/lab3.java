import java.util.Scanner;

class lab3{
    public static void main(String []args){
        String paragraph = "The Edge Surf is of course also a whole lot better, which will hopefully win Microsoft some converts. It offers time trial, support for other input methods like touch and gamepads, accessibility improvements, high scores, and remastered visuals.";
        System.out.println(countWord(paragraph));
        System.out.println(countSentences(paragraph));
        Scanner sc = new Scanner(System.in);
        System.out.println("nhap word : ");
        String word = sc.next();
        System.out.println(countAppear(paragraph,word));


    }
    //dem tu
    public static int countWord(String paragraph){
        String[] tu = paragraph.split("\\s+");
        // int count=0;
        // for (String word : tu){
        //     count ++;
        // }
        return tu.length;
    }

    //dem cau
    public static int countSentences(String paragraph){
        String[] tu = paragraph.split("[.!?]+\\s");
        return tu.length; //khong phai la length() do no tra ce gia tri thuoc mang tu
    }

    public static int countAppear(String paragraph,String word){
        String[] tu = paragraph.split("\\s+");
        int count = 0;
        for(String w : tu){
            if (w.equals(word)){
                count++;
            }
        }
        return count;
    }
}