class RegularPolygon{
    private String name;
    private int edgeAmount;   //so canh
    private double edgeLength;//do dai canh
    public RegularPolygon(){
        this.name = "";
        this.edgeAmount = 3;
        this.edgeLength = 1;
    }
    public RegularPolygon(String name,int edgeAmount,double edgeLength){
        this.name= name;
        this.edgeAmount = edgeAmount;
        this.edgeLength = edgeLength;
    }
    public RegularPolygon(String name,int edgeAmount){ //khoi tao 2 cai co the lay 2 lan du lieu
        this.name = name;
        this.edgeAmount = edgeAmount; 
        this.edgeLength = 1;
    }
    public RegularPolygon(RegularPolygon polygon){
        this.name = polygon.name;
        this.edgeAmount = polygon.edgeAmount;
        this.edgeLength = polygon.edgeLength;
    }
    public String getName(){
        return this.name;
    }
    public int getEdgeAmount(){
        return this.edgeAmount;
    }
    public double getEdgeLength(){
        return this.edgeLength;
    }
    public void setName(String name){
        this.name = name;
    }
    public void setEdgeAmount(int edgeAmount){
        this.edgeAmount = edgeAmount;
    }
    public void setEdgeLength(double edgeLength){
        this.edgeLength = edgeLength;
    }
    public String getPolygon(){
        if (edgeAmount < 3){  
            return "null";
        }
        if (edgeAmount == 3){  // so sanh giua int vs so khong bo trong ''
            return "Triangle";
        }
        if (edgeAmount == 4){  
            return "Quadrangle";
        }
        if (edgeAmount == 5){  
            return "Pentagon";
        }
        if (edgeAmount == 6){  
            return "Hexagon";
        }
        else {
            return "Polygon has the number of edges greater than 6";
        }
    }
    public double getPerimeter(){
        return this.edgeAmount * this.edgeLength;
    }
    public double getArea(){
        double a = 0;
        if (edgeAmount == 3){
            a = 0.433;
        }
        if (edgeAmount == 4){
            a = 1;
        }
        if (edgeAmount == 5){
            a = 1.72;
        }
        if (edgeAmount == 6){
            a = 2.595;
        }
        if (edgeAmount >6){
            return -1;
        }
        return edgeLength * edgeLength * a;
    }
    public String toString(){
        return "name - Polygon - Area               " + name + " - " + getPolygon() + " - " + getArea();
    }
    
}