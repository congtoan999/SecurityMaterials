class testRegularPolygon{
    public static void main(String[] args){
        RegularPolygon r1 = new RegularPolygon("kk",3,6.7);
        RegularPolygon r2 = new RegularPolygon("khang",2,6.7);
        RegularPolygon r3 = new RegularPolygon("kieu",5,5.2);
        RegularPolygon r4 = new RegularPolygon("ki",6,5.2);
        RegularPolygon r5 = new RegularPolygon("ko",4);
        System.out.println(r1.getPolygon());
        System.out.println(r2.getPolygon());
        System.out.println(r3.getPerimeter());
        System.out.println(r3.getArea());
        System.out.println(r4.getArea());
        System.out.println(r5);
        System.out.println(r4);
    }
}