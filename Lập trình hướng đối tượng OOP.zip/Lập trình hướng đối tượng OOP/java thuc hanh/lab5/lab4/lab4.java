class lab4{
    public static void main(String[] args){
        Club c1 = new Club("ok" , 5,4,6);
        Club c2 = new Club("on" , 2,4,1);

        System.out.println(c1.numMatchesPlayed());
        System.out.println(c1.isFinish());
        System.out.println(c2.isFinish());
        System.out.println(c1.getPoints());
        System.out.println(c1.toString());
        System.out.println(c2.getDraws());
        c2.setDraws(2);
        System.out.println(c2.getDraws());
        System.out.println(c2);
        
    }
}