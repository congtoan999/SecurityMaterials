class lab2{
    public static void main(String[] args){
        String str = "Nguyen Le Trong Tin";
        System.out.println(shortName(str));
        System.out.println(hashtagName(str));
        System.out.println(upperCaseAllVowel(str));
        System.out.println(upperCaseAllN(str));
    }
    
    public static String shortName(String str){
        String[] tu = str.split("\\s+");
        return tu[tu.length-1] + " " + tu[0];  //length khong co () do nó bị tách chuỗi thành đơn rồi
    }
    public static String hashtagName(String str){
        String[] tu = str.split("\\s+");
        return "#" + tu[tu.length-1]+ tu[0]; //[] dung de truy cap vao cac phan tu cua mang
                                             //() dung de truy cap phuong thuc
    }
    public static String upperCaseAllVowel(String str){
        String kq ="";
        for(int i = 0 ; i< str.length();i++){
            char ch =  str.charAt(i);
            if (ch == 'u' || ch =='e'|| ch == 'o'|| ch == 'a'|| ch =='i'){ //' ' dung de dinh nghia ki tu duy nhat
                kq += Character.toUpperCase(ch);
            }
            // else if(Character.isLetter(ch)){
            //     kq +=Character.toLowerCase(ch);
            // }
            else{
                kq += ch;
            }
        }
        return kq;
    }
    public static String upperCaseAllN(String str){
        String kq = "";
        for(int i = 0;i<str.length();i++){
            char ch = str.charAt(i);
            if (ch == 'n'){
                kq += Character.toUpperCase(ch);
            }
            else {
                kq += ch;
            }
        }
        return kq;
    }
}