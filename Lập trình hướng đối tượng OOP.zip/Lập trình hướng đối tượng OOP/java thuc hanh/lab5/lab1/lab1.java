import java.util.Scanner;

class lab1{
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        int[] a = {3,4,5,7,8,10,1,2};
        System.out.println("a : "+maxEven(a));
        System.out.println("b : "+minOdd(a));
        System.out.println("c : "+sumMEMO(a));
        System.out.println("d : "+sumEven(a));
        System.out.println("e : "+prodOdd(a));
        System.out.println("f : "+idxFirstEven(a));
        System.out.println("g : "+idxLastOdd(a));
        //cau h : 
        System.out.println("nhap n : ");
        int n = scanner.nextInt();              
        int[] a1 = input(n);                    //
        for (int i = 0; i < n; i++) {   //neu kh co 4 dong nay  
            System.out.print(a1[i] + " ");      //se ra mot mang 
        }                                       //ma ra day dia chi kh bk
    }
    public static int maxEven(int[] a){
        int max = a[0];
        for(int i = 0;i<a.length;i++){
            if (a[i]%2 == 0 && max<a[i] )
            {
                max = a[i];
            }  
        }
        return max;
    }
    public static int minOdd(int[] a){
        int min = a[0];
        for (int i = 0;i<a.length;i++){
            if(min > a[i] && a[i] %2 != 0){
                min= a[i];
            }
        }
        return min;
    }
    public static int sumMEMO(int[] a){
        int tong = maxEven(a) + minOdd(a);
        return tong;
    }
    public static int sumEven(int[] a){
        int total =0;
        for(int i = 0;i<a.length;i++){
            if(a[i] %2 == 0){
                total += a[i];
            }
        }
        return total;
    }
    public static int prodOdd(int[] a){
        int prod =1;
        for(int i = 0;i<a.length;i++){
            if (a[i] %2!=0){
                prod *= a[i];
            }
        }
        return prod;
    }
    public static int idxFirstEven(int[] a){
        int i ;
        for(i = 0;i<a.length;i++){
            if (a[i] %2==0){
                break;
            }
        }
        return i;   
    }
    public static int idxLastOdd(int[] a){
        int i;
        for (i = a.length-1;i>0;i--){
            if (a[i]%2!=0)
            break;
        }
        return i;
    }
    // viet mang moi gom n phan tu nhap tu ban phim
    public static int[] input(int n){
        Scanner sc = new Scanner (System.in);
        int[] a1 = new int[n];
        for(int i = 0;i<n;i++){
            a1[i] = sc.nextInt();
        }
        return a1 ;
    }
}