﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kiem_tra
{
    public class Pilot
    {
        [Key]
        public int Identifier { get; set; }

        [Required]
        [MaxLength(100)]
        public string Name { get; set; }

        // Liên kết 1-N với Flight
        public virtual ICollection<Flight> Flights { get; set; } = new List<Flight>();
    }
}
