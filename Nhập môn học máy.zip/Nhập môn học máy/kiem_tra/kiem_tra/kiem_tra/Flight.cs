﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kiem_tra
{
    public class Flight
    {
        [Key]
        public int Id { get; set; }

        public float Price { get; set; }

        [Required]
        [MaxLength(100)]
        public string Departure { get; set; }

        [Required]
        [MaxLength(100)]
        public string Destination { get; set; }

        public int FlightNumber { get; set; }

        // Liên kết với Airplane
        [ForeignKey("Airplane")]
        public int AirplaneId { get; set; }
        public virtual Airplane Airplane { get; set; }

        // Liên kết với Pilot
        [ForeignKey("Pilot")]
        public int PilotId { get; set; }
        public virtual Pilot Pilot { get; set; }
    }
}
