import java.util.PriorityQueue;
import java.util.Comparator;

public class Main {
    public static void main(String[] args) {
        Comparator<Integer> comparator = new Comparator<Integer>() {
            @Override
            public int compare(Integer num1, Integer num2) {
                if (num1 % 2 == 0 && num2 % 2 != 0) {
                    return -1;
                } else if (num1 % 2 != 0 && num2 % 2 == 0) {
                    return 1;
                } else if (num1 % 2 == 0) {
                    return num2 - num1;
                } else {
                    return num1 - num2;
                }
            }
        };
        PriorityQueue<Integer> queue = new PriorityQueue<>(comparator);
        // Thêm các số vào hàng đợi
        queue.add(1);
        queue.add(2);
        queue.add(8);
        queue.add(7);
        queue.add(5);
        queue.add(9);
        queue.add(3);
        queue.add(4);
        queue.add(6);

        // In ra các số từ hàng đợi
        while (!queue.isEmpty()) {
            System.out.print(queue.poll() + " ");
        }
    }
}
// (tùy chọn) Sử dụng lớp java.util.PriorityQueue<> để xây dựng một đống
// số nguyên trong đó
// a. Số chẵn có mức độ ưu tiên cao hơn số lẻ
// b. Trong số các số chẵn, số nguyên lớn hơn có mức độ ưu tiên cao hơn
// c. Trong số lẻ, số nguyên nhỏ hơn có mức độ ưu tiên cao