class Node {
    int key;
    Node left, right;

    Node(int item) {
        key = item;
        left = right = null;
    }
}

class BinaryTree {
    Node root;

    int countLeaves(Node node) {
        if (node == null)
            return 0;
        if (node.left == null && node.right == null)
            return 1;
        else
            return countLeaves(node.left) + countLeaves(node.right);
    }

    int size(Node node) {
        if (node == null)
            return 0;
        else
            return (size(node.left) + 1 + size(node.right));
    }

    int sumKeysInRange(Node node, int a, int b) {
        if (node == null)
            return 0;
        if (node.key < a)
            return sumKeysInRange(node.right, a, b);
        if (node.key > b)
            return sumKeysInRange(node.left, a, b);
        return node.key + sumKeysInRange(node.left, a, b) + sumKeysInRange(node.right, a, b);
    }

    int countOneChildParents(Node node) {
        if (node == null || (node.left == null && node.right == null))
            return 0;
        if (node.left == null || node.right == null)
            return 1 + countOneChildParents(node.left) + countOneChildParents(node.right);
        return countOneChildParents(node.left) + countOneChildParents(node.right);
    }

    public static void main(String[] args) {
        BinaryTree tree = new BinaryTree();
        tree.root = new Node(1);
        tree.root.left = new Node(2);
        tree.root.right = new Node(3);
        tree.root.left.left = new Node(4);
        tree.root.left.right = new Node(5);

        System.out.println("Number of leaves is : " + tree.countLeaves(tree.root));
        System.out.println("Size of the tree is : " + tree.size(tree.root));
        System.out.println("Sum of keys in range [1, 3] is : " + tree.sumKeysInRange(tree.root, 1, 3));
        System.out.println("Number of nodes with one child is : " + tree.countOneChildParents(tree.root));
    }
}
