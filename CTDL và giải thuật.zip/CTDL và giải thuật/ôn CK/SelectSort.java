import java.util.Arrays;

class SelectSort {
    public static void selectSort(int arr[]) {
        for (int i = 0; i < arr.length - 1; i++) {
            int min = i;
            for (int j = i + 1; j < arr.length; j++) {
                if (arr[min] > arr[j]) {
                    min = j;
                }
            }

            int tem = arr[min];
            arr[min] = arr[i];
            arr[i] = tem;
            System.out.println(Arrays.toString(arr));

        }
    }

    public static void main(String[] args) {
        int arr[] = { 2, 5, 4, 3, 7, 1 };
        selectSort(arr);
        // System.out.println(Arrays.toString(arr));
    }
}

// Lần lặp thứ 1: [5, 40, 46, 55, 54, 89, 50, 73, 23, 47]
// Lần lặp thứ 2: [5, 23, 46, 55, 54, 89, 50, 73, 40, 47]
// Lần lặp thứ 3: [5, 23, 40, 55, 54, 89, 50, 73, 46, 47]
// Lần lặp thứ 4: [5, 23, 40, 46, 54, 89, 50, 73, 55, 47]
// Lần lặp thứ 5: [5, 23, 40, 46, 47, 89, 50, 73, 55, 54]
// Lần lặp thứ 6: [5, 23, 40, 46, 47, 50, 89, 73, 55, 54]
// Lần lặp thứ 7: [5, 23, 40, 46, 47, 50, 54, 73, 55, 89]
// Lần lặp thứ 8: [5, 23, 40, 46, 47, 50, 54, 55, 73, 89]
// Lần lặp thứ 9: [5, 23, 40, 46, 47, 50, 54, 55, 73, 89]
// Lần lặp thứ 10: [5, 23, 40, 46, 47, 50, 54, 55, 73, 89]
