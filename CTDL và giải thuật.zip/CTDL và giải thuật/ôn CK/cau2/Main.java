public class Main {
    public static void main(String[] args) {
        int num = 10;
        System.out.println("Binary of " + num + ":");
        binary(num);
        System.out.println();

        num = 12345;
        System.out.println("Reverse of " + num + ": " + reverse(num, 0));

        String str = "Hello, World!";
        char c = 'o';
        System.out.println("Count of '" + c + "' in \"" + str + "\": " + countChar(str, c));

        num = 255;
        System.out.println("Hexadecimal of " + num + ": " + decimalToHex(num));

        int[] arr = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
        System.out.println("Elements at indices 1, 2, 4, 8, ..., 2^k in the array:");
        printArray(arr, 1);

        num = 123456;
        System.out.println("Even digits in " + num + ":");
        printEvenDigits(num);
    }

    // hàm đệ quy để in ra dạng nhị phân của một số nguyên dương.
    public static int binary(int n) {

        if (n > 0) {
            return n / 2;
        }
        return -1;
    }

    // hàm đệ quy để đảo ngược một số nguyên dương.
    static int reverse(int n, int rev) {
        if (n == 0) {
            return rev;
        } else {
            return reverse(n / 10, rev * 10 + n % 10);
        }
    }

    // hàm đệ quy để đếm số lần xuất hiện của một ký tự trong chuỗi.
    static int countChar(String s, char c) {
        if (s.length() == 0) {
            return 0;
        } else if (s.charAt(0) == c) {
            return 1 + countChar(s.substring(1), c);
        } else {
            return countChar(s.substring(1), c);
        }
    }

    // hàm đệ quy để chuyển một số nguyên dương ở dạng thập phân thành thập lục
    // phân. Hàm trả về một chuỗi.
    static String decimalToHex(int n) {
        char[] hexDigits = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
        if (n < 16) {
            return Character.toString(hexDigits[n]);
        } else {
            return decimalToHex(n / 16) + hexDigits[n % 16];
        }
    }

    // hàm đệ quy in ra các phần tử của một mảng các số nguyên có chỉ số 1, 2, 4, 8,
    // …, 2k, …
    static void printArray(int[] arr, int i) {
        if (i < arr.length) {
            System.out.println(arr[i]);
            printArray(arr, i * 2);
        }
    }

    // hàm đệ quy để in ra các chữ số chẵn của một số nguyên dương. Ví dụ: a =
    // 123456, thứ tự in: 6 4 2
    static void printEvenDigits(int n) {
        if (n > 0) {
            int digit = n % 10;
            if (digit % 2 == 0) {
                System.out.println(digit);
            }
            printEvenDigits(n / 10);
        }
    }
}