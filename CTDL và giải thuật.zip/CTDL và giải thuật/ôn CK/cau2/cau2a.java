
public class cau2a {
    public static int binary(int n) {
        if (n == 0) {
            return 0;
        }
        return n % 2 + 10 * binary(n / 2);
    }

    public static int swap(int n, int reserse) {
        if (n == 0) {
            return reserse;
        }
        int temp = n % 10;
        reserse = reserse * 10 + temp;
        return swap(n / 10, reserse);
    }

    public static int dem(String str, char a) {
        if (str.length() == 0) {
            return 0;
        }
        int count = (str.charAt(0) == a) ? 1 : 0;
        return count + dem(str.substring(1), a);
    }

    public static void hai_k(int[] arr, int index) {
        if (index < arr.length) {
            System.out.print(arr[index] + " ");
            hai_k(arr, index * 2);
        }
    }

    public static void in_chan(int n) {
        if (n > 0) {
            int digit = n % 10;
            if (digit % 2 == 0) {
                System.out.print(digit + " ");
            }
            in_chan(n / 10);
        }
    }

    public static void main(String[] args) {
        System.out.println(binary(10));
        System.out.println(swap(123, 0));
        System.out.println(dem("toooi khongggg cos gi muon nois ca moi nguwi yen lanrgj", 'g'));
        int[] arr = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17 };
        hai_k(arr, 1);
        in_chan(123456);
    }
}
