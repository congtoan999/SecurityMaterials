public class cau2d {
    public static String decToHexRecursive(int n) {
        if (n < 16) {
            return Integer.toHexString(n).toUpperCase();
        } else {
            return decToHexRecursive(n / 16) + Integer.toHexString(n % 16).toUpperCase();
        }
    }

    public static void main(String[] args) {
        System.out.println(decToHexRecursive(124234));
    }
}
// Hàm decToHexRecursive chuyển đổi một số nguyên từ hệ thập phân sang hệ thập
// lục phân bằng cách sử dụng phương pháp đệ quy. Đây là cách nó hoạt động với
// số 124234:

// Gọi decToHexRecursive(124234). Vì 124234 lớn hơn 16, chúng ta chia 124234 cho
// 16 để có được 7764 dư 10. Số 10 trong hệ thập lục phân là ‘A’, vì vậy chúng
// ta ghi nhớ ‘A’ và tiếp tục với phần nguyên 7764.

// Gọi decToHexRecursive(7764). Vì 7764 lớn hơn 16, chúng ta chia 7764 cho 16 để
// có được 485 dư 4. Số 4 trong hệ thập lục phân là ‘4’, vì vậy chúng ta ghi nhớ
// ‘4A’ và tiếp tục với phần nguyên 485.

// Gọi decToHexRecursive(485). Vì 485 lớn hơn 16, chúng ta chia 485 cho 16 để có
// được 30 dư 5. Số 5 trong hệ thập lục phân là ‘5’, vì vậy chúng ta ghi nhớ
// ‘54A’ và tiếp tục với phần nguyên 30.

// Gọi decToHexRecursive(30). Vì 30 lớn hơn 16, chúng ta chia 30 cho 16 để có
// được 1 dư 14. Số 14 trong hệ thập lục phân là ‘E’, vì vậy chúng ta ghi nhớ
// ‘E54A’ và tiếp tục với phần nguyên 1.

// Cuối cùng, gọi decToHexRecursive(1). Vì 1 nhỏ hơn 16, chúng ta trả về ‘1’.
// Kết hợp với chuỗi đã ghi nhớ, chúng ta có được ‘1E54A’.
