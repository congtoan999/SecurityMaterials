class Node {
    int key;
    Node left, right;

    public Node(int key) {
        this.key = key;
        this.left = this.right = null;
    }
}

public class BinarySearchTree {
    Node root;

    // Các hàm đệ quy
    // 1) Đếm số lượng lá
    public int countLeaves(Node node) {
        if (node == null) {
            return 0;
        }
        if (node.left == null && node.right == null) {
            return 1;
        }
        return countLeaves(node.left) + countLeaves(node.right);
    }

    // 2) Tính kích thước của một cây con
    public int computeSubtreeSize(Node node) {
        if (node == null) {
            return 0;
        }
        return 1 + computeSubtreeSize(node.left) + computeSubtreeSize(node.right);
    }

    // 3) Tính tổng các khóa trong khoảng [a, b]
    public int sumKeysInRange(Node node, int a, int b) {
        if (node == null) {
            return 0;
        }
        int sum = 0;
        if (node.key >= a && node.key <= b) {
            sum += node.key;
        }
        if (node.key > a) {
            sum += sumKeysInRange(node.left, a, b);
        }
        if (node.key < b) {
            sum += sumKeysInRange(node.right, a, b);
        }
        return sum;
    }

    // 4) Đếm số lượng nút có một con
    public int countNodesWithOneChild(Node node) {
        if (node == null || (node.left == null && node.right == null)) {
            return 0;
        }
        if (node.left == null || node.right == null) {
            return 1 + countNodesWithOneChild(node.left) + countNodesWithOneChild(node.right);
        }
        return countNodesWithOneChild(node.left) + countNodesWithOneChild(node.right);
    }

    public static void main(String[] args) {
        BinarySearchTree tree = new BinarySearchTree();

        // Xây dựng cây nhị phân tìm kiếm
        tree.root = new Node(20);
        tree.root.left = new Node(10);
        tree.root.right = new Node(30);
        tree.root.left.left = new Node(5);
        tree.root.left.right = new Node(15);
        tree.root.right.left = new Node(25);
        tree.root.right.right = new Node(35);

        // Gọi các hàm đệ quy
        int leafCount = tree.countLeaves(tree.root);
        int subtreeSize = tree.computeSubtreeSize(tree.root);
        int sumInRange = tree.sumKeysInRange(tree.root, 10, 50);
        int nodesWithOneChild = tree.countNodesWithOneChild(tree.root);

        // In kết quả
        System.out.println("Number of leaves: " + leafCount);
        System.out.println("Size of subtree: " + subtreeSize);
        System.out.println("Sum of keys in range: " + sumInRange);
        System.out.println("Number of nodes with one child: " + nodesWithOneChild);
    }
}
