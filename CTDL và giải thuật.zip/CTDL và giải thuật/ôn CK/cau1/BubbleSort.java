package cau1;

import java.util.*;

class BubbleSort {
    public static void bubbleSort(int[] a) {
        for (int i = 1; i < a.length; ++i) {
            for (int j = 0; j < a.length - 1; ++j) {
                if (a[j] > a[j + 1]) {
                    int temp = a[j];
                    a[j] = a[j + 1];
                    a[j + 1] = temp;
                    System.out.println(Arrays.toString(a));
                }
            }
        }
    }

    public static void main(String[] args) {
        int[] numbers = new int[] { 3, 4, 2, 1, 9, 8, 5 };
        System.out.println("Mảng ban đầu: " + Arrays.toString(numbers));
        bubbleSort(numbers);
    }
}

// Lần lặp thứ 1: [40, 46, 55, 54, 5, 50, 73, 23, 47, 89]
// Lần lặp thứ 2: [40, 46, 54, 5, 50, 55, 23, 47, 73, 89]
// Lần lặp thứ 3: [40, 46, 5, 50, 54, 23, 47, 55, 73, 89]
// Lần lặp thứ 4: [40, 5, 46, 50, 23, 47, 54, 55, 73, 89]
// Lần lặp thứ 5: [5, 40, 46, 23, 47, 50, 54, 55, 73, 89]
// Lần lặp thứ 6: [5, 40, 23, 46, 47, 50, 54, 55, 73, 89]
// Lần lặp thứ 7: [5, 23, 40, 46, 47, 50, 54, 55, 73, 89]
// Lần lặp thứ 8: [5, 23, 40, 46, 47, 50, 54, 55, 73, 89]
// Lần lặp thứ 9: [5, 23, 40, 46, 47, 50, 54, 55, 73, 89]
// Lần lặp thứ 10: [5, 23, 40, 46, 47, 50, 54, 55, 73, 89]
