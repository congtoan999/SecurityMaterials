package cau1;

import java.util.*;

class MyComparator implements Comparator<Integer> {
    @Override
    public int compare(Integer a, Integer b) {
        if (a % 2 == 0 && b % 2 != 0) {
            return -1;
        } else if (a % 2 != 0 && b % 2 == 0) {
            return 1;
        } else if (a % 2 == 0 && b % 2 == 0) {
            return a - b;
        } else {
            return b - a;
        }
    }
}

public class main1 {
    public static void main(String[] args) {
        Integer[] arr = { 89, 40, 46, 55, 54, 5, 50, 73, 23, 47 };
        Arrays.sort(arr, new MyComparator());
        System.out.println(Arrays.toString(arr));
    }
}
