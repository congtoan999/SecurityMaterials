import java.util.*;

class InsertionSort {
    public static void InserSort(int[] a) {
        for (int i = 1; i < a.length; i++) {
            int next = a[i];
            int j;
            for (j = i - 1; j >= 0 && a[j] > next; j--) {
                a[j + 1] = a[j];
                System.out.println(Arrays.toString(a));
            }
            a[j + 1] = next;
        }
    }

    public static void main(String[] args) {
        int[] a = { 3, 2, 1, 4, 0 };
        InserSort(a);
        System.out.println(Arrays.toString(a));
    }
}

// Giả sử chúng ta có một mảng số nguyên như sau: [4, 3, 2, 10, 12, 1, 5, 6].

// Bước 1: Xem phần tử đầu tiên [4] như một mảng đã được sắp xếp. Mảng còn lại
// là [3, 2, 10, 12, 1, 5, 6].

// Bước 2: Chèn phần tử tiếp theo 3 vào vị trí thích hợp trong mảng đã được sắp
// xếp. Bây giờ mảng đã được sắp xếp là [3, 4] và mảng còn lại là [2, 10, 12, 1,
// 5, 6].

// Bước 3: Tiếp tục với phần tử tiếp theo 2, chèn nó vào vị trí thích hợp trong
// mảng đã được sắp xếp. Bây giờ mảng đã được sắp xếp là [2, 3, 4] và mảng còn
// lại là [10, 12, 1, 5, 6].

// Chúng ta tiếp tục quá trình này cho đến khi tất cả các phần tử đều đã được
// chèn vào mảng đã được sắp xếp. Kết quả cuối cùng sẽ là một mảng đã được sắp
// xếp theo thứ tự tăng dần: [1, 2, 3, 4, 5, 6, 10, 12].

// Lần lặp thứ 1: [40, 89, 46, 55, 54, 5, 50, 73, 23, 47]
// Lần lặp thứ 2: [40, 46, 89, 55, 54, 5, 50, 73, 23, 47]
// Lần lặp thứ 3: [40, 46, 55, 89, 54, 5, 50, 73, 23, 47]
// Lần lặp thứ 4: [40, 46, 54, 55, 89, 5, 50, 73, 23, 47]
// Lần lặp thứ 5: [5, 40, 46, 54, 55, 89, 50, 73, 23, 47]
// Lần lặp thứ 6: [5, 40, 46, 50, 54, 55, 89, 73, 23, 47]
// Lần lặp thứ 7: [5, 40, 46, 50, 54, 55, 73, 89, 23, 47]
// Lần lặp thứ 8: [5, 23, 40, 46, 50, 54, 55, 73, 89, 47]
// Lần lặp thứ 9: [5, 23, 40, 46, 47, 50, 54, 55, 73, 89]
