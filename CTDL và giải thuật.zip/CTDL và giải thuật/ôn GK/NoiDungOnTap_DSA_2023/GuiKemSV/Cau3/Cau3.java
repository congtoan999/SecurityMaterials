import java.util.Stack;

public class Cau3 {
    public static int calculate(String[] expression){
        Stack<Integer> s = new Stack<>();
        for(String c : expression){
            if (isNumber(c)){
                s.push(Integer.parseInt(c));
            }else{
                int o1 = s.pop();
                int o2 = s.pop();
                int kq = toan_hang(o1,o2,c);
                s.push(kq);
            }
        }
        return s.pop();
    }

    private static int toan_hang(int o1, int o2, String c){
        if(c.equals("+")){
            return o1+o2;
        }else if (c.equals("-")){
            return o1 - o2;
        }else{
            throw new IllegalArgumentException("khong ton tai");
        }
    }
    private static boolean isNumber(String str) {
        return str.matches("0|([1-9][0-9]*)");
        }
    public static void main(String args[]){
		System.out.println(calculate(new String[]{"31", "12", "+"}));
	}
}