class CharLinkedList implements ListInterface{
    Node head;
    public CharLinkedList(){
        head = null;
    }
    public Node getHead(){
        return head;
    }

    public void addFirst(char data){
        head = new Node(data,head);
    }

    public void print(){
        if(head == null){
            System.out.println("khng co gia tri nao");
        }
        else{
            Node tmp = head;
            System.out.print(tmp.getData());
            tmp = tmp.getNext();
            while(tmp != null){
                System.out.print("-->" + tmp.getData());
                tmp = tmp.getNext();
            }
            System.out.println();
        }
    }
    public boolean addAfterFirstKey(char data, char key){
        if(head == null){
            return false;
        }else{
            Node tmp = head;
            while(tmp!= null){
                if (tmp.getData() == key){
                    Node moi = new Node(data,tmp.getNext());
                    tmp.setNext(moi);
                    return true;
                }
                tmp = tmp.getNext();
            }
            return false;
        }

    }
    public boolean addLast(char data){
        if (head == null){
            return false;
        }else{
            Node tmp = head;
            while(tmp!=null){
                if (tmp.getNext() == null){
                    Node n = new Node(data,tmp.getNext());
                    tmp.setNext(n);
                    return true;
                }
                tmp = tmp.getNext();
            }
            return false;
        }
    }
    public int largestCharPostition(){
        if (head == null){
            return -1;
        }else{
            Node tmp =head;
            int vi_tri = 0;
            char ma_lon_nhat = tmp.getData();
            int vt_tri_lon_nhat = 0;
            while(tmp != null){
                if(tmp.getData()> ma_lon_nhat){
                    ma_lon_nhat = tmp.getData();
                    vt_tri_lon_nhat = vi_tri;
                }
                tmp = tmp.getNext();
                vi_tri ++;
            }
            return vt_tri_lon_nhat;
        }
    }
}