import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class FacebookGraphAnalysis {
    public static List<Edge> docDoThiTuTep(String duongDan) {
        List<Edge> edges = new ArrayList<>();
        try {
            Scanner scanner = new Scanner(new File(duongDan));
            while (scanner.hasNextLine()) {
                String[] line = scanner.nextLine().split("\\s+");
                int u = Integer.parseInt(line[0]);
                int v = Integer.parseInt(line[1]);
                edges.add(new Edge(u, v));
            }
            scanner.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return edges;
    }

    public static int laySoDinh(List<Edge> edges) {
        Set<Integer> vertices = new HashSet<>();
        for (Edge edge : edges) {
            vertices.add(edge.u);
            vertices.add(edge.v);
        }
        return vertices.size();
    }

    public static int laySoCanh(List<Edge> edges) {
        return edges.size();
    }

    public static int demSoThanhPhan(List<Edge> edges) {
        Map<Integer, List<Integer>> danhSachKe = taoDanhSachKe(edges);
        Set<Integer> daTham = new HashSet<>();
        int soThanhPhan = 0;

        for (Integer dinh : danhSachKe.keySet()) {
            if (!daTham.contains(dinh)) {
                soThanhPhan++;
                dfs(dinh, danhSachKe, daTham);
            }
        }

        return soThanhPhan;
    }

    private static void dfs(Integer dinh, Map<Integer, List<Integer>> danhSachKe, Set<Integer> daTham) {
        daTham.add(dinh);
        for (Integer ke : danhSachKe.getOrDefault(dinh, Collections.emptyList())) {
            if (!daTham.contains(ke)) {
                dfs(ke, danhSachKe, daTham);
            }
        }
    }

    public static Map.Entry<Integer, Integer> nguoiCoNhieuBanNhat(List<Edge> edges) {
        Map<Integer, Integer> bacCuaDinh = new HashMap<>();
        for (Edge edge : edges) {
            bacCuaDinh.put(edge.u, bacCuaDinh.getOrDefault(edge.u, 0) + 1);
            bacCuaDinh.put(edge.v, bacCuaDinh.getOrDefault(edge.v, 0) + 1);
        }

        Map.Entry<Integer, Integer> dinhMax = null;
        for (Map.Entry<Integer, Integer> dinh : bacCuaDinh.entrySet()) {
            if (dinhMax == null || dinh.getValue() > dinhMax.getValue()) {
                dinhMax = dinh;
            }
        }

        return dinhMax;
    }

    public static List<Integer> banChung(List<Edge> edges, int u, int v) {
        Map<Integer, List<Integer>> danhSachKe = taoDanhSachKe(edges);
        List<Integer> banChung = new ArrayList<>();

        List<Integer> banU = danhSachKe.getOrDefault(u, Collections.emptyList());
        List<Integer> banV = danhSachKe.getOrDefault(v, Collections.emptyList());

        for (Integer ban : banU) {
            if (banV.contains(ban)) {
                banChung.add(ban);
            }
        }

        return banChung;
    }

    private static Map<Integer, List<Integer>> taoDanhSachKe(List<Edge> edges) {
        Map<Integer, List<Integer>> danhSachKe = new HashMap<>();
        for (Edge edge : edges) {
            danhSachKe.computeIfAbsent(edge.u, k -> new ArrayList<>()).add(edge.v);
            danhSachKe.computeIfAbsent(edge.v, k -> new ArrayList<>()).add(edge.u);
        }
        return danhSachKe;
    }

    public static void main(String[] args) {
        String duongDan = "facebook_combined.txt"; // Thay thế bằng đường dẫn thực tế đến tập dữ liệu của bạn
        List<Edge> edges = docDoThiTuTep(duongDan);

        // (a) Xây dựng đồ thị ở định dạng Danh sách Cạnh
        System.out.println("Đồ thị ở định dạng Danh sách Cạnh:");
        for (Edge edge : edges) {
            System.out.println(edge);
        }

        // (b) Tìm số đỉnh
        int soDinh = laySoDinh(edges);
        System.out.println("\nSố đỉnh: " + soDinh);

        // (c) Tìm số cạnh
        int soCanh = laySoCanh(edges);
        System.out.println("Số cạnh: " + soCanh);

        // (d) Đếm số thành phần của đồ thị
        int soThanhPhan = demSoThanhPhan(edges);
        System.out.println("Số thành phần của đồ thị: " + soThanhPhan);

        // (e) Tìm người có nhiều bạn nhất
        Map.Entry<Integer, Integer> nguoiNhieuBanNhat = nguoiCoNhieuBanNhat(edges);
        System.out.println("Người có nhiều bạn nhất: Người " + nguoiNhieuBanNhat.getKey() +
                " với " + nguoiNhieuBanNhat.getValue() + " bạn");

        // (f) Tìm danh sách bạn chung giữa người u và người v
        int nguoiU = 1; // Thay thế bằng ID người dùng cho người u
        int nguoiV = 2; // Thay thế bằng ID người dùng cho người v
        List<Integer> banChung = banChung(edges, nguoiU, nguoiV);
        System.out.println("\nDanh sách bạn chung giữa Người " + nguoiU + " và Người " + nguoiV + ": " + banChung);
    }
}

class Edge {
    int u, v;

    public Edge(int u, int v) {
        this.u = u;
        this.v = v;
    }

    @Override
    public String toString() {
        return "(" + u + ", " + v + ")";
    }
}
