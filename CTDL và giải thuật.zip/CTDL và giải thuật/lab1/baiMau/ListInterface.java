public interface ListInterface<E> {
    public void addFirst(E item);

    public int size();

    public void print();

    public boolean isEmpty();

    public Node<E> getHead();

    public E getFirst();

    public void addAfter(Node<E> curr, E item);

    // public void addLast ;
}