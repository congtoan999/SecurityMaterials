class Test {
    public static void main(String[] args) {
        MyLinkedList<Integer> lst = new MyLinkedList<>();
        lst.addFirst(2);
        lst.addFirst(3);
        lst.addFirst(1);
        lst.addFirst(0);
        lst.print();
        if (lst.isEmpty()) {
            System.out.println("trong");
        } else {
            System.out.println("khong trong");
        }

        // lst.getHead();
        // lst.getFirst();
        lst.find(2);
        Node<Integer> tontai = lst.find(3);
        if (tontai != null) {
            lst.addAfter(tontai, 4);
            lst.print();
        } else {
            System.out.println("khong tim thay");
        }
    }
}