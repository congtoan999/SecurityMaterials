import java.util.*;

class MyLinkedList<E> implements ListInterface<E> {
    private Node<E> head;
    private int numNode;

    public void addFirst(E item) {
        head = new Node<E>(item, head);
        numNode++;

    }

    public int size() {
        return numNode;
    }

    public void print() {
        
        if (head != null) {
            System.out.print(" " + head.getData());
            head = head.getNext();
            while (head != null) {
                System.out.print("-->" + head.getData());
                head = head.getNext();

            }

        }
    }

    public boolean isEmpty() {
        System.out.println();
        if (numNode == 0) {
            return true;
        }
        return false;
    }

    public Node<E> getHead() {

        return head;
    }

    public E getFirst() {
        if (head == null) {
            throw new NoSuchElementException("khong ton tai");
        }
        return head.getData();
    }

    public void addAfter(Node<E> curr, E item) {
        if (curr == null) {
            addFirst(item);
        } else {
            Node<E> newNode = new Node<E>(item, curr.getNext());
            curr.setNext(newNode);
            numNode++;
        }
    }

}