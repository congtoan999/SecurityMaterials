public class Test {
    public static void main(String[] args) {
        Fraction f = new Fraction();
        Fraction f1 = new Fraction(4, 5);
        Fraction f2 = new Fraction(f1);

        System.out.println(f.toString());
        System.out.println(f1.toString());
        System.out.println(f2.toString());

        System.out.println(f.eaquals(f2));
        System.out.println(f1.eaquals(f2));
        System.out.println(f.eaquals(f2));
    }
}
