public class Fraction {
    private int numer = 0;
    private int denom = 1;

    public Fraction() {
        this.numer = 0;
        this.denom = 1;
    }

    public Fraction(int x, int y) {
        this.numer = x;
        if (this.denom != 0) {
            this.denom = y;
        } else {
            throw new IllegalArgumentException("mau khong the la 0 ");
        }

    }

    public Fraction(Fraction f) {
        this.numer = f.numer;
        this.denom = f.denom;
    }

    public String toString() {
        return "Fraction[" + numer + " " + denom + " ]";
    }

    public boolean eaquals(Object f) {
        if (this == f) { // neu this cung loai voi object
            return true;
        } else if (this == null || getClass() != f.getClass()) { // khac loai
            return false;
        } else {
            Fraction other = (Fraction) f;
            return numer == other.numer && denom == other.denom;
        }

    }
}
