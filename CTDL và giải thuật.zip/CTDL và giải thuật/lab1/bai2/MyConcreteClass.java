class MyConcreteClass<E> extends MyAbstractClass<E> {
    Node<E> head;

    public MyConcreteClass() {
        this.head = null;
    }

    public void add(E data) {
        Node<E> newNode = new Node<>(data);

        if (head == null) {
            head = newNode;
        } else {
            newNode.next = head;
            head = newNode;
        }
    }

    public void print() {
        Node<E> current = head;
        while (current != null) {
            System.out.print(current.data + " -> ");
            current = current.next;
        }
        System.out.println();
    }

    @Override
    public E removeCurr(Node<E> curr) {
        if (curr == null) {
            return null;
        }

        if (head == curr) {
            E data = head.data;
            head = head.next;
            return data;
        }

        Node<E> current = head;
        while (current != null && current.next != curr) {
            current = current.next;
        }

        if (current != null) {
            E data = current.next.data;
            current.next = current.next.next;
            return data;
        }

        return null;
    }
}