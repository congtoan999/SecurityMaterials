abstract class MyAbstractClass<E> {
    public abstract E removeCurr(Node<E> curr);
}