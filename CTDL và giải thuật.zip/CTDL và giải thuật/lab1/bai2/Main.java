public class Main {
    public static void main(String[] args) {
        MyConcreteClass<Integer> myList = new MyConcreteClass<>();

        myList.add(1);
        myList.add(2);
        myList.add(3);

        System.out.print("Danh sách ban đầu: ");
        myList.print(); // Kết quả: 3 -> 2 -> 1 ->

        Node<Integer> nodeToRemove = myList.head.next; // Xóa nút thứ 2 (chứa giá trị 2)
        Integer removedData = myList.removeCurr(nodeToRemove);

        if (removedData != null) {
            System.out.println("Đã loại bỏ: " + removedData);
        }

        System.out.print("Danh sách sau khi loại bỏ: ");
        myList.print(); // Kết quả: 3 -> 1 ->
    }
}