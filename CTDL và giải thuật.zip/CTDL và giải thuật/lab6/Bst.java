public class Bst {
   Node root;

   public Bst() {
      root = null;
   }

   public void NLR(Node x) {
      if (x != null) {
         System.out.println(x.key + " ");
         NLR(x.left);
         NLR(x.right);
      }
   }

   public void LNR(Node x) {
      if (x != null) {
         NLR(x.left);
         System.out.println(x.key + " ");
         NLR(x.right);
      }
   }

   public void LRN(Node x) {
      if (x != null) {
         NLR(x.left);
         NLR(x.right);
         System.out.println(x.key + " ");
      }
   }

   public Node Search(Node x, Integer key) {
      if (x == null) {
         return null;
      }
      int c = key.compareTo(x.key);
      if (c < 0) {
         return Search(x.left, key);
      } else if (c > 0) {
         return Search(x.right, key);
      } else {
         return x;
      }
   }

   public Node insert(Node root, int key) {

      if (root == null) {
         return new Node(key);
      }
      if (key < root.key) {
         root.left = insert(root.left, key);
      } else if (key > root.key) {
         root.right = insert(root.right, key);
      }
      return root;

   }

   public void insert(int key) {
      root = insert(root, key);
   }

   public Node min(Node x) {
      if (x.left == null)
         return x;
      else
         return min(x.left);
   }

   public Node max(Node x) {
      if (x.right == null)
         return x;
      else
         return max(x.right);
   }

   public Node dltMin(Node x) {
      if (x.left == null)
         return x.right;
      x.left = dltMin(x.left);
      return x;
   }

   public void dltMax() {
      dltMax(root);
   }

   // cau2
   public void createTree(String strKey) {
      if (strKey == null || strKey.isEmpty()) {
         return;
      }

      String[] keyStrings = strKey.split(" ");
      for (String keyStr : keyStrings) {
         try {
            Integer key = Integer.parseInt(keyStr);
            root = insert(root, key);
         } catch (NumberFormatException e) {
            System.out.println(keyStr);
         }
      }
   }

   // cau3
   public void RNL(Node x) {
      if (x != null) {
         NLR(x.right);
         System.out.println(x.key + " ");
         NLR(x.left);
      }
   }

   // ex 4
   public boolean contains(Integer key) {
      if (Search(root, key) != null) {
         return true;
      }
      return false;
   }

   // cau5
   public Node dltMax(Node x) {
      if (x.right == null)
         return x.left;
      x.right = dltMax(x.right);
      return x;
   }

   public Node dmax() {
      return dltMax(root);
   }

   // ex 6
   public Node deleteNode(Node x, Integer key) {
      if (x == null) {
         return null;
      }
      int cmp = key.compareTo(x.key);
      if (cmp < 0) {
         x.left = deleteNode(x.left, key);
      } else if (cmp > 0) {
         x.right = deleteNode(x.right, key);
      } else {
         if (x.right == null) {
            return x.left;
         }
         if (x.left == null) {
            return x.right;
         }
         // nút có 2 nút con: Lấy nút kế thừa (nhỏ nhất ở cây con bên phải)
         x.key = min(x.right).key;
         x.right = dltMin(x.right);
      }
      return x;
   }

   public void delete(Integer key) {
      root = deleteNode(root, key);
   }

   // ex7
   public int height(Node node) {
      if (node == null) {
         return -1;
      }
      return 1 + Math.max(height(node.left), height(node.right));
   }

   public int height() {
      return height(root);
   }

   // ex8
   public Integer sum(Node node) {
      if (node == null) {
         return 0;
      }
      return node.key + sum(node.left) + sum(node.right);
   }

   public Integer sum() {
      return sum(root);
   }

   // ex9
   public Integer sumEven(Node node) {
      if (node == null) {
         return 0;
      }
      return ((node.key % 2 == 0) ? node.key : 0) + sumEven(node.left) +
            sumEven(node.right);
   }

   public Integer sumEven() {
      return sumEven(root);
   }

   // ex 10
   public int countLeaves(Node node) {
      if (node == null) {
         return 0;
      }
      return (node.left == null && node.right == null ? 1 : 0) +
            countLeaves(node.left) + countLeaves(node.right);
   }

   public int countLeaves() {
      return countLeaves(root);
   }

   // ex11
   public Integer sumEvenLeaves(Node node) {
      if (node == null) {
         return 0;
      }
      return (node.left == null && node.right == null && node.key % 2 == 0 ? node.key : 0) + sumEvenLeaves(node.right)
            + sumEvenLeaves(node.left);
   }

   public int sumEvenLeaves() {
      return sumEvenLeaves(root);
   }

   public int size(Node x) {
      if (x == null) {
         return 0;
      }
      return size(x.left) + size(x.right) + 1;
   }

   public int size() {
      return size(root);
   }

   // ex 12
   public void bfs(Node x) {
      int i = 0;
      while (i <= height()) {
         printLevel(x, i);
         i++;
      }
   }

   public void printLevel(Node x, int level) {
      if (x == null) {
         return;
      }
      if (level == 0) {
         System.out.println(x.key + " ");
      } else {
         printLevel(x.left, level - 1);
         printLevel(x.right, level - 1);
      }
   }

   public void bfs() {
      bfs(root);
   }
}
