import java.util.*;
import java.util.Vector;

class IntegerTriple {
    private Integer weight;
    private Integer source;
    private Integer dest;

    public IntegerTriple(Integer w, Integer s, Integer d) {
        weight = w;
        source = s;
        dest = d;
    }

    public Integer getWeight() {
        return weight;
    }

    public Integer getSource() {
        return source;
    }

    public Integer getDest() {
        return dest;
    }

    @Override
    public String toString() {
        return weight + " " + source + " " + dest;
    }
}

public class EdgeList {
    private Vector<IntegerTriple> edges;

    public EdgeList() {
        edges = new Vector<IntegerTriple>();
    }

    public void addEdge(int w, int u, int v) {
        edges.add(new IntegerTriple(w, u, v));
    }

    public void printGraph() {
        for (int i = 0; i < edges.size(); i++) {
            System.out.println(edges.get(i));
        }
    }

    public int getNoVertices() {
        Set<Integer> vertices = new HashSet<Integer>();
        for (IntegerTriple edge : edges) {
            vertices.add(edge.getSource());
            vertices.add(edge.getDest());
        }
        return vertices.size();
    }

    public int getNoEdges() {
        return edges.size();
    }

    public ArrayList<Integer> getNeighbors(int u) {
        ArrayList<Integer> neighbors = new ArrayList<Integer>();
        for (IntegerTriple edge : edges) {
            if (edge.getSource() == u) {
                neighbors.add(edge.getDest());
                continue;
            }
            if (edge.getDest() == u) {
                neighbors.add(edge.getSource());
            }
        }
        return neighbors;
    }

    public boolean hasEgde(int u, int v) {
        for (IntegerTriple edge : edges) {
            if ((edge.getSource() == u && edge.getDest() == v) || (edge.getSource() == v && edge.getDest() == u)) {
                return true;
            }
        }
        return false;
    }
}