import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class AdjacencyMatrix {
    private int[][] adj;
    private final int MAX_NUMBER_OF_VERTICES;

    public AdjacencyMatrix(int vertices) {
        MAX_NUMBER_OF_VERTICES = vertices;
        adj = new int[MAX_NUMBER_OF_VERTICES][MAX_NUMBER_OF_VERTICES];
    }

    public void addEdge(int vertexSource, int vertexDestination, int weight) {
        try {
            adj[vertexSource][vertexDestination] = weight;
            adj[vertexDestination][vertexSource] = weight;
        } catch (ArrayIndexOutOfBoundsException indexBounce) {
            System.out.println("The vertex is invalid");
        }
    }

    public void printGraph() {
        for (int i = 0; i < MAX_NUMBER_OF_VERTICES; i++) {
            for (int j = 0; j < MAX_NUMBER_OF_VERTICES; j++) {
                System.out.print(adj[i][j] + " ");
            }
            System.out.println();
        }
    }

    public static AdjacencyMatrix readGraphFromFile(String path) {
        try {
            File f = new File(path);
            Scanner sc = new Scanner(f);
            int v = Integer.parseInt(sc.nextLine());
            AdjacencyMatrix temp = new AdjacencyMatrix(v);
            int i = 0;
            while (sc.hasNextLine()) {
                int j = 0;
                String[] data = sc.nextLine().split(" ");
                for (String s : data) {
                    temp.addEdge(i, j, Integer.parseInt(s));
                    j++;
                }
                i++;
            }
            sc.close();
            return temp;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }

    public int getNovertices() {
        return MAX_NUMBER_OF_VERTICES;
    }

    public int getNoEdges() {
        int count = 0;
        for (int i = 0; i < MAX_NUMBER_OF_VERTICES; i++) {
            for (int j = 0; j < MAX_NUMBER_OF_VERTICES; j++) {
                if (adj[i][j] != 0) {
                    count++;
                }
            }
        }
        return count / 2;
    }

    public ArrayList<Integer> getNeighbors(int u) {
        ArrayList<Integer> neighbors = new ArrayList<Integer>();
        for (int i = 0; i < MAX_NUMBER_OF_VERTICES; i++) {
            if (adj[u][i] != 0) {
                neighbors.add(i);
            }
        }
        return neighbors;
    }

    public boolean hasEgde(int u, int v) {
        if (adj[u][v] != 0) {
            return true;
        }
        return false;
    }

    public AdjacencyList conertToAL() {
        AdjacencyList al = new AdjacencyList(MAX_NUMBER_OF_VERTICES);
        for (int i = 0; i < MAX_NUMBER_OF_VERTICES; i++) {
            for (int j = 0; j < MAX_NUMBER_OF_VERTICES; i++) {
                if (adj[i][j] != 0) {
                    al.addEdge(i, j);
                }
            }
        }
        return al;
    }

    public void BFS(int s) {
        boolean visited[] = new boolean[MAX_NUMBER_OF_VERTICES];
        Queue<Integer> queue = new LinkedList<Integer>();
        visited[s] = true;
        queue.offer(s);
        while (!queue.isEmpty()) {
            int x = queue.poll();
            System.out.print(x + " ");

            for (int i = 0; i < MAX_NUMBER_OF_VERTICES; i++) {
                if (adj[x][i] != 0 && visited[i] == false) {
                    queue.offer(i);
                    visited[i] = true;
                }
            }
        }
    }

    public void DFS_recur(int v, boolean[] visited) {
        visited[v] = true;

        System.out.print(v + " ");
        for (int i = 0; i < MAX_NUMBER_OF_VERTICES; i++) {
            if (adj[v][i] != 0 && visited[i] == false) {
                DFS_recur(i, visited);
            }
        }
    }

    public void DFS_recur_util(int s) {
        boolean[] visited = new boolean[MAX_NUMBER_OF_VERTICES];
        DFS_recur(s, visited);
    }

    public void DFS(int s) {
        boolean visited[] = new boolean[MAX_NUMBER_OF_VERTICES];
        Stack<Integer> stack = new Stack<Integer>();
        stack.push(s);
        while (!stack.empty()) {
            int x = stack.pop();

            if (visited[x] == false) {
                System.out.println(x + " ");
                visited[x] = true;
            }

            for (int i = MAX_NUMBER_OF_VERTICES - 1; i >= 0; i--) {
                if (adj[x][i] != 0 && visited[i] == false) {
                    stack.push(i);
                }
            }
        }
    }

    public boolean isReachable(int u, int v) {
        boolean visited[] = new boolean[MAX_NUMBER_OF_VERTICES];
        Queue<Integer> queue = new LinkedList<Integer>();
        visited[u] = true;
        queue.offer(u);
        while (!queue.isEmpty()) {
            int x = queue.poll();

            for (int i = 0; i < MAX_NUMBER_OF_VERTICES; i++) {
                if (adj[x][i] != 0 && visited[i] == false) {
                    queue.offer(i);
                    visited[i] = true;
                }
            }
        }
        return visited[v];
    }
}