import java.io.*;
import java.util.*;

public class Main {
    public static AdjacencyList readGraphFromFileAL(String path) {
        try {
            File f = new File(path);
            Scanner sc = new Scanner(f);
            int v = Integer.parseInt(sc.nextLine());
            AdjacencyList temp = new AdjacencyList(v);

            while (sc.hasNextLine()) {
                String[] data = sc.nextLine().split(" ");
                int i = Integer.parseInt(data[0]);
                for (int j = 1; j < data.length; j++) {
                    int u = Integer.parseInt(data[j]);
                    temp.addEdge(i, u);
                }
            }
            sc.close();
            return temp;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static EdgeList readGraphFromFileAL(String path) {
        try {
            File f = new File(path);
            Scanner sc = new Scanner(f);
            EdgeList temp = new EdgeList();
            while (sc.hasNextLine()) {
                String[] data = sc.nextLine().split(" ");
                int w = Integer.parseInt(data[0]);
                int u = Integer.parseInt(data[1]);
                int v = Integer.parseInt(data[2]);
                temp.addEdge(w, u, v);
            }
            sc.close();
            return temp;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static void main(String args[]) {
        AdjacencyMatrix adjMatrix = AdjacencyMatrix.readGraphFromFile();
        String adjListFilePath = "graph_adjacency_list.txt";
        AdjacencyList adjList = readGraphFromFileAL(adjListFilePath);
        System.out.println("Adjacency List representation:");
        System.out.println(adjList);

        // Assuming you have a file named "graph_edge_list.txt" for edge list
        // representation
        String edgeListFilePath = "graph_edge_list.txt";
        EdgeList edgeList = readGraphFromFileEL(edgeListFilePath);
        System.out.println("\nEdge List representation:");
        System.out.println(edgeList);
    }
}
