import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class GraphOperations {
    private int[][] adjacencyMatrix;
    private int numberOfVertices;

    // Constructor
    public GraphOperations(String filePath) {
        try {
            readGraphFromFile(filePath);
        } catch (FileNotFoundException e) {
            System.err.println("Error: File not found. Please provide a valid file path.");
        }
    }

    // Task (a): Read the graph from the file and print the AM on the screen.
    private void readGraphFromFile(String filePath) throws FileNotFoundException {
        try (Scanner scanner = new Scanner(new File(filePath))) {
            // Assuming the first line of the file contains the number of vertices
            numberOfVertices = scanner.nextInt();
            adjacencyMatrix = new int[numberOfVertices][numberOfVertices];

            // Assuming the rest of the file contains the adjacency matrix
            for (int i = 0; i < numberOfVertices; i++) {
                for (int j = 0; j < numberOfVertices; j++) {
                    adjacencyMatrix[i][j] = scanner.nextInt();
                }
            }
        }
    }

    // Task (b): Count the number of vertices.
    public int getNumberOfVertices() {
        return numberOfVertices;
    }

    // Task (c): Count the number of edges.
    public int getNumberOfEdges() {
        int edgeCount = 0;
        if (adjacencyMatrix != null) {
            for (int i = 0; i < numberOfVertices; i++) {
                for (int j = 0; j < numberOfVertices; j++) {
                    if (adjacencyMatrix[i][j] == 1) {
                        edgeCount++;
                    }
                }
            }
        }
        return edgeCount;
    }

    // Task (d): Enumerate neighbors of a vertex u.
    public void enumerateNeighbors(int u) {
        if (adjacencyMatrix != null && u >= 0 && u < numberOfVertices) {
            System.out.print("Neighbors of vertex " + u + ": ");
            for (int v = 0; v < numberOfVertices; v++) {
                if (adjacencyMatrix[u][v] == 1) {
                    System.out.print(v + " ");
                }
            }
            System.out.println();
        } else {
            System.err.println("Error: Vertex index out of bounds or adjacency matrix is null.");
        }
    }

    // Task (e): Check the existence of edge (u, v).
    public boolean hasEdge(int u, int v) {
        if (adjacencyMatrix != null && u >= 0 && u < numberOfVertices && v >= 0 && v < numberOfVertices) {
            return adjacencyMatrix[u][v] == 1;
        } else {
            System.err.println("Error: Invalid vertex indices or adjacency matrix is null.");
            return false;
        }
    }

    public static void main(String[] args) {
        String filePath = "path\\to\\your\\graph\\file.txt";
        GraphOperations graph = new GraphOperations(filePath);

        // Example usage:
        System.out.println("Number of vertices: " + graph.getNumberOfVertices());
        System.out.println("Number of edges: " + graph.getNumberOfEdges());

        int vertexToCheck = 0;
        graph.enumerateNeighbors(vertexToCheck);

        int u = 1, v = 2;
        System.out.println("Edge (" + u + ", " + v + ") exists: " + graph.hasEdge(u, v));
    }
}
