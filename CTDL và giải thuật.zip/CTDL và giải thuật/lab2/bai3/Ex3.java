import java.util.Stack;

class Ex3{
    public static String reverseString(String str){
        Stack<Character> stk = new Stack<Character>();
        for(int i = 0; i<str.length();i++){
            stk.push(str.charAt(i));
        }
        String result = "";
        while(!stk.isEmpty()){
            result += stk.pop();

        }
        return result;
    }

    public static void main(String[] args ){
        System.out.println(reverseString("TDTT TDTT 123"));
    }
}