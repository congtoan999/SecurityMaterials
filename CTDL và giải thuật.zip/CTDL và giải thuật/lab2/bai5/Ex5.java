import java.util.*;

public class Ex5 {
    public static void main(String[] args){
        Queue<Integer> q = new LinkedList<>();
        Stack<Integer> s1 = new Stack<>();
        Stack<Integer> s2 = new Stack<>();
        int[] arr = {2,3,6,1,4};
        for (int x : arr){
            q.add(x);
            s1.push(x);
        }
        while(!s1.isEmpty()){
            s2.push(s1.pop());
        }
        System.out.println(q);
        System.out.println(s2);
    }
}
