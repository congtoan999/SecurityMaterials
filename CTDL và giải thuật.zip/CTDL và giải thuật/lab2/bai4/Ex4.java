import java.util.Stack;

public class Ex4 {
    public static boolean checkBalanced(String str){
        Stack <Character> stk= new Stack <Character>();
        for (int i = 0;i< str.length();i++){
            if (str.charAt(i) == '{' || str.charAt(i) == '(' || str.charAt(i) == '[' ){
                stk.push(str.charAt(i));
            }
            else if(str.charAt(i)== ')' || str.charAt(i) == ']' || str.charAt(i) == '}'){
                if(stk.isEmpty()){
                    return false;
                }
                else if(!isMatching(stk.pop(),str.charAt(i))){
                    return false;
                }
            }
        }
        if(!stk.isEmpty()){
            return false;
        }else {
            return true;
        }
    }

    private static boolean isMatching(char ch1, char ch2){
        if(ch1 == '(' && ch2 == ')'){
            return true;
        }
        else if(ch1 == '[' && ch2 == ']'){
            return true;
        }
        else if(ch1 == '{' && ch2 == '}'){
            return true;
        }
        else{
            return false;
        }
    }


    public static void main(String[] args){
        System.out.println(checkBalanced("1+[132 + 3] - {3-2-3}"));
        System.out.println(checkBalanced("1+[132 + 3] - 3-2-3}"));
    }
    
}
