import java.util.Stack;

public class Ex2 {
    public static double recursion(int n){
        if(n == 1){
            return 3;
        }
        return Math.pow(2, n) + Math.pow(n, 2) + recursion(n-1);
    }

    public static double stackCal(int n){
        Stack<Double> stk= new Stack<Double>();
        while(n > 1){
            stk.push(Math.pow(2, n)+Math.pow(n, 2));
            n--;
        }
        stk.push(3.0);
        double result = 0;
        while(!stk.isEmpty()){
            result += stk.pop();
        }
        return result;
    }

    public static void main(String[] args){
        System.out.println(recursion(4));
        System.out.println(stackCal(4));
    }
}
