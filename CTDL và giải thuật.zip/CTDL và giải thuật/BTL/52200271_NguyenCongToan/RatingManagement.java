import java.util.*;
import java.io.*;

public class RatingManagement {
    private ArrayList<Rating> ratings;
    private ArrayList<Movie> movies;
    private ArrayList<User> users;

    // @Requirement 1
    public RatingManagement(String moviePath, String ratingPath, String userPath) {
        this.movies = loadMovies(moviePath);
        this.users = loadUsers(userPath);
        this.ratings = loadEdgeList(ratingPath);
    }

    private ArrayList<Rating> loadEdgeList(String ratingPath) {
        ArrayList<Rating> rats = new ArrayList<>();
        try {
            File f = new File(ratingPath);
            Scanner scanner = new Scanner(f);
            boolean dong_dau = false;

            while (scanner.hasNextLine()) {
                String dong = scanner.nextLine();
                if (!dong_dau) {
                    dong_dau = true;
                    continue;
                }
                String[] num = dong.split(",");
                if (num.length == 4) {
                    int userId = Integer.parseInt(num[0]);
                    int movieId = Integer.parseInt(num[1]);
                    int rating = Integer.parseInt(num[2]);
                    long timestamps = Long.parseLong(num[3]);
                    Rating r = new Rating(userId, movieId, rating, timestamps);
                    rats.add(r);
                }
            }
            scanner.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return rats;
    }

    private ArrayList<Movie> loadMovies(String moviePath) {
        ArrayList<Movie> m = new ArrayList<>();
        try {
            File f = new File(moviePath);
            Scanner sc = new Scanner(f);
            boolean dong_dau = false;

            while (sc.hasNextLine()) {
                String dong = sc.nextLine();
                if (!dong_dau) {
                    dong_dau = true;
                    continue;
                }
                String[] num = dong.split(",");
                if (num.length == 3) {
                    String title = num[1];
                    ArrayList<String> gen = new ArrayList<>();
                    String the_loai[] = num[2].split("-");
                    for (int i = 0; i < the_loai.length; i++) {
                        gen.add(the_loai[i]);
                    }
                    Movie new_movie = new Movie(Integer.parseInt(num[0]), title, gen);
                    m.add(new_movie);
                } else {
                    continue;
                }
            }
            sc.close();
        } catch (FileNotFoundException c) {
            c.printStackTrace();
        }
        return m;
    }

    private ArrayList<User> loadUsers(String userPath) {
        ArrayList<User> u = new ArrayList<>();
        try {
            File f = new File(userPath);
            Scanner sc = new Scanner(f);
            boolean dong_dau = false;
            while (sc.hasNextLine()) {
                String dong = sc.nextLine();
                if (!dong_dau) {
                    dong_dau = true;
                    continue;
                }
                String[] word = dong.split(",");
                if (word.length == 5) {
                    String gender = word[1];
                    String occupation = word[3];
                    String zipCode = word[4];
                    u.add(new User(Integer.parseInt(word[0]), gender, Integer.parseInt(word[2]), occupation, zipCode));
                }
            }
            sc.close();
        } catch (FileNotFoundException c) {
            c.printStackTrace();
        }
        return u;
    }

    public ArrayList<Movie> getMovies() {
        return movies;
    }

    public ArrayList<User> getUsers() {
        return users;
    }

    public ArrayList<Rating> getRating() {
        return ratings;
    }

    // @Requirement 2
    public ArrayList<Movie> findMoviesByNameAndMatchRating(int userId, int rating) {
        ArrayList<Movie> resultM = new ArrayList<>();

        for (Rating r : ratings) {
            if (r.getUserId() == userId && r.getRating() >= rating) {
                boolean movie_exist = false;
                for (Movie m : movies) {
                    if (m.getId() == r.getMovieId()) {
                        movie_exist = true;
                        resultM.add(m);
                        break;
                    }
                }
                if (!movie_exist) {
                    System.out.println(" loi " + r.getMovieId());
                }
            }
        }
        bubbleSort(resultM);
        return resultM;
    }

    private void bubbleSort(ArrayList<Movie> movies) {
        int n = movies.size();
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                Movie m1 = movies.get(j);
                Movie m2 = movies.get(j + 1);
                if (m1.getName().compareTo(m2.getName()) > 0) {
                    Movie tem = m1;
                    movies.set(j, m2);
                    movies.set(j + 1, tem);
                }
            }
        }
    }

    // Requirement 3
    public ArrayList<User> findUsersHavingSameRatingWithUser(int userId, int movieId) {
        ArrayList<User> people = new ArrayList<>();

        double nguoi_dung = -1;
        for (Rating r : ratings) {
            if (r.getUserId() == userId && r.getMovieId() == movieId) {
                nguoi_dung = r.getRating();
                break;
            }
        }
        if (nguoi_dung == -1) {
            return people;
        }
        for (Rating r : ratings) {
            if (r.getMovieId() == movieId && r.getRating() == nguoi_dung && r.getUserId() != userId) {
                for (User u : users) {
                    if (u.getId() == r.getUserId()) {
                        people.add(u);
                        break;
                    }
                }
            }
        }
        return people;
    }

    // Requirement 4
    public ArrayList<String> findMoviesNameHavingSameReputation() {
        ArrayList<String> kq = new ArrayList<>();
        ArrayList<Movie> movies = getMovies();
        ArrayList<Rating> r = getRating();
        ArrayList<Integer> new_list = new ArrayList<>();
        ArrayList<Integer> title = new ArrayList<>();
        for (int i = 0; i < r.size(); i++) {
            if (r.get(i).getRating() > 3) {
                if (new_list.contains(r.get(i).getMovieId())) {
                    if (!title.contains(r.get(i).getMovieId())) {
                        title.add(r.get(i).getMovieId());
                    }
                } else {
                    new_list.add(r.get(i).getMovieId());
                }
            }
        }
        for (int i = 0; i < movies.size(); i++) {
            if (title.contains(movies.get(i).getId())) {
                kq.add(movies.get(i).getName());
            }
        }
        kq = merge_sort(kq, 0, kq.size() - 1);
        return kq;
    }

    private ArrayList<String> merge_sort(ArrayList<String> l, int left_index, int right_index) {
        if (left_index < right_index) {
            int number_mid = (left_index + right_index) / 2;
            merge_sort(l, left_index, number_mid);
            merge_sort(l, number_mid + 1, right_index);
            merge(l, left_index, number_mid, right_index);
        }
        return l;
    }

    private void merge(ArrayList<String> l, int left_index, int mid_index, int right_index) {
        int sz_left = mid_index - left_index + 1;
        int sz_right = right_index - mid_index;
        ArrayList<String> L_left = new ArrayList<>();
        ArrayList<String> L_right = new ArrayList<>();

        for (int i = 0; i < sz_left; i++) {
            L_left.add(l.get(left_index + i));
        }
        for (int j = 0; j < sz_right; j++) {
            L_right.add(l.get(mid_index + 1 + j));
        }
        int i = 0, j = 0;
        int k = left_index;
        while (i < sz_left && j < sz_right) {
            if (L_left.get(i).compareTo(L_right.get(j)) <= 0) {
                l.set(k, L_left.get(i));
                i++;
            } else {
                l.set(k, L_right.get(j));
                j++;
            }
            k++;
        }
        while (i < sz_left) {
            l.set(k, L_left.get(i));
            i++;
            k++;
        }
        while (j < sz_right) {
            l.set(k, L_right.get(j));
            j++;
            k++;
        }
    }

    // @Requirement 5
    public ArrayList<String> findMoviesMatchOccupationAndGender(String occupation, String gender, int k, int rating) {
        HashSet<Integer> user_ids = new HashSet<>();
        HashSet<Integer> movie_ids = new HashSet<>();
        ArrayList<String> kq = new ArrayList<>();

        for (User u : getUsers()) {
            if (u.getOccupation().equals(occupation) && u.getGender().equals(gender)) {
                user_ids.add(u.getId());
            }
        }

        for (Rating r : getRating()) {
            if (r.getRating() == rating && user_ids.contains(r.getUserId())) {
                movie_ids.add(r.getMovieId());
            }
        }

        for (Movie m : getMovies()) {
            if (movie_ids.contains(m.getId())) {
                kq.add(m.getName());
            }
        }

        for (int i = 0; i < kq.size() - 1; i++) {
            for (int j = 0; j < kq.size() - i - 1; j++) {
                if (kq.get(j).compareTo(kq.get(j + 1)) > 0) {
                    String tem = kq.get(j);
                    kq.set(j, kq.get(j + 1));
                    kq.set(j + 1, tem);
                }
            }
        }
        ArrayList<String> kq2 = new ArrayList<>();
        for (int i = 0; i < Math.min(k, kq.size()); i++) {
            kq2.add(kq.get(i));
        }

        return kq2;
    }

    // @Requirement 6
    public ArrayList<String> findMoviesByOccupationAndLessThanRating(String occupation, int k, int rating) {
        ArrayList<String> resultM = new ArrayList<>();
        HashSet<String> new_h = new HashSet<>();
        for (User u : users) {
            if (u.getOccupation().equals(occupation)) {
                for (Rating rs : ratings) {
                    if (rs.getUserId() == u.getId() && rs.getRating() < rating) {
                        Movie movie = null;
                        for (Movie m : movies) {
                            if (m.getId() == rs.getMovieId()) {
                                movie = m;
                                break;
                            }
                        }
                        if (movie != null) {
                            String movie_name = movie.getName();
                            new_h.add(movie_name);
                        }
                    }
                }
            }
        }
        for (String movie_name : new_h) {
            resultM.add(movie_name);
        }
        for (int i = 0; i < resultM.size() - 1; i++) {
            for (int j = 0; j < resultM.size() - i - 1; j++) {
                if (resultM.get(j).compareTo(resultM.get(j + 1)) > 0) {
                    String tem = resultM.get(j);
                    resultM.set(j, resultM.get(j + 1));
                    resultM.set(j + 1, tem);
                }
            }
        }
        while (resultM.size() > k) {
            resultM.remove(resultM.size() - 1);
        }
        return resultM;
    }

    // @Requirement 7
    public ArrayList<String> findMoviesMatchLatestMovieOf(int userId, int rating, int k) {
        ArrayList<String> kq = new ArrayList<>();
        ArrayList<String> result1 = new ArrayList<>();
        ArrayList<Integer> a = new ArrayList<>();
        ArrayList<Integer> b = new ArrayList<>();
        HashMap<Integer, String> c = new HashMap<>();
        int movie_ID = 0;
        long max_times = 0;
        String gender = "";
        for (User u : users) {
            if (u.getId() == userId) {
                gender = u.getGender();
                break;
            }
        }
        for (User u : users) {
            if (u.getId() != userId && u.getGender().equals(gender)) {
                if (!a.contains(u.getId())) {
                    a.add(u.getId());
                }
            }
        }
        for (Rating r : ratings) {
            if (r.getUserId() == userId) {
                if (r.getTimestamps() > max_times && r.getRating() >= rating) {
                    max_times = r.getTimestamps();
                    movie_ID = r.getMovieId();
                }
            }
            if (r.getUserId() > userId) {
                break;
            }
        }
        ArrayList<String> genres = new ArrayList<>();
        for (Movie movie : movies) {
            if (movie.getId() == movie_ID) {
                genres = movie.getGenres();
                break;
            }
        }
        for (Movie movie : movies) {
            if (!b.contains(movie.getId())) {
                for (String genre : genres) {
                    if (movie.getGenres().contains(genre)) {
                        b.add(movie.getId());
                        boolean found = false;
                        for (Integer n_k : c.keySet()) {
                            if (n_k.equals(movie.getId())) {
                                found = true;
                                break;
                            }
                        }
                        if (!found) {
                            c.put(movie.getId(), movie.getName());
                        }
                        break;
                    }
                }
            }
        }
        for (Rating r : ratings) {
            if (r.getUserId() != userId && b.contains(r.getMovieId())
                    && r.getRating() >= rating && a.contains(r.getUserId())) {
                boolean found = false;
                for (Integer n_k : c.keySet()) {
                    if (n_k.equals(r.getMovieId())) {
                        found = true;
                        break;
                    }
                }
                if (found) {
                    kq.add(c.get(r.getMovieId()));
                    c.remove(r.getMovieId());
                }
            }
        }
        kq = merge_sort(kq);
        for (int i = 0; i < k; i++) {
            result1.add(kq.get(i));
        }
        return result1;
    }

    private ArrayList<String> merge_sort(ArrayList<String> l) {
        if (l.size() <= 1) {
            return l;
        }
        ArrayList<String> left = new ArrayList<>();
        ArrayList<String> right = new ArrayList<>();
        int mid = l.size() / 2;

        for (int i = 0; i < mid; i++) {
            left.add(l.get(i));
        }

        for (int i = mid; i < l.size(); i++) {
            right.add(l.get(i));
        }
        left = merge_sort(left);
        right = merge_sort(right);
        return merge(left, right);
    }

    private ArrayList<String> merge(ArrayList<String> left, ArrayList<String> right) {
        ArrayList<String> kq = new ArrayList<>();

        while (!left.isEmpty() && !right.isEmpty()) {
            if (left.get(0).compareTo(right.get(0)) < 0) {
                kq.add(left.remove(0));
            } else {
                kq.add(right.remove(0));
            }
        }
        kq.addAll(left);
        kq.addAll(right);
        return kq;
    }
}