class Ex1{
    public double prod_recur(int a, int b){
        if (b == 0){
            return 0;
        }
        else if (b>0){
            return a+ prod_recur(a, b-1);
        }else{
            return -prod_recur(a, -b);
        }
    }
    public int bin2dec(int n, int exp){
        if (n  ==0){
            return 0;
        }
        return 2*bin2dec(n/10,0) +n%10  ;
        
    }
    public int demSoluongSoChinhPhuong(int[] a, int k) {
        if (k == 0) {
            return 0;
        }
        int count = demSoluongSoChinhPhuong(a, k - 1);
        if (Math.sqrt(a[k - 1]) % 1 == 0) {
            count++;
        }
        return count;
    }


    public int maxDigit(int n) {
        if (n < 10) {
            return n;
        } else {
            int max = maxDigit(n / 10);
            int last = n % 10;
            return Math.max(max, last);
        }
    }

    public int maxElement(int[] a, int n) {
        if (n == 0) {
            return a[0];
        }
        return Math.max(a[n], maxElement(a, n - 1));
    }

    public int search(int a[], int n, int key) {
        if (n < 0) {
            return -1;
        }
        if (a[n] == key) {
            return n;
        }
        return search(a, n - 1, key);
    }
    public int findLastEvenPosition(int a[], int n) {
        if (n < 0) {
            return -1;
        }
        if (a[n] % 2 == 0) {
            return n;
        }
        return findLastEvenPosition(a, n - 1);
    }
}