class Ex3{
    public static double A(int n, int k){
        if (k == 1){
            return n;
        }
        if (k>1){
            return n+ A(n,k-1);
        }else{
            throw new IllegalArgumentException("gia tri khong hop le");
        }
    }

    public static double F(int n){
        if (n == 0){
            return 0;
        }
        if (n == 1){
            return 1;
        }
        return F(n-1) + F(n-2);
    }
    public static void main(String[] args){
        System.out.println(A(4,5));
        System.out.println(F(3));
    }
}