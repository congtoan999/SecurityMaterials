public class Test {
    public static void main(String[] args){
        Ex1 e = new Ex1();
        System.out.println(e.prod_recur(3,4)); 
        System.out.println(e.bin2dec(1011,0)); 
        int[] a ={3,1,2,3,4,9,8};
        // System.out.println(e.demSoluongSoChinhPhuong(a)); 
        System.out.println(e.bin2dec(1011,0)); 
    }
    
}
