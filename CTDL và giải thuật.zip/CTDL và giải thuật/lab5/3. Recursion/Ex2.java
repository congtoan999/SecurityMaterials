class Ex2{
    public static double tong_2_mu(double n){
        if (n == 1){
            return 2;
        }
        return  Math.pow(2, n) + tong_2_mu(n-1) ; 
        
    }
    public static double tong_x_cong1_tat_ca_chia_2 (double n){
        if(n == 0){
            return 0;
        }
        return (n+1)/2 +tong_x_cong1_tat_ca_chia_2(n-1);
    }
    public static double de_quy_n (double n){
        if(n <= 1){
            return 1;
        }
        return n *de_quy_n(n-1);
    }
    public static double i_luy_thua_chia_i_tru_1_luy_thua (double n){
        if(n ==2){
            return 2;
        }
        return de_quy_n(n)/de_quy_n(n-1) + i_luy_thua_chia_i_tru_1_luy_thua(n -1);
    }

    public static double tong (double n){
        if (n == 1){
            return 0;
        }
        return n*(n-1) + tong(n-1);
    }
    public static double tich (double n){
        if (n == 1){
            return 1;
        }
        return n* tich(n - 1);
    }

    public static void main(String[] args){
        // System.out.println(tong_2_mu(3));
        // System.out.println(tong_x_cong1_tat_ca_chia_2(3));
        System.out.println(i_luy_thua_chia_i_tru_1_luy_thua(3));
        System.out.println(tong(3));
        System.out.println(tich(3));
    }
}