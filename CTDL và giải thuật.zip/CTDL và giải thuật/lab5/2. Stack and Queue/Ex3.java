import java.util.Stack;

import java.util.*;

import java.util.Queue;

public class Ex3 {
    public static boolean isPalindrome(int n){
        Stack<Character> s = new Stack<>();
        Queue<Character> q = new LinkedList<>();
        String tu = Integer.toString(n);

        for (char c : tu.toCharArray()){
            s.push(c);
            q.add(c);
        }

        while( !s.empty() || !q.isEmpty() ){
            if (s.pop() != q.poll()){
                return false;
            }
        }
        return true;
    }
    public static void main(String[] args){
        int n1 = 102;
        int n2 = 101;
        int n3 = 256652;
        System.out.println(isPalindrome(n1));        
        System.out.println(isPalindrome(n2));        
        System.out.println(isPalindrome(n3));        
    }
}
