import java.util.Stack;

class Ex2{
    public static int InfixToPostfix(String s){
        Stack<Integer> stack = new Stack<>();
        String[] Split_ch = s.split(" ");
        for(String ch :Split_ch){
             if(isNumber(ch)){
                stack.push(Integer.parseInt(ch));
            }else {
                int a = stack.pop();
                int b = stack.pop();
                int res = toantu(b,a,ch);
                stack.push(res);
            } 
        } 
        return stack.pop();
    } 
    private static boolean isNumber(String ch) {
        return ch.matches("0|([1-9][0-9]*)");
    }
    private static int toantu(int a, int b ,String ch){
        if(ch.equals("+")){
            return a+b;
        }else if(ch.equals("-")){
            return a-b;
        }else if(ch.equals("*")){
            return a*b;
        }else if(ch.equals("/")){
            return a/b;
        }else{
            throw new IllegalArgumentException("khong ton tai");
        }
    }
    public static void main(String[] args){
        String result_String = "9 2 - 6 * 7 + 7 /";
        System.out.println(InfixToPostfix(result_String));        
    }
}