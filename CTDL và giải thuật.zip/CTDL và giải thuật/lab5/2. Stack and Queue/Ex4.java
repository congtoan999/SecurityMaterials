import java.util.Stack;

public class Ex4 {
    public static String dao_cau(String str){
        String[] tu = str.split(" ");
        Stack<String> stack = new Stack<>();
        StringBuilder s = new StringBuilder();
        for (String c : tu){
            stack.push(c);
        }
        while(!stack.empty()){
            s.append(stack.pop()).append(" ");
        }
        return s.toString();
    }
    public static void main(String[] args){
        String str = "I like apple";
        System.out.println(dao_cau(str));        
    }
}
