import java.util.Stack;

public class Ex1 {
    public static String infixToPostfix(String s) {
        StringBuilder chuoi_trong = new StringBuilder();
        Stack<Character> ngan_xep_trong = new Stack<>();

        String[] chuoi = s.split(" ");
        for (String ch : chuoi) {
            char kitu = ch.charAt(0);
            if (Character.isLetterOrDigit(kitu)) {
                chuoi_trong.append(ch).append(" ");
            } else if (kitu == '(') {
                ngan_xep_trong.push(kitu);
            } else if (kitu == ')') {
                while (!ngan_xep_trong.isEmpty() && ngan_xep_trong.peek() != '(') {
                    chuoi_trong.append(ngan_xep_trong.pop()).append(" ");
                }
                ngan_xep_trong.pop(); // Pop the '('
            } else {
                while (!ngan_xep_trong.isEmpty() && toan_hang(kitu) <= toan_hang(ngan_xep_trong.peek())) {
                    chuoi_trong.append(ngan_xep_trong.pop()).append(" ");
                }
                ngan_xep_trong.push(kitu);
            }
        }

        while (!ngan_xep_trong.isEmpty()) {
            chuoi_trong.append(ngan_xep_trong.pop()).append(" ");
        }

        return chuoi_trong.toString().trim();
    }

    private static int toan_hang(char operator) {
        if (operator == '+' || operator == '-') {
            return 1;
        } else if (operator == '*' || operator == '/') {
            return 2;
        }
        return 0; 
    }

    public static void main(String[] args) {
        String mau = "A + B * ( C - D ) / E";
        String chuoi_trong = infixToPostfix(mau);
        System.out.println("Infix Expression: " + mau);
        System.out.println("Postfix Expression: " + chuoi_trong);
    }
}
