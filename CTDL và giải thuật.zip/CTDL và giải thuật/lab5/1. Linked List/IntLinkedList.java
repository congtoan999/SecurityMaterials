class IntLinkedList implements ListInterface{
    Node head;
    
    public void addFirst(int data){
        head = new Node(data, head);
    }

    public void print(){
        if(head != null){
            Node tmp = head;
            System.out.print("" + tmp.getData());
            tmp =tmp.getNext();
            while(tmp != null){
                System.out.print("-->" + tmp.getData());
                tmp = tmp.getNext();
            }
        }
        System.out.println();
    }

    public boolean addLast(int data){
        if(head == null){
            return false;
        }else{
            Node tmp = head;
            while(tmp!=null){
                if(tmp.getNext() == null){
                    Node n = new Node(data,tmp.getNext());
                    tmp.setNext(n);
                    return true;
                }
                tmp = tmp.getNext();
            }
            return false;
        }  
    }
    public boolean removeAt(int position){
        if(head == null){
            return false;
        }else if(head.getData() == position){
            head = head.getNext();
            return true;
        }else{
            Node tmp = head;
            while(tmp.getNext()!= null){
                if (tmp.getNext().getData() == position){
                    tmp.setNext(tmp.getNext().getNext());
                    return true;
                }
                tmp = tmp.getNext();
            }
            return false;
        }
    }

    public int countOdd(){
        int dem  = 0;
        Node t = head;
        if (t == null){
            return 0;
        }
        while(t != null  ){
            if (t.getData() % 2 != 0){
                dem ++;
            }
            t = t.getNext();
        }
        return dem;
    }

    public int searchKey(int key){
        if (head == null){
            return -1;
        }else{
            Node tmp = head;
            int vi_tri =0;
            while(tmp!= null){
                if (tmp.getData()== key){
                    return vi_tri;
                }
                vi_tri ++;
                tmp=tmp.getNext();
            }
        }
        return -1;
    }

    public boolean checkSorted() {
        Node t = head;
        boolean sortTang = true;
        boolean sortGiam = true;
    
        if (t == null) {
            return false;
        } 
    
        while (t.getNext() != null) {
            if (t.getData() < t.getNext().getData()) {
                sortGiam = false;
            } else if (t.getData() > t.getNext().getData()) {
                sortTang = false;
            }
            t = t.getNext();
        }
    
        if (sortGiam  == true || sortTang == true) {
            return true; 
        }
    
        return false; 
    }
    
}
