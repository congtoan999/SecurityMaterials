public class Test {
    public static void main(String[] args){
        IntLinkedList stk = new IntLinkedList();
        stk.addFirst(4);
        stk.addFirst(3);
        // stk.addFirst(2);
        // stk.addFirst(1);
        // stk.addFirst(5);
        // stk.addFirst(6);
        // stk.addFirst(7);
        // stk.addFirst(8);
        // stk.addFirst(41);
        // stk.print();
        // stk.addLast(3);
        // stk.addLast(7);
        stk.addLast(1);
        stk.addLast(0);
        stk.print();
        // stk.removeAt(1);
        // stk.print();
       
        // System.out.println( stk.countOdd());
        System.out.println( stk.searchKey(41));
        // System.out.println( stk.searchKey(5));
        System.out.println( stk.searchKey(1));
        // System.out.println( stk.checkSorted());
        
    }
}

