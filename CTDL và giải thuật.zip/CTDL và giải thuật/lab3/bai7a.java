public class bai7a {
    public static int findMin(int[] arr, int n){
        if(n == 0){
            return arr[0]; 
        }
        int result = findMin(arr, n-1);
        return result < arr[n] ? result : arr[n];  //de quy lui tu phai qua trai
    }

    public static void main(String[] args){
        int[] arr = {2,0,-1,3,7,1};
        System.out.println(findMin(arr,arr.length-1 ));
    }
}
