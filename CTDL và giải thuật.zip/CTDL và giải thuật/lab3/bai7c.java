public class bai7c {
    public static int cau7c(int[] arr,int n ){
        if(arr.length == 0) return 0;
        if(n == 0){
            return arr[0] %2== 0?1:0;
        }
        return (arr[n] %2 == 0? 1:0) + cau7c(arr, n-1);
        // return (arr[n] %2 == 0? 1:0) ;
    }

    public static void main(String[] args){
        int[] arr = {2,5,3,10,6,1,4,9,8};// dem tu 0
        // System.out.println(cau7c(arr,arr.length - 1));
        System.out.println(cau7c(arr,arr.length-1));
    }
}
