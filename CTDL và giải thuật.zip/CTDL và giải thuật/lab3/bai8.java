public class bai8 {
    // bên lab 1
}
