import java.util.*;




class bai4_d_e {
    public static int cau4d(int n, int r){
        if (n>=r && r > 0){
            return (n - r +1) * cau4d( n , -1);   // n-(r-1)  
        }
        return 1;
    }

    public static int cau4e(int n){
        int re = 0;
        if(n>1){
            while(n > 1){
                re += Math.pow(2, n) + Math.pow(n, 2) ;
                n--;
                // return re;
            }
        return re + 3;
        }
        return 3;
    }

   

    public static void main(String[] args ){
        System.out.println(cau4d(3, 2));
        System.out.println(cau4e(3));
        System.out.println(cau4e(2));
    }
}