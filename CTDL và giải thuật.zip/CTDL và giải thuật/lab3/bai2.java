public class bai2 {
    public static double computeFactorial(int n) {
        if (n == 0 || n == 1) {
            return 1;
        }
        return n * computeFactorial(n - 1);
    }
    public static double countDigit2c(int n) {

        if (n<10) {
            return 1;
        }
        return  1 + countDigit2c(n/10);
    }

    // public static

    public static void main(String[] args) {
        System.out.println(computeFactorial(4));
        // System.out.println(countDigit2c(12));
        System.out.println(countDigit2c(646462));
    }
}
