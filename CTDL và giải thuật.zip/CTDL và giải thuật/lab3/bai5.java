public class bai5 {
    public static int dec2bin(int n) {
        if (n == 0) {
            return 0;
        }
        return dec2bin(n / 2) * 10 + n % 2;

        // 3 1
        // 11 1
        // 111 1

        // 4 / 2
        // 0 2 / 2
        // 0 1 / 2
        // 1 / 0
    }

    public static void main(String[] args) {
        System.out.println(dec2bin(7));
    }
}
