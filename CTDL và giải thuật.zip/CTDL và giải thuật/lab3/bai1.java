public class bai1 {
    public static int comoute(int n) {

        if (n == 1 || n == 0) {
            return 1;
        }
        int facrorial = 1;
        for (int i = 2; i <= n; i++) {
            facrorial = facrorial * i;
        }
        return facrorial;
    }

    public static int compute(int x, int n) {
        if (n == 0)
            return 1;
        if (n == 1)
            return n;
        int result = 1;
        for (int i = 1; i <= n; i++) {
            result *= x;
        }
        return result;
    }

    public static int dem(int n) {
        int d = 0;
        int tem = 0;
        while (n != 0) {
            tem = n % 10;
            n = n / 10;
            d++;
        }
        return d;
    }

    public static boolean ktra(int n) {
        for (int i = 2; i <= Math.sqrt(n); i++) {
            if (n % i == 0) {
                return false;
            }
        }
        return true;
    }

    public static void main(String[] args) {
        // System.out.println(comoute(4));
        // System.out.println(compute(2, 4));
        System.out.println(dem(3223534));
        // System.out.println(ktra(119));
    }
}
