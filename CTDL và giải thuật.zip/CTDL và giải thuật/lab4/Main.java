import java.util.Arrays;
import java.util.Comparator;

public class Main {
    public static void main(String[] args) {
        Integer[] arr = { 89, 40, 46, 55, 54, 5, 50, 73, 23, 47 };
        Arrays.sort(arr, new MyComparator());
        System.out.println(Arrays.toString(arr));
    }
}

class MyComparator implements Comparator<Integer> {
    @Override
    public int compare(Integer a, Integer b) {
        // Sắp xếp số chẵn trước số lẻ
        if (a % 2 == 0 && b % 2 != 0)
            return -1;// a đứng trước b
        if (a % 2 != 0 && b % 2 == 0)
            return 1;// a đứng sau b
        // Sắp xếp số chẵn theo thứ tự tăng dần
        if (a % 2 == 0)
            return a - b;// a đứng trước b (a nhỏ hơn b)
        // Sắp xếp số lẻ theo thứ tự giảm dần
        return b - a;// a đứng sau b (a lớn hơn b)
    }
}
