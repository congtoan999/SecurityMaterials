public class QuickSort {
    // Hàm phân chia mảng thành 2 phần, trái và phải
    private static int phanChiaMang(int[] mang, int dau, int cuoi) {
        int mocChia = mang[dau];
        int viTriMocChia = dau;
        for (int viTri = dau + 1; viTri <= cuoi; viTri++) {
            if (mang[viTri] < mocChia) {
                viTriMocChia++;
                int tam = mang[viTriMocChia];
                mang[viTriMocChia] = mang[viTri];
                mang[viTri] = tam;
            }
        }

        int tam = mang[viTriMocChia];
        mang[viTriMocChia] = mang[dau];
        mang[dau] = tam;
        return viTriMocChia;
    }

    // Hàm sắp xếp mảng theo thuật toán QuickSort
    public static void sapXepNhanh(int[] mang, int dau, int cuoi) {
        if (dau < cuoi) {
            int viTriMocChia = phanChiaMang(mang, dau, cuoi);
            sapXepNhanh(mang, dau, viTriMocChia - 1);
            sapXepNhanh(mang, viTriMocChia + 1, cuoi);
        }
    }

    public static void main(String[] args) {
        int[] mang = { 12, 11, 13, 5, 6, 7 };

        System.out.println("Mảng chưa sắp xếp:");
        inMang(mang);

        sapXepNhanh(mang, 0, mang.length - 1);

        System.out.println("Mảng đã sắp xếp:");
        inMang(mang);
    }

    private static void inMang(int[] mang) {
        for (int giaTri : mang) {
            System.out.print(giaTri + " ");
        }
        System.out.println();
    }
}