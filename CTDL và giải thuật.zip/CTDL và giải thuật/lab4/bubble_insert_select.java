public class bubble_insert_select {
    public static void bubbleSort(int[] arr) {
        int n = arr.length;
        for (int i = 0; i < n - 1; i++)
            for (int j = 0; j < n - i - 1; j++)
                if (arr[j] > arr[j + 1]) {
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
    }

    // Selection Sort
    public static void selectionSort(int[] arr) {
        int n = arr.length;
        for (int i = 0; i < n - 1; i++) {
            int min_idx = i;
            for (int j = i + 1; j < n; j++) {
                if (arr[min_idx] > arr[j])
                    min_idx = j;
            }
            int temp = arr[min_idx];
            arr[min_idx] = arr[i];
            arr[i] = temp;
        }
    }

    // Insertion Sort
    public static void insertionSort(int[] arr) {
        int n = arr.length;
        for (int i = 1; i < n; i++) {
            int key = arr[i];
            int j = i - 1;
            while (j >= 0 && arr[j] > key) {
                arr[j + 1] = arr[j];
                j = j - 1;
            }
            arr[j + 1] = key;
        }
    }
}

// Bubble Sort:
// So sánh từng cặp phần tử liền kề và hoán đổi chúng nếu chúng không theo thứ
// tự mong muốn.
// Lặp lại quá trình trên cho đến khi không còn cặp nào để hoán đổi nữa.

// Selection Sort:
// Tìm phần tử nhỏ nhất (hoặc lớn nhất, tùy thuộc vào thứ tự sắp xếp) trong mảng
// chưa được sắp xếp.
// Hoán đổi phần tử đó với phần tử đầu tiên của mảng chưa được sắp xếp.
// Lặp lại quá trình trên cho phần còn lại của mảng.

// Insertion Sort:
// Xem phần tử đầu tiên như một mảng đã được sắp xếp.
// Chèn từng phần tử tiếp theo vào vị trí thích hợp trong mảng đã được sắp xếp.
// Lặp lại quá trình trên cho đến khi tất cả các phần tử đều đã được chèn.