import java.util.*;

class BubbleSort {
    public static void bubbleSort(int[] a) {
        for (int i = 1; i < a.length; ++i) {
            for (int j = 0; j < a.length - 1; ++j) {
                if (a[j] > a[j + 1]) {
                    int temp = a[j];
                    a[j] = a[j + 1];
                    a[j + 1] = temp;
                    System.out.println(Arrays.toString(a));
                }
            }
        }
    }

    public static void main(String[] args) {
        int[] numbers = new int[] { 3, 4, 2, 1, 9, 8, 5 };
        System.out.println("Mảng ban đầu: " + Arrays.toString(numbers));
        bubbleSort(numbers);
    }
}