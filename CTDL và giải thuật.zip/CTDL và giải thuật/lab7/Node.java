public class Node{
    Integer data;
    Node left,right;
    int height;

    public Node(Integer data){
        this.data = data;
        height = 0;
        right = left = null;
    }

}