public class AVL {
    public Node root;

    public AVL() {
        root = null;
    }

    private Node insert(Node node, Integer key) {
        if (node == null) {
            node = new Node(key);
            return new Node(key);
        }
        int cmp = key.compareTo(node.data);
        if (cmp < 0) {
            node.left = insert(node.left, key);
        } else if (cmp > 0) {
            node.right = insert(node.right, key);
        } else {
            node.data = key;
        }
        node.height = 1 + Math.max(height(node.left), height(node.right));
        System.out.println(node.data + " " + node.height);
        return balance(node);
    }

    public void insertNode(Integer key) {
        root = insert(root, key);
    }

    public int height(Node node) {
        if (node == null) {
            return -1;
        }
        return node.height;
    }

    public int height1() {
        return height(root);
    }

    private Node rotateRight(Node x) {
        Node y = x.left;
        x.left = y.right;
        y.right = x;
        x.height = 1 + Math.max(height(x.left), height(x.right));
        y.height = 1 + Math.max(height(y.left), height(y.right));
        return y;
    }

    private Node rotateLeft(Node x) {
        Node y = x.right;
        x.right = y.left;
        y.left = x;
        x.height = 1 + Math.max(height(x.left), height(x.right));
        y.height = 1 + Math.max(height(y.left), height(y.right));
        return y;
    }

    private int checkBalance(Node x) {
        return height(x.left) - height(x.right);
    }

    private Node balance(Node x) {
        if (checkBalance(x) == -2) {
            if (checkBalance(x.right) == 1) {
                x.right = rotateRight(x.right);
            }
            x = rotateLeft(x);
        } else if (checkBalance(x) == 2) {
            if (checkBalance(x.left) == -1) {
                x.left = rotateLeft(x.left);
            }
            x = rotateRight(x);
        }
        return x;
    }

    private void NLR(Node x) {
        if (x != null) {
            System.out.print(x.data + " ");
            NLR(x.left);
            NLR(x.right);
        }
    }

    public void NLR() {
        NLR(root);
    }

    private void LRN(Node x) {
        if (x != null) {
            LRN(x.left);
            System.out.print(x.data + " ");
            LRN(x.right);
        }
    }

    public void LRN() {
        LRN(root);
    }

    private Node delete(Node node, Integer key) {
        if (node == null) {
            node = new Node(key);
            return null;
        }
        int cmp = key.compareTo(node.data);
        if (cmp < 0) {
            node.left = delete(node.left, key);
        } else if (cmp > 0) {
            node.right = delete(node.right, key);
        } else {
            if (node.left == null) {
                return node.right;
            }
            if (node.right == null) {
                return node.left;
            }
            node.data = findMin(node.right).data;
            node.right = deletemin(node.right);
            node.height = Math.max(height(node.left), height(node.right)) + 1;
        }
        return balance(node);
    }

    public void delete(Integer key) {
        root = delete(root, key);
    }

    private Node deletemin(Node x) {
        if (x.left == null) {
            return x.right;
        }
        x.left = deletemin(x.left);
        return x;
    }

    private Node findMin(Node x) {
        if (x.left == null) {
            return x;
        }
        return findMin(x.left);
    }

    public Integer findMin() {
        return findMin(root).data;
    }

}
