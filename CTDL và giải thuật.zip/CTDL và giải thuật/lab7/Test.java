public class Test {
    public static void main(String[] args) {
        AVL n = new AVL();
        n.insertNode(1);
        n.insertNode(2);
        n.insertNode(3);
        n.insertNode(4);
        n.insertNode(5);
        n.insertNode(6);

        // n.insertNode(10);
        // n.LRN();
        // System.out.println();
        n.NLR();
        System.out.println();
        System.out.println(n.height(n.root));
        n.delete(11);
        System.out.println();
        System.out.println(n.height(n.root));
        // n.print();
    }
}
