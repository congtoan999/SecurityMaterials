import java.util.NoSuchElementException;

public class PersonMaxHeap {
    Person[] heap;
    int maxSize;
    int heapSize;

    public PersonMaxHeap(int capity) {
        this.maxSize = capity + 1;
        heap = new Person[maxSize];
        heapSize = 0;
    }

    private int parent(int i) {
        return i / 2;
    }

    private int left(int i) {
        return 2 * i;
    }

    private int right(int i) {
        return (2 * i) + 1;
    }

    private void swap(int i, int j) {
        Person temp = heap[i];
        heap[i] = heap[j];
        heap[j] = temp;
    }

    private void shiftUp(int i) {
        while (i > 1 && heap[parent(i)].priorityNumber < heap[i].priorityNumber) {
            swap(parent(i), i);
            i = parent(i);
        }
    }

    public void enqueue(Person person) {
        if (heapSize == maxSize) {
            throw new NoSuchElementException("overflow Exception");
        }
        heapSize += 1;
        heap[heapSize] = person;
        shiftUp(heapSize);
    }

    private void shiftDown(int i) {
        while (i <= heapSize) {
            int max = heap[i].priorityNumber;
            int max_id = i;
            if (left(i) <= heapSize && max < heap[left(i)].priorityNumber) {
                max = heap[left(i)].priorityNumber;
                max_id = left(i);
            }
            if (right(i) <= heapSize && max < heap[right(i)].priorityNumber) {
                max = heap[right(i)].priorityNumber;
                max_id = right(i);
            }
            if (max_id != i) {
                swap(max_id, i);
                i = max_id;
            } else {
                break;
            }
        }
    }

    public Person dequeue() {
        if (heapSize == 0) {
            throw new NoSuchElementException("Underflow Exception");
        }
        Person max = heap[1];
        heap[1] = heap[heapSize];
        heapSize -= 1;
        shiftDown(1);
        return max;
    }

    public void print() {
        for (int i = 0; i <= heapSize; i++) {
            System.out.println(heap[i] + " ");
        }
        System.out.println();
    }
}
