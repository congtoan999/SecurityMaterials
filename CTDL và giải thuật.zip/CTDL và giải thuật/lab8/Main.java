import java.util.Arrays;

public class Main {
    private static MaxHead inserMaxHead(String str, int capity) {
        MaxHead mh = new MaxHead(capity);
        String[] s = str.split(" , ");
        for (String i : s) {
            mh.insert(Integer.parseInt(i));
        }
        return mh;
    }

    public static void heapSort(int[] arr) {
        MaxHead mh = new MaxHead(arr.length);
        for (int i : arr) {
            mh.insert(i);
        }
        for (int i = 0; i < arr.length; i++) {
            arr[i] = mh.extracMax();
        }
    }

    public static void main(String[] args[]) {
        MaxHead mh = inserMaxHead("2,7,26,25,19,17,1,90,3,36", 60);
        mh.print();
        System.out.println(mh.heapSize);
        mh.extracMax();
        mh.print();
        System.out.println(mh.heapSize);
        mh.insert(5);
        mh.print();
        mh.extracMax();
        mh.print();
        mh.extracMax();
        mh.print();
        mh.extracMax();
        mh.print();
        mh.extracMax();
        mh.print();
        mh.insert(6);
        mh.print();
        mh.insert(0);
        mh.print();
        mh.extracMax();
        mh.print();
        int[] arr = { 2, 7, 4, 6, 3, 1 };
        System.out.println(Arrays.toString(arr));
        heapSort(arr);
        System.out.println(Arrays.toString(arr));

    }
}
