public class Main1 {
    public static void main(String[] args) {
        PersonMaxHeap mh = new PersonMaxHeap(10);
        mh.enqueue(new Person("Alex", 3));
        mh.enqueue(new Person("Bob", 2));
        mh.enqueue(new Person("David", 6));
        mh.enqueue(new Person("Susan", 1));
        System.out.println(mh.dequeue());
        mh.enqueue(new Person("Mike", 5));
        mh.enqueue(new Person("Kevin", 4));
        System.out.println(mh.dequeue());
        System.out.println(mh.dequeue());
        mh.enqueue(new Person("Helen", 0));
        mh.enqueue(new Person("Paul", 8));
        mh.enqueue(new Person("Iris", 7));
        System.out.println(mh.dequeue());
    }
}
