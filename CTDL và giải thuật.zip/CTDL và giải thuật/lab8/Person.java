public class Person {
    String name;
    int priorityNumber;

    public Person(String name, int priorityNumber) {
        this.name = name;
        this.priorityNumber = priorityNumber;
    }

    public String toString() {
        return "(" + name + "," + priorityNumber + ")";
    }
}
