package N01_Client_Server_TCP_Demo;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;

import java.awt.Font;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
public class V4_Client_CalculatorFrame extends JFrame implements Runnable {
	private JPanel contentPane;
	private JTextField serverPort;
	private JTextField serverName;
	private JTextField result;
	private JButton createClient;
	private JButton tong;
	Socket socket;
	DataInputStream dataInputStream;
	DataOutputStream dataOutputStream;
	String str1="",str2="";
	private JTextField No1;
	private JTextField No2;
	String ar[];
	private JButton btnSend_1;
	/**
	* Launch the application.
	*/
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					V4_Client_CalculatorFrame frame = new V4_Client_CalculatorFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	/**
	* Create the frame.
	*/
	public V4_Client_CalculatorFrame() {
		setTitle("SIMPLE CALCULATOR CLIENT");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
	
		setContentPane(contentPane);
		contentPane.setLayout(null);
		serverPort = new JTextField();
		serverPort.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		serverPort.setText("2024");
		serverPort.setBounds(246, 22, 79, 26);
		contentPane.add(serverPort);
		serverPort.setColumns(10);
		serverName = new JTextField();
		serverName.setText("localhost");
		serverName.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		serverName.setColumns(10);
		serverName.setBounds(85, 22, 101, 26);
		contentPane.add(serverName);
		JLabel ServerName = new JLabel("ServerName:");
		ServerName.setBounds(6, 28, 86, 16);
		contentPane.add(ServerName);
		JLabel lblPortno = new JLabel("PortNo:");
		lblPortno.setBounds(192, 28, 54, 16);
		contentPane.add(lblPortno);
		createClient = new JButton("Start");
		createClient.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int serverNo = Integer.parseInt(serverPort.getText());
				String serverN = serverName.getText();
				try {
					socket = new Socket(serverN,serverNo);
					Thread thread = new Thread(V4_Client_CalculatorFrame.this);
					thread.start();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		createClient.setFont(new Font("Times New Roman", Font.BOLD, 18));
		createClient.setBounds(325, 22, 108, 29);
		contentPane.add(createClient);
		//JScrollPane scrollPane = new JScrollPane(showMessage);
		//scrollPane.setBounds(35, 72, 382, 132);
		//contentPane.add(scrollPane);
		result = new JTextField();
		result.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		result.setColumns(10);
		result.setBounds(114, 221, 202, 26);
		contentPane.add(result);
	
		tong = new JButton("+");
		tong.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				str1 = No1.getText() + " " + No2.getText() +" +";
				try {
					dataOutputStream = new DataOutputStream(socket.getOutputStream());
					dataOutputStream.writeUTF(str1);
					dataOutputStream.flush();
					//showMessage.setText(showMessage.getText().trim() +"\n Me: "+str2);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				result.setText("");
			}
		});
		tong.setFont(new Font("Times New Roman", Font.BOLD, 18));
		tong.setBounds(114, 162, 47, 29);
		contentPane.add(tong);
		No1 = new JTextField();
		No1.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		No1.setColumns(10);
		No1.setBounds(117, 74, 194, 26);
		contentPane.add(No1);
		No2 = new JTextField();
		No2.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		No2.setColumns(10);
		No2.setBounds(117, 124, 194, 26);
		contentPane.add(No2);
		JButton btnSend_1_1 = new JButton("-");
		btnSend_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				str1 = No1.getText() + " " + No2.getText() +" -";
				try {
					dataOutputStream = new DataOutputStream(socket.getOutputStream());
					dataOutputStream.writeUTF(str1);
					dataOutputStream.flush();
					//showMessage.setText(showMessage.getText().trim() +"\n Me: "+str2);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				result.setText("");
			}
		});
		btnSend_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		btnSend_1_1.setBounds(158, 162, 47, 29);
		contentPane.add(btnSend_1_1);
		JButton btnSend_1_2 = new JButton("x");
		btnSend_1_2.addActionListener(new ActionListener() {
	
			public void actionPerformed(ActionEvent e) {
				str1 = No1.getText() + " " + No2.getText() +" x";
				try {
					dataOutputStream = new DataOutputStream(socket.getOutputStream());
					dataOutputStream.writeUTF(str1);
					dataOutputStream.flush();
					//showMessage.setText(showMessage.getText().trim() +"\n Me: "+str2);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				result.setText("");
			}
		});
		btnSend_1_2.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		btnSend_1_2.setBounds(210, 162, 47, 29);
		contentPane.add(btnSend_1_2);
		JButton btnSend_1_3 = new JButton(":");
		btnSend_1_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				str1 = No1.getText() + " " + No2.getText() +" :";
				try {
					dataOutputStream = new DataOutputStream(socket.getOutputStream());
					dataOutputStream.writeUTF(str1);
					dataOutputStream.flush();
					//showMessage.setText(showMessage.getText().trim() +"\n Me: "+str2);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				result.setText("");
			}
		});
		btnSend_1_3.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		btnSend_1_3.setBounds(269, 162, 47, 29);
		contentPane.add(btnSend_1_3);
		JLabel lblNumberOne = new JLabel("Number One:");
		lblNumberOne.setBounds(6, 80, 101, 16);
		contentPane.add(lblNumberOne);
		JLabel lblNumberTwo = new JLabel("Number Two:");
		lblNumberTwo.setBounds(6, 130, 101, 16);
		contentPane.add(lblNumberTwo);
		btnSend_1 = new JButton("Exit");
		btnSend_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				str1 = "exit";
				try {
					dataOutputStream = new DataOutputStream(socket.getOutputStream());
					dataOutputStream.writeUTF(str1);
					dataOutputStream.flush();
	
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				//result.setText("");
			}
		});
		btnSend_1.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		btnSend_1.setBounds(351, 222, 67, 29);
		contentPane.add(btnSend_1);
		}
		@Override
		public void run() {
			// TODO Auto-generated method stub
			try {
				dataInputStream = new DataInputStream(socket.getInputStream());
				while(true) {
					str1 = dataInputStream.readUTF();
					result.setText(""+str1);
				}
			} catch (IOException e) {
					// TODO Auto-generated catch block
		e.printStackTrace();
			}
			finally {
				if(socket!=null) {
					try {
						socket.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		}
}