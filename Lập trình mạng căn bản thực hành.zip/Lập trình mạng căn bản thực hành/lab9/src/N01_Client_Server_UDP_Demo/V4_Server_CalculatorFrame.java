package N01_Client_Server_TCP_Demo;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.awt.event.ActionEvent;
public class V4_Server_CalculatorFrame extends JFrame implements Runnable {
	private JPanel contentPane;
	private JTextField serverPort;
	private JTextArea showMessage;
	private JButton CreateServer;
	ServerSocket serverSocket;
	Socket socket;
	DataOutputStream dataOutputStream;
	DataInputStream dataInputStream;
	String str1="", str2="";
	Float result;
	/**
	* Launch the application.
	*/
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					V4_Server_CalculatorFrame frame = new
							V4_Server_CalculatorFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	/**
	* Create the frame.
	*/
	public V4_Server_CalculatorFrame() {
		setFont(new Font("Times New Roman", Font.BOLD, 18));
		setTitle("SIMPLE CALCULATOR SERVER");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
	
		setContentPane(contentPane);
		contentPane.setLayout(null);
		serverPort = new JTextField();
		serverPort.setText("2024");
		serverPort.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		serverPort.setBounds(132, 22, 148, 26);
		contentPane.add(serverPort);
		serverPort.setColumns(10);
		CreateServer = new JButton("Start");
		CreateServer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int portNo = Integer.parseInt(serverPort.getText());
				try {
					serverSocket = new ServerSocket(portNo);
					JOptionPane.showMessageDialog(null, "Server is waitting a Client"+portNo, "Note",JOptionPane.WARNING_MESSAGE);
					socket = serverSocket.accept();
					JOptionPane.showMessageDialog(null, "Start Chatting ","Note",JOptionPane.WARNING_MESSAGE);
					Thread thread = new Thread(V4_Server_CalculatorFrame.this);
					thread.start();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		CreateServer.setFont(new Font("Times New Roman", Font.BOLD, 18));
		CreateServer.setBounds(292, 22, 117, 29);
		contentPane.add(CreateServer);
		JLabel lblNewLabel = new JLabel("Server Port No.");
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 16));
		lblNewLabel.setBounds(6, 28, 114, 16);
		contentPane.add(lblNewLabel);
		showMessage = new JTextArea();
		showMessage.setBounds(32, 60, 379, 160);
		contentPane.add(showMessage);
		JScrollPane scrollPane = new JScrollPane(showMessage);
		scrollPane.setBounds(32, 60, 379, 160);
		contentPane.add(scrollPane);
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		try {
			dataInputStream = new DataInputStream(socket.getInputStream());
			dataOutputStream = new DataOutputStream(socket.getOutputStream());
			while(true) {
	
				str1 = dataInputStream.readUTF();
				String[] words = str1.split("\\s+");
				showMessage.setText(showMessage.getText() + "\n Client says:"+words[0]+words[2] +words[1]);
				if(words[0].equals("exit")) {
					break;
				}
				if(words[2].equals("+")) {
					result = Float.parseFloat(words[0])+Float.parseFloat(words[1]);
					showMessage.setText(showMessage.getText() + "\n Result: "+result);
				}
				else if(words[2].equals("-")){
					result = Float.parseFloat(words[0])-Float.parseFloat(words[1]);
					showMessage.setText(showMessage.getText() + "\n Result: "+result);
				}
				else if(words[2].equals("x")){
					result = Float.parseFloat(words[0])*Float.parseFloat(words[1]);
					showMessage.setText(showMessage.getText() + "\n Result: "+result);
				}
				else if(words[2].equals(":")){
					result = Float.parseFloat(words[0])/Float.parseFloat(words[1]);
					showMessage.setText(showMessage.getText() + "\n Result: "+result);
				}
				dataOutputStream.writeUTF(""+result);
				dataOutputStream.flush();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			if(socket!=null) {
				try {
					socket.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
}