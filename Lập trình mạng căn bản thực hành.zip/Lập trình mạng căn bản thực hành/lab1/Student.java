public class Student extends Person {
    public Student(String vName, String vCode, int Birthday) {
        super(vName, vCode, Birthday);
        this.setScore(0.1);
    }

    public double score;

    public double getScore() {
        return score;
    }

    public void setScore(double score) {
        this.score = score;
    }

    public void showInfo() {
        System.out.println("Student Info:...............");
        super.showInfo();
        System.out.println("Score : " + this.getScore());
    }
}
