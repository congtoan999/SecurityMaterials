
import java.util.*;

public class Person {
    public String name;
    public String code;
    public int birthday;

    public Person(String vName, String vCode, int vBirthday) {
        this.name = vName;
        this.code = vCode;
        this.birthday = vBirthday;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public int getBirthday() {
        return birthday;
    }

    public void setBirthday(int birthday) {
        this.birthday = birthday;
    }

    public int getAge() {
        Calendar c = Calendar.getInstance();
        return c.get(Calendar.YEAR) - this.getBirthday();
    }

    public void showInfo() {
        System.out.println("Name : " + this.getName());
        System.out.println("Code : " + this.getCode());
        System.out.println("Birthday: " + this.getBirthday());
        System.out.println("Age : " + this.getAge());
    }

}
