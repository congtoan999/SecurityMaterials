public class Main {
    public static void main(String[] args) {
        Student studentOne = new Student("Nguyen Cong A", "SV001", 2001);
        studentOne.setScore(8.9);
        studentOne.showInfo();
        Teacher teacherOne = new Teacher("Nguyen Van B", "T001", 1984);
        teacherOne.setSalary(5.60000);
        teacherOne.showInfo();
    }
}