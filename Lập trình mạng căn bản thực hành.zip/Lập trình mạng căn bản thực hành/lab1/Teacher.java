
public class Teacher extends Person {
    public Teacher(String vName, String vCode, int vBirthday) {
        super(vName, vCode, vBirthday);
        this.setSalary(0.01);
    }

    public double salary;

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public void showInfo() {
        System.out.println("Teacher Info:........");
        super.showInfo();
        System.out.println("Score : " + this.getSalary());
    }
}
