import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.net.*;

public class MainMenu extends JFrame {
    private JLabel infoLabel;

    public MainMenu() {
        super("Main Menu");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(3, 1));

        JButton createServerButton = new JButton("Tạo máy chủ");
        createServerButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose(); // Đóng frame MainMenu
                ServerGUI serverGUI = new ServerGUI();
                serverGUI.setVisible(true);
            }
        });
        buttonPanel.add(createServerButton);

        JButton createClientButton = new JButton("Tạo khách hàng");
        createClientButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose(); // Đóng frame MainMenu
                ClientGUI clientGUI = new ClientGUI();
                clientGUI.setVisible(true);
            }
        });
        buttonPanel.add(createClientButton);

        mainPanel.add(buttonPanel, BorderLayout.CENTER);

        infoLabel = new JLabel("Nguyễn Công Toàn - MSSV: 52200271", SwingConstants.CENTER);
        mainPanel.add(infoLabel, BorderLayout.SOUTH);

        getContentPane().add(mainPanel);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MainMenu mainMenu = new MainMenu();
            mainMenu.setVisible(true);
        });
    }
}

class ServerGUI extends JFrame {
    private JTextArea logTextArea;

    public ServerGUI() {
        super("Server");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Đóng frame này mà không ảnh hưởng đến frame MainMenu
        setSize(400, 300);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());

        logTextArea = new JTextArea();
        logTextArea.setEditable(false);

        JScrollPane scrollPane = new JScrollPane(logTextArea);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        JButton backButton = new JButton("Back");
        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose(); // Đóng frame ServerGUI
                MainMenu mainMenu = new MainMenu();
                mainMenu.setVisible(true);
            }
        });
        mainPanel.add(backButton, BorderLayout.SOUTH);

        getContentPane().add(mainPanel);
    }
}

class ClientGUI extends JFrame {
    private JTextArea resultTextArea;

    public ClientGUI() {
        super("Client");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Đóng frame này mà không ảnh hưởng đến frame MainMenu
        setSize(400, 300);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());

        resultTextArea = new JTextArea();
        resultTextArea.setEditable(false);

        JScrollPane scrollPane = new JScrollPane(resultTextArea);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        JButton backButton = new JButton("Back");
        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose(); // Đóng frame ClientGUI
                MainMenu mainMenu = new MainMenu();
                mainMenu.setVisible(true);
            }
        });
        mainPanel.add(backButton, BorderLayout.SOUTH);

        getContentPane().add(mainPanel);
    }
}
