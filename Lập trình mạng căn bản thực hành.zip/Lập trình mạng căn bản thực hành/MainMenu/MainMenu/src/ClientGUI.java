import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.net.*;
import java.io.IOException;

public class ClientGUI extends JFrame {
    private JTextField requestField;
    private JTextField radiusField;
    private JTextArea resultTextArea;

    private InetAddress serverAddress;
    private int serverPort;

    public ClientGUI() {
        super("Client");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());

        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(3, 2));

        inputPanel.add(new JLabel("Yêu cầu:"));
        requestField = new JTextField();
        inputPanel.add(requestField);

        inputPanel.add(new JLabel("Bán kính:"));
        radiusField = new JTextField();
        inputPanel.add(radiusField);

        JButton sendButton = new JButton("Gửi");
        sendButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                sendRequest();
            }
        });
        inputPanel.add(sendButton);

        mainPanel.add(inputPanel, BorderLayout.NORTH);

        resultTextArea = new JTextArea();
        JScrollPane scrollPane = new JScrollPane(resultTextArea);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        getContentPane().add(mainPanel);

        // Đặt địa chỉ và cổng của server
        try {
            serverAddress = InetAddress.getLocalHost();
            serverPort = 12345;
        } catch (UnknownHostException ex) {
            ex.printStackTrace();
        }
    }

    private void sendRequest() {
        try {
            DatagramSocket socket = new DatagramSocket();

            String request = requestField.getText();
            String radiusString = radiusField.getText();

            if (request.isEmpty() || radiusString.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Vui lòng nhập yêu cầu và bán kính.");
                return;
            }

            double radius = Double.parseDouble(radiusString);

            String requestData = request + "," + radius;
            byte[] sendData = requestData.getBytes();
            DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, serverAddress, serverPort);
            socket.send(sendPacket);

            byte[] receiveData = new byte[1024];
            DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
            socket.receive(receivePacket);
            String responseData = new String(receivePacket.getData(), 0, receivePacket.getLength());
            resultTextArea.setText(responseData);

            socket.close();
        } catch (NumberFormatException | IOException e) {
            JOptionPane.showMessageDialog(this, "Lỗi: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            ClientGUI clientGUI = new ClientGUI();
            clientGUI.setVisible(true);
        });
    }
}
