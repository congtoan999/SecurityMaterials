import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.net.*;
import java.io.IOException;

public class ServerGUI extends JFrame {
    private JTextArea logTextArea;

    public ServerGUI() {
        super("Server");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());

        logTextArea = new JTextArea();
        logTextArea.setEditable(false);

        JScrollPane scrollPane = new JScrollPane(logTextArea);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        add(mainPanel);
    }

    public void startServer(int port) {
        try {
            DatagramSocket socket = new DatagramSocket(port);
            log("Server started on port " + port);

            byte[] receiveData = new byte[1024];

            while (true) {
                DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
                socket.receive(receivePacket);
                String requestData = new String(receivePacket.getData(), 0, receivePacket.getLength());
                log("Received request: " + requestData);

                // Xử lý yêu cầu từ client
                String[] params = requestData.split(",");
                if (params.length != 2) {
                    sendResponse(socket, "Invalid request", receivePacket.getAddress(), receivePacket.getPort());
                    continue;
                }

                try {
                    double radius = Double.parseDouble(params[1]);
                    if (radius <= 0) {
                        sendResponse(socket, "Invalid radius value", receivePacket.getAddress(), receivePacket.getPort());
                        continue;
                    }

                    if (params[0].equals("area")) {
                        double area = calculateCircleArea(radius);
                        sendResponse(socket, "Diện tích hình tròn là " + area, receivePacket.getAddress(), receivePacket.getPort());
                    } else if (params[0].equals("perimeter")) {
                        double perimeter = calculateCirclePerimeter(radius);
                        sendResponse(socket, "Chu vi hình tròn là " + perimeter, receivePacket.getAddress(), receivePacket.getPort());
                    } else {
                        sendResponse(socket, "Invalid request", receivePacket.getAddress(), receivePacket.getPort());
                    }
                } catch (NumberFormatException e) {
                    sendResponse(socket, "Invalid radius value", receivePacket.getAddress(), receivePacket.getPort());
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private double calculateCircleArea(double radius) {
        return Math.PI * radius * radius;
    }

    private double calculateCirclePerimeter(double radius) {
        return 2 * Math.PI * radius;
    }

    private void sendResponse(DatagramSocket socket, String message, InetAddress address, int port) throws IOException {
        byte[] sendData = message.getBytes();
        DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, address, port);
        socket.send(sendPacket);
        log("Sent response: " + message);
    }

    private void log(String message) {
        SwingUtilities.invokeLater(() -> {
            logTextArea.append(message + "\n");
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            ServerGUI serverGUI = new ServerGUI();
            serverGUI.setVisible(true);
            serverGUI.startServer(12345); // Bắt đầu server trên cổng 12345
        });
    }
}
