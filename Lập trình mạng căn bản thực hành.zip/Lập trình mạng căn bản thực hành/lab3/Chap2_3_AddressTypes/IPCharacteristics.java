package Chap2_3_AddressTypes;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.awt.event.ActionEvent;

public class IPCharacteristics extends JFrame {
	private JPanel contentPane;
	private JTextField textFieldInput;
	private JTextArea textAreaOutput;
	/**
	* Launch the application.
	*/
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
						IPCharacteristics frame = new IPCharacteristics();
						frame.setVisible(true);
				} catch (Exception e) {
						e.printStackTrace();
				}
			}
		});
	}
	/**
	* Create the frame.
	*/
	public IPCharacteristics() {
		setTitle("IPCharacteristics");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 558, 364);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Input IP Address:");
		lblNewLabel.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		lblNewLabel.setBounds(12, 40, 122, 27);
		contentPane.add(lblNewLabel);
		
		textFieldInput = new JTextField();
		textFieldInput.setBounds(134, 43, 312, 22);
		contentPane.add(textFieldInput);
		textFieldInput.setColumns(10);
		
		textAreaOutput = new JTextArea();
		textAreaOutput.setEditable(false);
		textAreaOutput.setBounds(134, 161, 312, 86);
		contentPane.add(textAreaOutput);
		
		JButton btnNewButton = new JButton("Click Me!");
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 16));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String IPaddress = textFieldInput.getText();
				String result="";
				try {
						InetAddress address = InetAddress.getByName(IPaddress);
						if (address.isAnyLocalAddress( )) {
							result += address + " is a wildcard address.\n";
							}
							if (address.isLoopbackAddress( )) {
								result += address + " is loopback address.\n";
							}
							if (address.isLinkLocalAddress( )) {
								result += address + " is a link-local address.\n";
							}
							else if (address.isSiteLocalAddress( )) {
								result += address + " is a site-local address.\n";
							}
							else {
								result += address + " is a global address.\n";
							}
							if (address.isMulticastAddress( )) {
								if (address.isMCGlobal( )) {
									result += address + " is a global multicast address.\n";
								}
								else if (address.isMCOrgLocal( )) {
									result += address + " is an organization wide multicast address.\n";
								}
								else if (address.isMCSiteLocal( )) {
									result += address + " is a site wide multicast address.\n";
								}
								else if (address.isMCLinkLocal( )) {
									result += address + " is a subnet wide multicast address.\n";
								}
								else if (address.isMCNodeLocal( )) {
									result += address +" is an interface-local multicast address.\n";
								}
								else {
									result += address +" is an unknown multicast address type.\n";
								}
								}
								else {
									result += address + " is a unicast address.\n";
								}
							textAreaOutput.setText(result);
				} catch (UnknownHostException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
				}
			}
		});
		btnNewButton.setBounds(219, 86, 108, 40);
		contentPane.add(btnNewButton);
		
		JLabel lblAddressType = new JLabel("Address Type:");
		lblAddressType.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		lblAddressType.setBounds(20, 193, 102, 27);
		contentPane.add(lblAddressType);
	}
}
