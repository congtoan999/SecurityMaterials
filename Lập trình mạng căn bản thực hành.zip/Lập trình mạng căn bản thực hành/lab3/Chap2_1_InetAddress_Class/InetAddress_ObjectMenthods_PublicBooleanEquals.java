package Chap2_1_InetAddress_Class;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.awt.event.ActionEvent;

public class InetAddress_ObjectMenthods_PublicBooleanEquals extends JFrame {
	private JPanel contentPane;
	private JTextField textFieldAddress1;
	private JTextField textFieldAddress2;
	/**
	* Launch the application.
	
	*/
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					InetAddress_ObjectMenthods_PublicBooleanEquals frame = new
					InetAddress_ObjectMenthods_PublicBooleanEquals();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	/**
	* Create the frame.
	*/
	public InetAddress_ObjectMenthods_PublicBooleanEquals() {
		setTitle("Are addresses the same");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 558, 415);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Enter Address 1:");
		lblNewLabel.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		lblNewLabel.setBounds(26, 31, 119, 23);
		contentPane.add(lblNewLabel);
		
		JLabel lblEnterAddress = new JLabel("Enter Address 2:");
		lblEnterAddress.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		lblEnterAddress.setBounds(26, 67, 119, 23);
		contentPane.add(lblEnterAddress);
		
		JLabel lblResult = new JLabel("Result:");
		lblResult.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		lblResult.setBounds(73, 206, 50, 23);
		contentPane.add(lblResult);
		
		textFieldAddress1 = new JTextField();
		textFieldAddress1.setText("www.ibiblio.org");
		textFieldAddress1.setBounds(157, 32, 311, 22);
		contentPane.add(textFieldAddress1);
		textFieldAddress1.setColumns(10);
		
		textFieldAddress2 = new JTextField();
		textFieldAddress2.setText("helios.metalab.unc.edu");
		textFieldAddress2.setColumns(10);
		textFieldAddress2.setBounds(157, 68, 311, 22);
		contentPane.add(textFieldAddress2);
		
		JTextArea textArea = new JTextArea();
		textArea.setEditable(false);
		
		textArea.setBounds(157, 190, 311, 48);
		contentPane.add(textArea);
		JButton btnNewButton = new JButton("Click Me!");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String getAddress1 = textFieldAddress1.getText();
				String getAddress2 = textFieldAddress2.getText();
				try {
					InetAddress address1 = InetAddress.getByName(getAddress1);
					InetAddress address2 = InetAddress.getByName(getAddress2);
					if (address1.equals(address2)) {
						textArea.setText(address1.getHostName()+" is the same as " +address2.getHostName());
						}
					else {
						textArea.setText(address1.getHostName()+" is not the same as " +address2.getHostName());
					}
				} catch (UnknownHostException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
				}
			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 16));
		btnNewButton.setBounds(230, 115, 119, 38);
		contentPane.add(btnNewButton);
	}
}
