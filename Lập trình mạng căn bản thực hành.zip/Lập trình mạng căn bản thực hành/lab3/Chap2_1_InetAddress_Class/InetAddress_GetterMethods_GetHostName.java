package Chap2_1_InetAddress_Class;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;

public class InetAddress_GetterMethods_GetHostName extends JFrame {
	private JPanel contentPane;
	private JTextField textFieldAddress;
	
	/**
	* Launch the application.
	*/
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
						InetAddress_GetterMethods_GetHostName frame = new
						InetAddress_GetterMethods_GetHostName();
						frame.setVisible(true);
				} catch (Exception e) {
						e.printStackTrace();
				}
			}
		});
	}
	/**
	* Create the frame.
	*/
	public InetAddress_GetterMethods_GetHostName() {
		setTitle("InetAddress_GetterMethods_GetHostName");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 563, 325);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Enter Address:");
		lblNewLabel.setBounds(25, 34, 94, 24);
		contentPane.add(lblNewLabel);
		
		textFieldAddress = new JTextField();
		textFieldAddress.setText("dantri.com.vn");
		textFieldAddress.setBounds(131, 35, 323, 22);
		contentPane.add(textFieldAddress);
		textFieldAddress.setColumns(10);
		
		JLabel lblHostname = new JLabel("Result:");
		lblHostname.setBounds(47, 150, 72, 24);
		contentPane.add(lblHostname);
		
		JTextArea textAreaResult = new JTextArea();
		textAreaResult.setEditable(false);
		textAreaResult.setBounds(129, 124, 325, 89);
		
		contentPane.add(textAreaResult);
		
		JButton btnNewButton = new JButton("Click Me!");
		btnNewButton.addActionListener(new ActionListener() {
		
			public void actionPerformed(ActionEvent e) {
				String getAddress = textFieldAddress.getText();
				try {
					InetAddress ia = InetAddress.getByName(getAddress);
					String str ="HostName and IP Address: "+ ia +"\n";
					str += "HostName: "+ ia.getHostName();
					textAreaResult.setText(str);
				} catch (UnknownHostException e1) {
					// TODO Auto-generated catch block
					//e1.printStackTrace();
					textAreaResult.setText("Could not find "+getAddress);
				}
			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 14));
		btnNewButton.setBounds(246, 80, 97, 25);
		contentPane.add(btnNewButton);
	}
}
