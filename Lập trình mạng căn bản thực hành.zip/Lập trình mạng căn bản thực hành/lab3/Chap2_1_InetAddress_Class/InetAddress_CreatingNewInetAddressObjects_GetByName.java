package Chap2_1_InetAddress_Class;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class InetAddress_CreatingNewInetAddressObjects_GetByName extends JFrame {
	private JPanel contentPane;
	private JTextField textFieldAdress;
	private JTextField textFieldResult;
	/**
	* Launch the application.
	*/
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
				public void run() {
					try {
						InetAddress_CreatingNewInetAddressObjects_GetByName frame = new
						InetAddress_CreatingNewInetAddressObjects_GetByName();
									frame.setVisible(true);
	
					} catch (Exception e) {
						e.printStackTrace();
	
					}
				}
		});
	}
	/**
	* Create the frame.
	*/
	public InetAddress_CreatingNewInetAddressObjects_GetByName() {
		setTitle("InetAddress_GetByName");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 521, 332);
		contentPane = new JPanel();
		
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel(" Enter HostName:");
		lblNewLabel.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		lblNewLabel.setBounds(12, 38, 122, 16);
		contentPane.add(lblNewLabel);
		
		textFieldAdress = new JTextField();
		textFieldAdress.setBounds(167, 35, 312, 22);
		contentPane.add(textFieldAdress);
		textFieldAdress.setColumns(10);
		
		JLabel lblResult = new JLabel("Result:");
		lblResult.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		lblResult.setBounds(84, 148, 50, 16);
		contentPane.add(lblResult);
		
		textFieldResult = new JTextField();
		textFieldResult.setEditable(false);
		textFieldResult.setBounds(167, 146, 312, 22);
		contentPane.add(textFieldResult);
		textFieldResult.setColumns(10);
		
		JButton btnNewButton = new JButton("Click Me!");
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 16));
		btnNewButton.addActionListener(new ActionListener() {
		
			public void actionPerformed(ActionEvent arg0) {
				//Lay gia tri string trong textFildAdress EX: dantri.com.vn or 42.113.206.26
				String hostName = textFieldAdress.getText();
				try {
					// Lay gia tri Hostaddress
					InetAddress address = InetAddress.getByName(hostName);
					// Gan ket qua vao textFielResult
					textFieldResult.setText(""+address);
				} catch (UnknownHostException e) {
					// Bao loi khi khong tim thay ket qua
					textFieldResult.setText("Could not find "+hostName);
				}
			}
		});
		btnNewButton.setBounds(252, 82, 114, 33);
		contentPane.add(btnNewButton);
	}
}	