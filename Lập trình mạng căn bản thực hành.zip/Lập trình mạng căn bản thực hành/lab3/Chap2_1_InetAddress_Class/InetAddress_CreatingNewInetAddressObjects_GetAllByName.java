package Chap2_1_InetAddress_Class;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.awt.event.ActionEvent;

public class InetAddress_CreatingNewInetAddressObjects_GetAllByName extends JFrame {
	private JPanel contentPane;
	private JTextField textFieldHostName;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					InetAddress_CreatingNewInetAddressObjects_GetAllByName frame = new InetAddress_CreatingNewInetAddressObjects_GetAllByName();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public InetAddress_CreatingNewInetAddressObjects_GetAllByName() {
		setTitle("InetAddress_getAllByName");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 541, 313);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);

		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("Enter HostName:");
		lblNewLabel.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		lblNewLabel.setBounds(27, 30, 116, 23);
		contentPane.add(lblNewLabel);

		textFieldHostName = new JTextField();
		textFieldHostName.setText("microsoft.com");
		textFieldHostName.setBounds(150, 31, 343, 22);
		contentPane.add(textFieldHostName);
		textFieldHostName.setColumns(10);

		JLabel lblIpAddresses = new JLabel("IP Addresses:");
		lblIpAddresses.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		lblIpAddresses.setBounds(38, 153, 97, 23);
		contentPane.add(lblIpAddresses);

		JTextArea textAreaIPs = new JTextArea();
		textAreaIPs.setEditable(false);
		textAreaIPs.setBounds(150, 104, 343, 115);
		contentPane.add(textAreaIPs);

		JButton btnNewButton = new JButton("Click Me!");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String hostName = textFieldHostName.getText();
				try {
					String str = "";
					InetAddress[] addresses = InetAddress.getAllByName(hostName);
					for (int i = 0; i < addresses.length; i++) {
						str += i + 1 + ":" + addresses[i] + "\n";
					}
					textAreaIPs.setText(str);
				} catch (UnknownHostException e) {
					e.printStackTrace();
				}
			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		btnNewButton.setBounds(277, 66, 97, 25);
		contentPane.add(btnNewButton);
	}
}
