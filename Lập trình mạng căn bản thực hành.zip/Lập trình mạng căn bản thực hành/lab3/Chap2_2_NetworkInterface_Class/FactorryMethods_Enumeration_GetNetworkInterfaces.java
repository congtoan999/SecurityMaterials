package Chap2_2_NetworkInterface_Class;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Enumeration;
import java.awt.event.ActionEvent;

public class FactorryMethods_Enumeration_GetNetworkInterfaces extends JFrame {
	private JPanel contentPane;
	/**
	* Launch the application.
	*/
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FactorryMethods_Enumeration_GetNetworkInterfaces frame = new FactorryMethods_Enumeration_GetNetworkInterfaces();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	/**
	* Create the frame.
	*/
	public FactorryMethods_Enumeration_GetNetworkInterfaces() {
		setTitle("FactorryMethods_Enumeration_GetNetworkInterfaces");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 623, 344);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		JLabel lblNewLabel = new JLabel("InterfaceLister:");
		lblNewLabel.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		lblNewLabel.setBounds(33, 149, 100, 26);
		contentPane.add(lblNewLabel);
		
		JTextArea textAreaInterfaceLister = new JTextArea();
		textAreaInterfaceLister.setEditable(false);
		textAreaInterfaceLister.setBounds(145, 58, 353, 226);
		contentPane.add(textAreaInterfaceLister);
		JButton btnNewButton = new JButton("Click Me!");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String str=" ";
				try {
					Enumeration interfaces = NetworkInterface.getNetworkInterfaces( );
					while (interfaces.hasMoreElements( )) { NetworkInterface ni = (NetworkInterface) interfaces.nextElement( ); 
					str +=" "+ ni +"\n";
					}
					textAreaInterfaceLister.setText(str);
				} catch (SocketException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 16));
		btnNewButton.setBounds(239, 13, 137, 32);
		contentPane.add(btnNewButton);
	}
}
