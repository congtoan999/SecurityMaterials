package Chap2_2_NetworkInterface_Class;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.Font;

public class FactoryMethods_NetworkInterface_GetByName_Demo extends JFrame {
	private JPanel contentPane;
	private JTextField textFieldInterfaceName;
	private JTextField textFieldResult;
	/**
	
	* Launch the application.
	*/
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FactoryMethods_NetworkInterface_GetByName_Demo frame = new FactoryMethods_NetworkInterface_GetByName_Demo();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	/**
	* Create the frame.
	*/
	public FactoryMethods_NetworkInterface_GetByName_Demo() {
		setTitle("FactoryMethods_NetworkInterface_GetByName_Demo");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 529, 257);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("Enter Interface Name:");
		lblNewLabel.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		lblNewLabel.setBounds(12, 32, 135, 25);
		contentPane.add(lblNewLabel);
		
		textFieldInterfaceName = new JTextField();
		textFieldInterfaceName.setText("eth0");
		textFieldInterfaceName.setBounds(153, 33, 246, 22);
		contentPane.add(textFieldInterfaceName);
		textFieldInterfaceName.setColumns(10);
		
		JLabel lblResult = new JLabel("Result:");
		lblResult.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		lblResult.setBounds(59, 127, 47, 25);
		contentPane.add(lblResult);
		
		textFieldResult = new JTextField();
		textFieldResult.setEditable(false);
		textFieldResult.setColumns(10);
		textFieldResult.setBounds(103, 129, 358, 22);
		contentPane.add(textFieldResult);
		
		JButton btnNewButton = new JButton("Click Me!");
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 16));
		
		btnNewButton.setBounds(218, 76, 114, 25);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String getNetworkInterfaceName = textFieldInterfaceName.getText();
				try {
					NetworkInterface ni = NetworkInterface.getByName(getNetworkInterfaceName);
					if (ni == null) {
						textFieldResult.setText("No such interface: " +getNetworkInterfaceName);
					}
					else textFieldResult.setText(""+ni);;
				}
				catch (SocketException ex) {
					textFieldResult.setText("Could not list sockets." );
				}
			}
		});
		contentPane.setLayout(null);
		contentPane.add(btnNewButton);
	}
}
