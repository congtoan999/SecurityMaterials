package Chap2_2_NetworkInterface_Class;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.awt.event.ActionEvent;

public class FactoryMethods_NetworkInterface_GetByInetAddress extends JFrame {
	private JPanel contentPane;
	private JTextField textFieldIP;
	private JTextField textFieldResult;
	/**
	* Launch the application.
	*/
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FactoryMethods_NetworkInterface_GetByInetAddress frame = new FactoryMethods_NetworkInterface_GetByInetAddress();
					frame.setVisible(true);
	
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	/**
	* Create the frame.
	*/
	public FactoryMethods_NetworkInterface_GetByInetAddress() {
		setTitle("FactoryMethods_NetworkInterface_GetByInetAddress");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 578, 321);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		JLabel lblNewLabel = new JLabel("Enter IP:");
		lblNewLabel.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		lblNewLabel.setBounds(55, 41, 68, 16);
		contentPane.add(lblNewLabel);
		textFieldIP = new JTextField();
		textFieldIP.setText("127.0.0.1");
		textFieldIP.setBounds(150, 39, 290, 22);
		contentPane.add(textFieldIP);
		textFieldIP.setColumns(10);
		JLabel lblResult = new JLabel("Result:");
		lblResult.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		lblResult.setBounds(66, 135, 57, 16);
		contentPane.add(lblResult);
		textFieldResult = new JTextField();
		textFieldResult.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		textFieldResult.setEditable(false);
		textFieldResult.setColumns(10);
		textFieldResult.setBounds(150, 133, 290, 22);
		contentPane.add(textFieldResult);
		JButton btnNewButton = new JButton("Click Me!");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String getIP = textFieldIP.getText();
				try {
					InetAddress local = InetAddress.getByName(getIP);
					NetworkInterface ni =
							NetworkInterface.getByInetAddress(local);
					if (ni == null) {
						textFieldResult.setText("That's weird. No local loopback address.");
					}
					textFieldResult.setText(""+ni);//""+ni convert ni to String
				}
				catch (SocketException ex) {
							textFieldResult.setText("Could not list sockets." );
				}
				catch (UnknownHostException ex) {
					textFieldResult.setText("That's weird. No local loopback address.");
				}
			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 16));
		btnNewButton.setBounds(213, 79, 128, 25);
		contentPane.add(btnNewButton);
	}
}
