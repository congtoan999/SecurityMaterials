package Chap4_5_ChatClientSever;
import java.net.*;
import java.io.*;
public class echoClient1 {
	public static void main(String[] args)
	{
		String hostname="localhost";
		if(args.length>0){
			hostname=args[0];
		}
		PrintWriter pw=null;
		BufferedReader br=null;
		try{
			Socket s=new Socket(hostname,2007);
			br=new BufferedReader(new InputStreamReader(s.getInputStream()));
			BufferedReader user=new BufferedReader(new
					InputStreamReader(System.in));
			pw=new PrintWriter(s.getOutputStream());
			System.out.println("Da ket noi duoc voi server...");
			while(true){
				String st=user.readLine();
				if(st.equals("exit")) {
					break;
				}
				pw.println(st);
				pw.flush();
				System.out.println(br.readLine());
			}
		}
		catch(IOException e){
			System.err.println(e);
		}
		finally{
			try{
				if(br!=null)br.close();
				if(pw!=null)pw.close();
			}
			catch(IOException e){
				System.err.println(e);
			}
		}
	}
}