package lab2;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class Manu extends JFrame {
    private JPanel contentPane;
    public Student student[] = new Student[10];

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Manu frame = new Manu();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public Manu() {
        setTitle("Lab2 Main Manu");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 499, 337);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JMenuBar menuBar = new JMenuBar();
        menuBar.setBounds(0, 0, 485, 22);
        contentPane.add(menuBar);

        JMenu mnNewMenu = new JMenu(" Create User");
        mnNewMenu.setFont(new Font("Times New Roman", Font.BOLD, 14));
        menuBar.add(mnNewMenu);

        JMenuItem mntmNewMenuItem = new JMenuItem("Create Student");
        mntmNewMenuItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Create_Student_Form createStudent = new Create_Student_Form();
                createStudent.setVisible(true);
            }
        });
        mntmNewMenuItem.setFont(new Font("Times New Roman", Font.PLAIN, 14));
        mnNewMenu.add(mntmNewMenuItem);

        JMenuItem mntmNewMenuItem_1 = new JMenuItem("Create Teacher");
        mntmNewMenuItem_1.setFont(new Font("Times New Roman", Font.PLAIN, 14));
        mnNewMenu.add(mntmNewMenuItem_1);

        JMenu mnShowUser = new JMenu(" | Show User |");
        mnShowUser.setFont(new Font("Times New Roman", Font.BOLD, 14));
        menuBar.add(mnShowUser);

        JMenuItem mntmShowStudent = new JMenuItem("Show Student");
        mntmShowStudent.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, " Student Code:"+student[0].code+ "\n Student Name: " + student[0].name);
            }
        });
        mntmShowStudent.setFont(new Font("Times New Roman", Font.PLAIN, 14));
        mnShowUser.add(mntmShowStudent);

        JMenuItem mntmNewMenuItem_1_1 = new JMenuItem("Show Teacher");
        mntmNewMenuItem_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 14));
        mnShowUser.add(mntmNewMenuItem_1_1);

        JLabel lblNewLabel_1 = new JLabel("Nguyễn Công Toàn MSSV:52200271");
        lblNewLabel_1.setForeground(Color.RED);
        lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 20));
        lblNewLabel_1.setVerticalAlignment(SwingConstants.TOP);
        lblNewLabel_1.setIcon(new ImageIcon("landscape-photography_1645-t.jpg"));
        lblNewLabel_1.setBounds(34, 65, 402, 152);
        contentPane.add(lblNewLabel_1);

        JLabel lblNewLabel = new JLabel("");
        lblNewLabel.setIcon(new ImageIcon("landscape-photography_1645-t.jpg"));
        lblNewLabel.setBounds(0, 22, 485, 278);
        contentPane.add(lblNewLabel);
    }
}
