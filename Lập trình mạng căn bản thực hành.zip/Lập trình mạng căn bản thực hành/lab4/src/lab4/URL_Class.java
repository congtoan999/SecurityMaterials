package lab4;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import Chap3_1_URLs_Creating_New_URLs.Constructing_A_URL_from_Its_Component_parts1;
import Chap3_1_URLs_Creating_New_URLs.Constructing_Relative_URLs;
import Chap3_1_URLs_Creating_New_URLs.Constructing_URL_From_String;
import Chap3_1_URLs_Creating_New_URLs.Constructing_a_URL_from_Its_component_parts2;
import Chap3_2_URLs_Splitting_A_URL_Into_Pieces.GetAuthority;
import Chap3_2_URLs_Splitting_A_URL_Into_Pieces.GetDefaultPort;
import Chap3_2_URLs_Splitting_A_URL_Into_Pieces.GetFile;
import Chap3_2_URLs_Splitting_A_URL_Into_Pieces.GetHost;
import Chap3_2_URLs_Splitting_A_URL_Into_Pieces.GetPath;
import Chap3_2_URLs_Splitting_A_URL_Into_Pieces.GetPort;
import Chap3_2_URLs_Splitting_A_URL_Into_Pieces.GetProtocol;
import Chap3_2_URLs_Splitting_A_URL_Into_Pieces.GetQuery;
import Chap3_2_URLs_Splitting_A_URL_Into_Pieces.GetRef;
import Chap3_2_URLs_Splitting_A_URL_Into_Pieces.GetUserInfo;
import Chap3_3_Retrieving_Data_From_A_URL.InputStream_OpenStream_Download_A_Web_Page;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import java.awt.Font;
import javax.swing.UIManager;
import javax.swing.JMenuItem;
import java.awt.event.ActionListener;
import java.io.ObjectInputStream.GetField;
import java.awt.event.ActionEvent;
import java.awt.SystemColor;

import java.awt.Color;
import javax.swing.JTextField;
	public class URL_Class extends JFrame {
		private JPanel contentPane;
		private JTextField txtHTnSv;
		/**
		 * Launch the application.
		 */
		public static void main(String[] args) {
			EventQueue.invokeLater(new Runnable() {
				public void run() {
					try {
						URL_Class frame = new URL_Class();
						frame.setVisible(true);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			});
		}
		/**
		 * Create the frame.
		 */
	public URL_Class() {
		setTitle("Lab Part3 URL Class");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 754, 397);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBackground(SystemColor.inactiveCaptionBorder);
		menuBar.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		menuBar.setToolTipText("");
		menuBar.setBounds(0, 0, 732, 43);
		contentPane.add(menuBar);
		JMenu mnNewMenu = new JMenu("Creating New URLs");
		mnNewMenu.setForeground(Color.GREEN);
		mnNewMenu.setBackground(UIManager.getColor("Button.background"));
		mnNewMenu.setFont(new Font("Times New Roman", Font.BOLD, 20));
		menuBar.add(mnNewMenu);
		JMenuItem mntmNewMenuItem = new JMenuItem("Constructing a URL from a String");
		mntmNewMenuItem.setFont(new Font("Times New Roman", Font.BOLD, 20));
		mntmNewMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Constructing_URL_From_String constructing_string = new Constructing_URL_From_String();
				constructing_string.setVisible(true);
			}
		});
		JMenuItem mntmNewMenuItem_2 = new JMenuItem("Constructing relative URLs");
		mntmNewMenuItem_2.setFont(new Font("Times New Roman", Font.BOLD, 20));
		mntmNewMenuItem_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Constructing_Relative_URLs frame = new Constructing_Relative_URLs();
				frame.setVisible(true);
		
			}
		});
		mnNewMenu.add(mntmNewMenuItem_2);
		mnNewMenu.add(mntmNewMenuItem);
		JMenuItem mntmNewMenuItem_1 = new JMenuItem("Constructing a URL from its component part1");
		mntmNewMenuItem_1.setFont(new Font("Times New Roman", Font.BOLD, 20));
		mntmNewMenuItem_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Constructing_A_URL_from_Its_Component_parts1 frame = new Constructing_A_URL_from_Its_Component_parts1();
				frame.setVisible(true);
			}
		});
		mnNewMenu.add(mntmNewMenuItem_1);
		JMenuItem mntmNewMenuItem_1_1 = new JMenuItem("Constructing a URL from its component part2");
		mntmNewMenuItem_1_1.setFont(new Font("Times New Roman", Font.BOLD, 20));
		mntmNewMenuItem_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Constructing_a_URL_from_Its_component_parts2 frame = new Constructing_a_URL_from_Its_component_parts2();
				frame.setVisible(true);
			}
		});
		mnNewMenu.add(mntmNewMenuItem_1_1);
		JMenu mnNewMenu_1 = new JMenu("Splitting a URL into Pieces");
		mnNewMenu_1.setForeground(Color.CYAN);
		mnNewMenu_1.setFont(new Font("Times New Roman", Font.BOLD, 20));
		menuBar.add(mnNewMenu_1);
		JMenuItem mntmNewMenuItem_3 = new JMenuItem("GetAuthority");
		mntmNewMenuItem_3.setFont(new Font("Times New Roman", Font.BOLD, 20));
		mntmNewMenuItem_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GetAuthority frame = new GetAuthority();
				frame.setVisible(true);
			}
		});
		mnNewMenu_1.add(mntmNewMenuItem_3);
		JMenuItem mntmNewMenuItem_4 = new JMenuItem("GetDefaultPort");
		mntmNewMenuItem_4.setFont(new Font("Times New Roman", Font.BOLD, 20));
		mntmNewMenuItem_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GetDefaultPort frame = new GetDefaultPort();
				frame.setVisible(true);
			}
		});
		mnNewMenu_1.add(mntmNewMenuItem_4);
		JMenuItem mntmNewMenuItem_8 = new JMenuItem("GetPort");
		mntmNewMenuItem_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GetPort frame = new GetPort();
				frame.setVisible(true);
			}
		});
		mntmNewMenuItem_8.setFont(new Font("Times New Roman", Font.BOLD, 20));
		mnNewMenu_1.add(mntmNewMenuItem_8);
		JMenuItem mntmNewMenuItem_5 = new JMenuItem("GetFile");
		mntmNewMenuItem_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GetFile frame = new GetFile();
				frame.setVisible(true);
			}
		});
		mntmNewMenuItem_5.setFont(new Font("Times New Roman", Font.BOLD, 20));
		mnNewMenu_1.add(mntmNewMenuItem_5);
		JMenuItem mntmNewMenuItem_6 = new JMenuItem("GetHost");
		mntmNewMenuItem_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GetHost frame = new GetHost();
				frame.setVisible(true);
			}
		});
		mntmNewMenuItem_6.setFont(new Font("Times New Roman", Font.BOLD, 20));
		mnNewMenu_1.add(mntmNewMenuItem_6);
		JMenuItem mntmNewMenuItem_7 = new JMenuItem("GetPath");
		mntmNewMenuItem_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GetPath frame = new GetPath();
				frame.setVisible(true);
			}
		});
		mntmNewMenuItem_7.setFont(new Font("Times New Roman", Font.BOLD, 20));
		mnNewMenu_1.add(mntmNewMenuItem_7);
		JMenuItem mntmNewMenuItem_9 = new JMenuItem("GetProtocol");
		mntmNewMenuItem_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GetProtocol frame = new GetProtocol();
				frame.setVisible(true);
			}
		});
		mntmNewMenuItem_9.setFont(new Font("Times New Roman", Font.BOLD, 20));
		mnNewMenu_1.add(mntmNewMenuItem_9);
		JMenuItem mntmNewMenuItem_10 = new JMenuItem("GetQuery");
		mntmNewMenuItem_10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GetQuery frame = new GetQuery();
				frame.setVisible(true);
			}
		});
		mntmNewMenuItem_10.setFont(new Font("Times New Roman", Font.BOLD, 20));
		mnNewMenu_1.add(mntmNewMenuItem_10);
		JMenuItem mntmNewMenuItem_11 = new JMenuItem("GetRef");
		mntmNewMenuItem_11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GetRef frame = new GetRef();
				frame.setVisible(true);
			}
		});
		mntmNewMenuItem_11.setFont(new Font("Times New Roman", Font.BOLD, 20));
		mnNewMenu_1.add(mntmNewMenuItem_11);
		JMenuItem mntmNewMenuItem_12 = new JMenuItem("GetUserInfo");
		mntmNewMenuItem_12.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GetUserInfo frame = new GetUserInfo();
				frame.setVisible(true);
			}
		});
		mntmNewMenuItem_12.setFont(new Font("Times New Roman", Font.BOLD, 20));
		mnNewMenu_1.add(mntmNewMenuItem_12);
		
		JMenu mnNewMenu_2 = new JMenu("Retrieving Data from a URL");
		mnNewMenu_2.setForeground(Color.BLUE);
		mnNewMenu_2.setFont(new Font("Times New Roman", Font.BOLD, 20));
		menuBar.add(mnNewMenu_2);
		JMenuItem mntmNewMenuItem_13 = new JMenuItem("Download a web page");
		mntmNewMenuItem_13.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				InputStream_OpenStream_Download_A_Web_Page frame = new InputStream_OpenStream_Download_A_Web_Page();
				frame.setVisible(true);
			}
		});
		mntmNewMenuItem_13.setFont(new Font("Times New Roman", Font.BOLD, 20));
		mnNewMenu_2.add(mntmNewMenuItem_13);
		JMenuItem mntmNewMenuItem_14 = new JMenuItem("Download an object");
		mntmNewMenuItem_14.setFont(new Font("Times New Roman", Font.BOLD, 20));
		mnNewMenu_2.add(mntmNewMenuItem_14);
		JMenuItem mntmNewMenuItem_15 = new JMenuItem("Are the sameFiles?");
		mntmNewMenuItem_15.setFont(new Font("Times New Roman", Font.BOLD, 20));
		mnNewMenu_2.add(mntmNewMenuItem_15);
		txtHTnSv = new JTextField();
		txtHTnSv.setEditable(false);
		txtHTnSv.setText(" H\u1ECD T\u00EAn SV, M\u00E3 SV");
		txtHTnSv.setFont(new Font("Times New Roman", Font.BOLD, 27));
		txtHTnSv.setBounds(238, 152, 274, 52);
		contentPane.add(txtHTnSv);
		txtHTnSv.setColumns(10);
	}
}