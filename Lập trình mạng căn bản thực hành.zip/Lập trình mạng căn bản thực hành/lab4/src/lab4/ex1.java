package lab4;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import java.awt.Rectangle;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JTextArea;
import javax.swing.AbstractAction;
import java.awt.event.ActionEvent;
import javax.swing.Action;
import java.awt.event.ActionListener;

public class ex1 extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtHttps;
	private JButton btnNewButton;
	private final Action action = new SwingAction();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ex1 frame = new ex1();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ex1() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBounds(new Rectangle(139, 0, 0, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		txtHttps = new JTextField();
		txtHttps.setBounds(163, 44, 202, 20);
		txtHttps.setText("https://dantri.com.vn/the-gioi.htm");
		contentPane.add(txtHttps);
		txtHttps.setColumns(10);
		
		JLabel lblEnterl = new JLabel("Enter URL:");
		lblEnterl.setBounds(53, 44, 80, 20);
		lblEnterl.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		contentPane.add(lblEnterl);
		
		btnNewButton = new JButton("Click Me!");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		btnNewButton.setBounds(198, 88, 115, 25);
		contentPane.add(btnNewButton);
		
		JLabel lblIpAddresses = new JLabel("Result:");
		lblIpAddresses.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		lblIpAddresses.setBounds(53, 151, 97, 23);
		contentPane.add(lblIpAddresses);
		
		JTextArea txtrHttpsdantricomvnthegioihtm = new JTextArea();
		txtrHttpsdantricomvnthegioihtm.setEditable(false);
		txtrHttpsdantricomvnthegioihtm.setBounds(163, 151, 202, 23);
		contentPane.add(txtrHttpsdantricomvnthegioihtm);
	}

	protected Rectangle getTxtHttpsBounds() {
		return txtHttps.getBounds();
	}
	protected void setTxtHttpsBounds(Rectangle bounds) {
		txtHttps.setBounds(bounds);
	}
	public JButton getBtnNewButton() {
		return btnNewButton;
	}
	private class SwingAction extends AbstractAction {
		public SwingAction() {
			putValue(NAME, "SwingAction");
			putValue(SHORT_DESCRIPTION, "Some short description");
		}
		public void actionPerformed(ActionEvent e) {
		}
	}
}
