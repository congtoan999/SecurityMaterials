package lab4;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import Chap3.URL_Class;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.net.MalformedURLException;
import java.net.URL;
import java.awt.event.ActionEvent;
	public class Constructing_Relative_URLs extends JFrame {
		private JPanel contentPane;
		private JTextField textFieldU1;
		private JTextField textFieldU2;
		private JTextField textFieldResult;
		
		private JButton btnNewButton_1;
		/**
		* Launch the application.
		*/
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Constructing_Relative_URLs frame = new Constructing_Relative_URLs();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
		/**
		* Create the frame.
		*/
	public Constructing_Relative_URLs() {
		setTitle("Constructing_Relative_URLs ");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 670, 414);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		JLabel lblNewLabel = new JLabel("Enter Data1:");
		lblNewLabel.setBounds(62, 33, 81, 28);
		contentPane.add(lblNewLabel);
		JLabel lblEnterUrl = new JLabel("Enter Data2:");
		lblEnterUrl.setBounds(62, 74, 81, 28);
		contentPane.add(lblEnterUrl);
		textFieldU1 = new JTextField();
		textFieldU1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		textFieldU1.setText("\"http://www.ibiblio.org/javafaq/index.html\"");
		textFieldU1.setBounds(155, 36, 393, 28);
		contentPane.add(textFieldU1);
		textFieldU1.setColumns(10);
		textFieldU2 = new JTextField();
		textFieldU2.setFont(new Font("Tahoma", Font.PLAIN, 18));
		textFieldU2.setText("u1, \"mailinglists.html\"");
		textFieldU2.setColumns(10);
		textFieldU2.setBounds(155, 77, 393, 33);
		contentPane.add(textFieldU2);
		JLabel lblResult = new JLabel("Result:");
		lblResult.setBounds(78, 224, 54, 28);
		contentPane.add(lblResult);
		textFieldResult = new JTextField();
		textFieldResult.setFont(new Font("Times New Roman", Font.BOLD, 20));
		textFieldResult.setEditable(false);
		textFieldResult.setColumns(10);
		textFieldResult.setBounds(136, 214, 435, 45);
		contentPane.add(textFieldResult);
		JButton btnNewButton = new JButton("Click Me!");
		btnNewButton.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		
			String getURL1 = textFieldU1.getText();
			String getURL2 = textFieldU2.getText();
			try {
				URL u1 = new URL("http://www.ibiblio.org/javafaq/index.html");
				URL u2 = new URL (u1, "mailinglists.html");
				textFieldResult.setText(""+u2);
			}
			catch (MalformedURLException ex) {
				System.err.println(ex);
				textFieldResult.setText("this "+ getURL1 +" or "+getURL2+"is
						Unknown Source");
			}
		}
	});
	btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 20));
	btnNewButton.setBounds(283, 141, 130, 45);
	contentPane.add(btnNewButton);
	btnNewButton_1 = new JButton("Back");
	btnNewButton_1.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
		URL_Class frame = new URL_Class();
		frame.setVisible(true);
		dispose();
		}
	});
		btnNewButton_1.setFont(new Font("Times New Roman", Font.BOLD, 21));
		btnNewButton_1.setBounds(309, 316, 97, 38);
		contentPane.add(btnNewButton_1);
	}
}
