package Chat;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.nio.file.Files;

public class ServerUDPChat extends JFrame {
    private static final int PORT = 42349;
    private static Set<InetSocketAddress> clientAddresses = new HashSet<>();
    private JTextArea serverLogArea;
    private JTextField senderNameField;
    private JTextField subjectField;
    private JTextArea messageField;
    private JButton sendButton;
    private JButton attachFileButton;
    private DatagramSocket socket;
    private JButton recallButton;
    private JButton editButton;
    private int messageID = 0;
    private InetAddress serverAddress;
    private int serverPort;
    private Map<Integer, String> sentMessages = new HashMap<>();

    public ServerUDPChat() {
        setTitle("UDP Chat Room Server");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 600);

        // Setup the layout
        setLayout(new BorderLayout(10, 10));

        // Header panel
        JPanel headerPanel = new JPanel();
        headerPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
        headerPanel.setLayout(new BorderLayout());
        JLabel headerLabel = new JLabel("UDP Chat Room Server", JLabel.CENTER);
        headerLabel.setFont(new Font("Arial", Font.BOLD, 18));
        headerPanel.add(headerLabel, BorderLayout.CENTER);
        add(headerPanel, BorderLayout.NORTH);

        // Log area
        serverLogArea = new JTextArea();
        serverLogArea.setEditable(false);
        serverLogArea.setFont(new Font("Monospaced", Font.PLAIN, 14));
        JScrollPane scrollPane = new JScrollPane(serverLogArea);
        add(scrollPane, BorderLayout.CENTER);

        // Input panel
        JPanel inputPanel = new JPanel();
        inputPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
        inputPanel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Họ tên
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.WEST;
        inputPanel.add(new JLabel("Họ tên:"), gbc);
        senderNameField = new JTextField(20);
        gbc.gridx = 1;
        gbc.gridy = 0;
        inputPanel.add(senderNameField, gbc);

        // Tiêu đề
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.WEST;
        inputPanel.add(new JLabel("Tiêu đề:"), gbc);
        subjectField = new JTextField(20);
        gbc.gridx = 1;
        gbc.gridy = 1;
        inputPanel.add(subjectField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 1;
        inputPanel.add(new JLabel("Nội dung:"), gbc);
        messageField = new JTextArea(5, 20);
        JScrollPane messageInputScrollPane = new JScrollPane(messageField);
        gbc.gridx = 1;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        inputPanel.add(messageInputScrollPane, gbc);

        // Đính kèm file button
        attachFileButton = new JButton("Đính kèm file");
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.WEST;
        inputPanel.add(attachFileButton, gbc);

        // Gửi button
        sendButton = new JButton("Gửi");
        gbc.gridx = 1;
        gbc.gridy = 4;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.WEST;
        inputPanel.add(sendButton, gbc);

        // Recall button
        recallButton = new JButton("Thu hồi tin nhắn");
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.CENTER;
        inputPanel.add(recallButton, gbc);

        // Edit button
        editButton = new JButton("Chỉnh sửa tin nhắn");
        gbc.gridx = 1;
        gbc.gridy = 5;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.CENTER;
        inputPanel.add(editButton, gbc);

        // ActionListener cho nút gửi
        sendButton.addActionListener(e -> sendMessage(socket));

        // ActionListener cho nút đính kèm file
        attachFileButton.addActionListener(e -> attachFile());

        recallButton.addActionListener(e -> recallMessage());

        // Thêm ActionListener cho nút editButton
        editButton.addActionListener(e -> editMessage());

        // Add input panel to frame
        add(inputPanel, BorderLayout.SOUTH);

        setVisible(true);

        startServer();
    }

	    private void startServer() {
	        new Thread(() -> {
	            try {
	                socket = new DatagramSocket(PORT);
	                serverLogArea.append("Chat server is running...\n");
	                while (true) {
	                    byte[] receiveBuffer = new byte[1024];
	                    DatagramPacket receivePacket = new DatagramPacket(receiveBuffer, receiveBuffer.length);
	                    socket.receive(receivePacket);
	
	                    // Set serverAddress and serverPort
	                    serverAddress = receivePacket.getAddress();
	                    serverPort = receivePacket.getPort();
	
	                    InetAddress clientAddress = receivePacket.getAddress();
	                    int clientPort = receivePacket.getPort();
	                    InetSocketAddress clientSocketAddress = new InetSocketAddress(clientAddress, clientPort);
	
	                    String message = new String(receivePacket.getData(), 0, receivePacket.getLength());
	                    serverLogArea.append("Received " + message + "\n");
	
	                    if (!clientAddresses.contains(clientSocketAddress)) {
	                        clientAddresses.add(clientSocketAddress);
	                    }
	
	                    broadcastMessage(message, socket);
	                }
	            } catch (IOException e) {
	                e.printStackTrace();
	                serverLogArea.append("Error starting the server: " + e.getMessage() + "\n");
	            }
	        }).start();
	    }

    private void broadcastMessage(String message, DatagramSocket socket) {
        byte[] sendData = message.getBytes();
        for (InetSocketAddress clientAddress : clientAddresses) {
            DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, clientAddress.getAddress(), clientAddress.getPort());
            try {
                socket.send(sendPacket);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void sendMessage(DatagramSocket socket) {
        String senderName = senderNameField.getText();
        String subject = subjectField.getText();
        String message = messageField.getText();
        if (!senderName.trim().isEmpty() && !subject.trim().isEmpty() && !message.trim().isEmpty()) {
            messageID++;
            String fullMessage = "MessageID: " + messageID + " " + senderName + ": " + subject + " - " + message;
            sentMessages.put(messageID, fullMessage);  // Store the message with its ID
            for (InetSocketAddress clientAddress : clientAddresses) {
                byte[] sendData = fullMessage.getBytes();
                DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, clientAddress.getAddress(), clientAddress.getPort());
                try {
                    socket.send(sendPacket);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            serverLogArea.append("Sent : " + fullMessage + "\n");
            messageField.setText("");
        }
    }

    private void attachFile() {
        JFileChooser fileChooser = new JFileChooser();
        int returnValue = fileChooser.showOpenDialog(this);
        if (returnValue == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            String fileName = selectedFile.getName();
            String senderName = senderNameField.getText();
            String subject = subjectField.getText();

            try {
                byte[] fileBytes = Files.readAllBytes(selectedFile.toPath());
                String fileContent = Base64.getEncoder().encodeToString(fileBytes);

                String fileMessage = "FILE\n" + fileName + "\n" + senderName + "\n" + subject + "\n" + fileContent;
                byte[] sendData = fileMessage.getBytes();
                for (InetSocketAddress clientAddress : clientAddresses) {
                    DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, clientAddress.getAddress(), clientAddress.getPort());
                    try {
                        socket.send(sendPacket);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                serverLogArea.append("File attached: " + fileName + "\n");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void editMessage() {
        String messageIdStr = JOptionPane.showInputDialog(this, "Enter the message ID to edit:");
        if (messageIdStr != null && !messageIdStr.trim().isEmpty()) {
            try {
                int messageId = Integer.parseInt(messageIdStr);
                if (sentMessages.containsKey(messageId)) {
                    String oldMessage = sentMessages.get(messageId);
                    String[] parts = oldMessage.split(" - ", 2);
                    String newMessage = JOptionPane.showInputDialog(this, "Edit your message:", parts[1]);
                    if (newMessage != null && !newMessage.trim().isEmpty()) {
                        String updatedMessage = "MessageID: " + messageId + " - " + newMessage;
                        sentMessages.put(messageId, updatedMessage);
                        String editCommand = "EDIT " + messageId + " " + newMessage;
                        byte[] buffer = editCommand.getBytes();
                        DatagramPacket packet = new DatagramPacket(buffer, buffer.length, serverAddress, serverPort);
                        socket.send(packet);
                        serverLogArea.append("Message edited: " + messageIdStr + "\n");
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "Message ID not found.");
                }
            } catch (NumberFormatException | IOException e) {
                JOptionPane.showMessageDialog(this, "Invalid message ID format.");
            }
        }
    }

    private void recallMessage() {
        String messageIdStr = JOptionPane.showInputDialog(this, "Nhập mã tin nhắn để thu hồi:");
        if (messageIdStr != null && !messageIdStr.trim().isEmpty()) {
            try {
                int messageId = Integer.parseInt(messageIdStr);
                String recallCommand = "RECALL " + messageId;
                byte[] buffer = recallCommand.getBytes();
                DatagramPacket packet = new DatagramPacket(buffer, buffer.length, serverAddress, serverPort);
                socket.send(packet);
                serverLogArea.append("Message edited: " + packet + "\n");
            } catch (NumberFormatException | IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(ServerUDPChat::new);
    }
}
