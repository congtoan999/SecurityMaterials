package Chat;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JLabel;

public class mains {
    public static void main(String[] args) {
        // Tạo frame
        JFrame frame = new JFrame("Chat Application");
        frame.setSize(400, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // Tạo panel và sử dụng GridBagLayout
        JPanel panel = new JPanel(new GridBagLayout());
        
        // Thêm panel vào frame
        frame.getContentPane().add(panel);
        
        JButton btnNewButton = new JButton("TCP");
        btnNewButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        	}
        });
        
        JButton btnNewButton_2 = new JButton("Main Menu");
        GridBagConstraints gbc_btnNewButton_2 = new GridBagConstraints();
        gbc_btnNewButton_2.insets = new Insets(0, 0, 5, 5);
        gbc_btnNewButton_2.gridx = 2;
        gbc_btnNewButton_2.gridy = 0;
        panel.add(btnNewButton_2, gbc_btnNewButton_2);
        GridBagConstraints gbc_btnNewButton = new GridBagConstraints();
        gbc_btnNewButton.insets = new Insets(0, 0, 5, 5);
        gbc_btnNewButton.gridx = 1;
        gbc_btnNewButton.gridy = 1;
        panel.add(btnNewButton, gbc_btnNewButton);
        
        JButton btnNewButton_1 = new JButton("UDP");
        GridBagConstraints gbc_btnNewButton_1 = new GridBagConstraints();
        gbc_btnNewButton_1.insets = new Insets(0, 0, 5, 0);
        gbc_btnNewButton_1.gridx = 3;
        gbc_btnNewButton_1.gridy = 1;
        panel.add(btnNewButton_1, gbc_btnNewButton_1);
        
        // Tạo constraints mới cho ClientUDPChat
        GridBagConstraints gbc2 = new GridBagConstraints(); // Tạo constraints mới
        gbc2.insets = new Insets(5, 5, 5, 0);
        gbc2.fill = GridBagConstraints.HORIZONTAL;
        
        // Tạo nút cho ClientUDPChat
        JButton clientUDPButton = new JButton("Client UDP");
        clientUDPButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Khi nút được nhấn, mở cửa sổ ClientUDPChat
                new ClientUDPChat();
            }
        });
        
        // Tạo constraints cho các button
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // Tạo nút cho ClientTCPChat
        JButton clientTCPButton = new JButton("Client TCP");
        clientTCPButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Khi nút được nhấn, mở cửa sổ ClientTCPChat
                new ClientTCPChat();
            }
        });
        gbc.gridx = 1;
        gbc.gridy = 2;
        panel.add(clientTCPButton, gbc);
        gbc2.gridx = 3;
        gbc2.gridy = 2;
        panel.add(clientUDPButton, gbc2);
        
        // Tạo constraints mới cho ServerUDPChat
        GridBagConstraints gbc4 = new GridBagConstraints(); // Tạo constraints mới
        gbc4.anchor = GridBagConstraints.NORTH;
        gbc4.insets = new Insets(5, 5, 5, 0);
        gbc4.fill = GridBagConstraints.HORIZONTAL;
        
        // Tạo nút cho ServerUDPChat
        JButton serverUDPButton = new JButton("Server UDP");
        serverUDPButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Khi nút được nhấn, mở cửa sổ ServerUDPChat
                new ServerUDPChat();
            }
        });
        
        // Tạo constraints mới cho ServerTCPChat
        GridBagConstraints gbc3 = new GridBagConstraints(); // Tạo constraints mới
        gbc3.anchor = GridBagConstraints.NORTH;
        gbc3.insets = new Insets(5, 5, 5, 5);
        gbc3.fill = GridBagConstraints.HORIZONTAL;
        
        // Tạo nút cho ServerTCPChat
        JButton serverTCPButton = new JButton("Server TCP");
        serverTCPButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Khi nút được nhấn, mở cửa sổ ServerTCPChat
                new ServerTCPChat();
            }
        });
        gbc3.gridx = 1;
        gbc3.gridy = 3;
        panel.add(serverTCPButton, gbc3);
        gbc4.gridx = 3;
        gbc4.gridy = 3;
        panel.add(serverUDPButton, gbc4);
        
        JLabel lblNewLabel_1 = new JLabel("52200271-DoThanhTu");
        GridBagConstraints gbc_lblNewLabel_1 = new GridBagConstraints();
        gbc_lblNewLabel_1.insets = new Insets(0, 0, 5, 5);
        gbc_lblNewLabel_1.gridx = 2;
        gbc_lblNewLabel_1.gridy = 4;
        panel.add(lblNewLabel_1, gbc_lblNewLabel_1);
        
        JLabel lblNewLabel = new JLabel("52200271-NguyenCongToan");
        GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
        gbc_lblNewLabel.anchor = GridBagConstraints.EAST;
        gbc_lblNewLabel.insets = new Insets(0, 0, 0, 5);
        gbc_lblNewLabel.gridx = 2;
        gbc_lblNewLabel.gridy = 5;
        panel.add(lblNewLabel, gbc_lblNewLabel);
        
        // Hiển thị frame
        frame.setVisible(true);
    }
}
