package Chat;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.nio.file.Files;
import java.util.List;

public class ClientTCPChat extends JFrame {
    private JTextArea messageArea;
    private JTextField senderNameField;
    private JTextField subjectField;
    private JTextArea messageField;
    private JButton sendButton;
    private JButton attachFileButton;
    private JButton recallButton;
    private JButton editButton;
    private PrintWriter out;
    private BufferedReader in;
    private Map<Integer, String> sentMessages; // Map to store sent messages with their IDs
    private int messageIdCounter; // Counter for generating unique message IDs

    private JList<String> groupList;
    private DefaultListModel<String> groupListModel;
    private JButton createGroupButton;

    public ClientTCPChat() {
        setTitle("TCP Chat Room Client");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 700);

        setLayout(new BorderLayout(10, 10));

        JPanel headerPanel = new JPanel();
        headerPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
        headerPanel.setLayout(new BorderLayout());
        JLabel headerLabel = new JLabel("TCP Chat Room Client", JLabel.CENTER);
        headerLabel.setFont(new Font("Arial", Font.BOLD, 18));
        headerPanel.add(headerLabel, BorderLayout.CENTER);
        add(headerPanel, BorderLayout.NORTH);

        messageArea = new JTextArea();
        messageArea.setEditable(false);
        messageArea.setFont(new Font("Monospaced", Font.PLAIN, 14));
        JScrollPane messageScrollPane = new JScrollPane(messageArea);
        add(messageScrollPane, BorderLayout.CENTER);

        JPanel inputPanel = new JPanel();
        inputPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
        inputPanel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0;
        gbc.gridy = 0;
        inputPanel.add(new JLabel("Họ tên:"), gbc);
        senderNameField = new JTextField(20);
        gbc.gridx = 1;
        gbc.gridy = 0;
        inputPanel.add(senderNameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        inputPanel.add(new JLabel("Tiêu đề:"), gbc);
        subjectField = new JTextField(20);
        gbc.gridx = 1;
        gbc.gridy = 1;
        inputPanel.add(subjectField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        inputPanel.add(new JLabel("Nội dung:"), gbc);
        messageField = new JTextArea(5, 20);
        JScrollPane messageInputScrollPane = new JScrollPane(messageField);
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        inputPanel.add(messageInputScrollPane, gbc);

        attachFileButton = new JButton("Đính kèm file");
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.CENTER;
        inputPanel.add(attachFileButton, gbc);

        sendButton = new JButton("Gửi");
        gbc.gridx = 1;
        gbc.gridy = 4;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.CENTER;
        inputPanel.add(sendButton, gbc);

        recallButton = new JButton("Thu hồi tin nhắn");
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.CENTER;
        inputPanel.add(recallButton, gbc);

        editButton = new JButton("Chỉnh sửa tin nhắn");
        gbc.gridx = 1;
        gbc.gridy = 5;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.CENTER;
        inputPanel.add(editButton, gbc);

        groupListModel = new DefaultListModel<>();
        groupList = new JList<>(groupListModel);
        groupList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        groupList.setLayoutOrientation(JList.VERTICAL);
        JScrollPane groupScrollPane = new JScrollPane(groupList);
        groupScrollPane.setPreferredSize(new Dimension(200, 150));

        createGroupButton = new JButton("Create Group");
        createGroupButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                createGroup();
            }
        });

        gbc.gridx = 0;
        gbc.gridy = 6;
        inputPanel.add(new JLabel("Groups:"), gbc);
        gbc.gridx = 1;
        gbc.gridy = 6;
        inputPanel.add(groupScrollPane, gbc);
        gbc.gridx = 1;
        gbc.gridy = 7;
        inputPanel.add(createGroupButton, gbc);

        attachFileButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                attachFile();
            }
        });
        sendButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                sendMessage();
            }
        });
        recallButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                recallMessage();
            }
        });
        editButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                editMessage();
            }
        });

        add(inputPanel, BorderLayout.SOUTH);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                if (out != null) {
                    out.println("Client disconnected");
                    out.close();
                }
            }
        });

        sentMessages = new HashMap<>();
        messageIdCounter = 0;

        setVisible(true);

        connectToServer();
    }
    private void connectToServer() {
        new Thread(new Runnable() {
            public void run() {
                try {
                    Socket socket = new Socket("localhost", 32340);
                    out = new PrintWriter(socket.getOutputStream(), true);
                    in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

                    new Thread(new IncomingMessageHandler()).start();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        }).start();
    }

    private void sendMessage() {
        String senderName = senderNameField.getText();
        String subject = subjectField.getText();
        String message = messageField.getText();
        if (!senderName.trim().isEmpty() && !subject.trim().isEmpty() && !message.trim().isEmpty()) {
            int messageId = ++messageIdCounter;
            String fullMessage = messageId + ": " + senderName + ": " + subject + " - " + message;
            out.println(fullMessage);
            sentMessages.put(messageId, fullMessage);
            messageField.setText("");
        }
    }

    private void recallMessage() {
        String messageIdStr = JOptionPane.showInputDialog(this, "Enter the message ID to recall:");
        if (messageIdStr != null && !messageIdStr.trim().isEmpty()) {
            try {
                int messageId = Integer.parseInt(messageIdStr);
                if (sentMessages.containsKey(messageId)) {
                    out.println("RECALL " + messageId);
                    sentMessages.remove(messageId);
                } else {
                    JOptionPane.showMessageDialog(this, "Message ID not found.");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Invalid message ID format.");
            }
        }
    }

    private void editMessage() {
        String messageIdStr = JOptionPane.showInputDialog(this, "Enter the message ID to edit:");
        if (messageIdStr != null && !messageIdStr.trim().isEmpty()) {
            String newMessage = JOptionPane.showInputDialog(this, "Enter the new message:");
            if (newMessage != null && !newMessage.trim().isEmpty()) {
                try {
                    int messageId = Integer.parseInt(messageIdStr);
                    if (sentMessages.containsKey(messageId)) {
                        String oldMessage = sentMessages.get(messageId);
                        String[] parts = oldMessage.split(": ", 3);
                        String senderName = parts[1].split(":")[0];
                        String subject = parts[2].split(" - ")[0];
                        String updatedMessage = messageId + ": " + senderName + ": " + subject + " - " + newMessage;
                        out.println("EDIT " + messageId + " " + updatedMessage);
                        sentMessages.put(messageId, updatedMessage);
                    } else {
                        JOptionPane.showMessageDialog(this, "Message ID not found.");
                    }
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(this, "Invalid message ID format.");
                }
            }
        }
    }
    private void createGroup() {
        String groupName = JOptionPane.showInputDialog(this, "Enter the group name:");
        if (groupName != null && !groupName.trim().isEmpty()) {
            out.println("CREATE_GROUP " + groupName);
            groupListModel.addElement(groupName);
        }
    }



    private void attachFile() {
        JFileChooser fileChooser = new JFileChooser();
        int returnValue = fileChooser.showOpenDialog(this);
        if (returnValue == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            try {
                byte[] fileBytes = Files.readAllBytes(selectedFile.toPath());
                String fileContent = Base64.getEncoder().encodeToString(fileBytes);

                // Thêm thông tin về tệp đính kèm vào dữ liệu gửi đi
                out.println("FILE");
                out.println(selectedFile.getName()); // Tên tệp
                out.println("from: "+senderNameField.getText()); // Tên người gửi
                out.println("subjectField: "+subjectField.getText()); // Tiêu đề tin nhắn
                out.println("fileContent: "+fileContent); // Dữ liệu của tệp

                // Hiển thị thông tin về tệp đính kèm trên giao diện của client
                messageArea.append("File attached sent: " + selectedFile.getName() + "\n");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    private class IncomingMessageHandler implements Runnable {
        @Override
        public void run() {
            try {
                String message;
                while ((message = in.readLine()) != null) {
                    if ("FILE".equals(message)) {
                        String fileName = in.readLine();
                        String fileSender = in.readLine(); // Người gửi tệp
                        String fileSubject = in.readLine(); // Tiêu đề tin nhắn
                        String fileContent = in.readLine(); // Nội dung tệp (Base64)

                        // Hiển thị thông báo trên giao diện của client
                        SwingUtilities.invokeLater(() -> {
//                            messageArea.append("Received file: " + fileName + " from: " + fileSender + " - " + fileSubject + "\n");
                        });

                        // Giải mã nội dung tệp từ Base64
                        byte[] fileBytes = Base64.getDecoder().decode(fileContent);

                        // Lưu tệp vào ổ đĩa
                        File receivedFile = new File(fileName);
                        try (FileOutputStream fos = new FileOutputStream(receivedFile)) {
                            fos.write(fileBytes);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    } else if (message.startsWith("RECALL")) {
                        String[] parts = message.split(" ", 2);
                        int messageId = Integer.parseInt(parts[1]);
                        sentMessages.remove(messageId);
                        messageArea.append("Message " + messageId + " has been recalled.\n");
                    } else if (message.startsWith("EDIT")) {
                        String[] parts = message.split(" ", 3);
                        int messageId = Integer.parseInt(parts[1]);
                        String newContent = parts[2];
                        sentMessages.put(messageId, newContent);
                        messageArea.append("Message " + messageId + " has been edited to: " + newContent + "\n");
                    } else {
                        messageArea.append(message + "\n");
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(ClientTCPChat::new);
    }
}