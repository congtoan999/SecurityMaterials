package Chat;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.List;

public class ServerTCPChat extends JFrame {
    private static final int PORT = 32340;
    private static Set<PrintWriter> clientWriters = new HashSet<>();
    private JTextArea serverLogArea;
    private JTextField senderNameField;
    private JTextField subjectField;
    private JTextArea messageField;
    private JButton sendButton;
    private JButton attachFileButton;
    private JButton editButton;
    private JButton recallButton;

    private List<Message> messages = new ArrayList<>();
    private int messageIdCounter = 0;

    public ServerTCPChat() {
        setTitle("TCP Chat Room Server");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 600);
        setLayout(new BorderLayout(10, 10));

        buildUI();

        setVisible(true);

        startServer();
    }

    private void buildUI() {
        JPanel headerPanel = createHeaderPanel();
        add(headerPanel, BorderLayout.NORTH);

        serverLogArea = createServerLogArea();
        JScrollPane scrollPane = new JScrollPane(serverLogArea);
        add(scrollPane, BorderLayout.CENTER);

        JPanel inputPanel = createInputPanel();
        add(inputPanel, BorderLayout.SOUTH);
    }

    private JPanel createHeaderPanel() {
        JPanel headerPanel = new JPanel();
        headerPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
        headerPanel.setLayout(new BorderLayout());
        JLabel headerLabel = new JLabel("TCP Chat Room Server", JLabel.CENTER);
        headerLabel.setFont(new Font("Arial", Font.BOLD, 18));
        headerPanel.add(headerLabel, BorderLayout.CENTER);
        return headerPanel;
    }

    private JTextArea createServerLogArea() {
        JTextArea serverLogArea = new JTextArea();
        serverLogArea.setEditable(false);
        serverLogArea.setFont(new Font("Monospaced", Font.PLAIN, 14));
        return serverLogArea;
    }

    private JPanel createInputPanel() {
        JPanel inputPanel = new JPanel();
        inputPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
        inputPanel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0;
        gbc.gridy = 0;
        inputPanel.add(new JLabel("Họ tên:"), gbc);
        senderNameField = new JTextField(20);
        gbc.gridx = 1;
        inputPanel.add(senderNameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        inputPanel.add(new JLabel("Tiêu đề:"), gbc);
        subjectField = new JTextField(20);
        gbc.gridx = 1;
        inputPanel.add(subjectField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 1;
        inputPanel.add(new JLabel("Nội dung:"), gbc);
        messageField = new JTextArea(5, 20);
        JScrollPane messageInputScrollPane = new JScrollPane(messageField);
        gbc.gridx = 1;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        inputPanel.add(messageInputScrollPane, gbc);

        attachFileButton = new JButton("Đính kèm file");
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.CENTER;
        inputPanel.add(attachFileButton, gbc);

        sendButton = new JButton("Gửi");
        gbc.gridx = 1;
        gbc.gridy = 3;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.CENTER;
        inputPanel.add(sendButton, gbc);

        recallButton = new JButton("Thu hồi tin nhắn");
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.CENTER;
        inputPanel.add(recallButton, gbc);

        editButton = new JButton("Chỉnh sửa tin nhắn");
        gbc.gridx = 1;
        gbc.gridy = 4;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.CENTER;
        inputPanel.add(editButton, gbc);

        attachFileButton.addActionListener(e -> attachFile());
        sendButton.addActionListener(e -> sendMessage());
        recallButton.addActionListener(e -> recallMessage());
        editButton.addActionListener(e -> editMessage());

        return inputPanel;
    }

    private void startServer() {
        new Thread(() -> {
            try (ServerSocket serverSocket = new ServerSocket(PORT)) {
                serverLogArea.append("server is running...\n");
                while (true) {
                    new ClientHandler(serverSocket.accept()).start();
                }
            } catch (IOException e) {
                e.printStackTrace();
                serverLogArea.append("Error starting the server: " + e.getMessage() + "\n");
            }
        }).start();
    }

    private class ClientHandler extends Thread {
        private Socket socket;
        private PrintWriter out;
        private BufferedReader in;

        public ClientHandler(Socket socket) {
            this.socket = socket;
        }

        @Override
        public void run() {
            try {
                in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                out = new PrintWriter(socket.getOutputStream(), true);

                synchronized (clientWriters) {
                    clientWriters.add(out);
                }

                String message;
                while ((message = in.readLine()) != null) {
                    serverLogArea.append("Received: " + message + "\n");
                    broadcastMessage(message);
                }
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (out != null) {
                    synchronized (clientWriters) {
                        clientWriters.remove(out);
                    }
                }
                try {
                    socket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        private void broadcastMessage(String message) {
            synchronized (clientWriters) {
                for (PrintWriter writer : clientWriters) {
                    writer.println(message);
                }
            }
        }
    }

    private void sendMessage() {
        String senderName = senderNameField.getText();
        String subject = subjectField.getText();
        String message = messageField.getText();
        if (!senderName.trim().isEmpty() && !subject.trim().isEmpty() && !message.trim().isEmpty()) {
            String fullMessage = "Server: " + senderName + " Title: " + subject + "\n" + message;
            int messageId = messageIdCounter++;
            Message newMessage = new Message(messageId, fullMessage);
            messages.add(newMessage);
            synchronized (clientWriters) {
                for (PrintWriter writer : clientWriters) {
                    writer.println(newMessage);
                }
            }
            serverLogArea.append("Sent: " + newMessage + "\n");
            messageField.setText("");
        }
    }

    private void attachFile() {
        JFileChooser fileChooser = new JFileChooser();
        int returnValue = fileChooser.showOpenDialog(this);
        if (returnValue == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            String fileName = selectedFile.getName();
            serverLogArea.append("File attached sent: " + fileName + "\n");
        }
    }
    private void handleMessage(String message) {
        if (message.startsWith("EDIT")) {
            editMessage(message);
        } else if (message.startsWith("RECALL")) {
            recallMessage(message);
        } else {
            broadcastMessage(message);
        }
    }

    private void editMessage() {
        String messageIdStr = JOptionPane.showInputDialog(this, "Enter the ID of the message to edit:");
        if (messageIdStr != null) {
            try {
                int messageId = Integer.parseInt(messageIdStr);
                for (Message message : messages) {
                    if (message.getId() == messageId) {
                        String newMessageContent = JOptionPane.showInputDialog(this, "Edit your message:", message.getContent());
                        if (newMessageContent != null) {
                            message.setContent(newMessageContent);
                            broadcastMessage("Edited message: " + message);
                            serverLogArea.append("Message edited: " + message + "\n");
                        }
                        return;
                    }
                }
                JOptionPane.showMessageDialog(this, "Message ID not found.");
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Invalid message ID.");
            }
        }
    }

    private void recallMessage() {
        String messageIdStr = JOptionPane.showInputDialog(this, "Enter the ID of the message to recall:");
        if (messageIdStr != null) {
            try {
                int messageId = Integer.parseInt(messageIdStr);
                Iterator<Message> iterator = messages.iterator();
                while (iterator.hasNext()) {
                    Message message = iterator.next();
                    if (message.getId() == messageId) {
                        iterator.remove();
                        broadcastMessage("Recalled message: " + messageId);
                        serverLogArea.append("Message recalled: " + messageId + "\n");
                        return;
                    }
                }
                JOptionPane.showMessageDialog(this, "Message ID not found.");
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Invalid message ID.");
            }
        }
    }
    private void attachFile() {
        JFileChooser fileChooser = new JFileChooser();
        int returnValue = fileChooser.showOpenDialog(this);
        if (returnValue == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            try {
                byte[] fileBytes = Files.readAllBytes(selectedFile.toPath());
                String fileContent = Base64.getEncoder().encodeToString(fileBytes);

                // Gửi tin nhắn đính kèm tệp cho tất cả client
                synchronized (clientWriters) {
                    for (PrintWriter writer : clientWriters) {
                        writer.println("FILE");
                        writer.println(selectedFile.getName()); // Tên tệp
                        writer.println(senderNameField.getText()); // Tên người gửi
                        writer.println(subjectField.getText()); // Tiêu đề tin nhắn
                        writer.println(fileContent); // Dữ liệu của tệp
                    }
                }

                serverLogArea.append("File attached and sent to all clients: " + selectedFile.getName() + "\n");
            } catch (IOException e) {
                e.printStackTrace();
                serverLogArea.append("Error attaching and sending file: " + e.getMessage() + "\n");
            }
        }
    }



    private void broadcastMessage(String message) {
        synchronized (clientWriters) {
            for (PrintWriter writer : clientWriters) {
                writer.println(message);
            }
        }
    }

    private class Message {
        private int id;
        private String content;

        public Message(int id, String content) {
            this.id = id;
            this.content = content;
        }

        public int getId() {
            return id;
        }

        public String getContent() {
            return content;
        }

        public void setContent(String content) {
            this.content = content;
        }

        @Override
        public String toString() {
            return id + ": " + content;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(ServerTCPChat::new);
    }
}
