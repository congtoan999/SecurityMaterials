package Chat;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.nio.file.Files;
import java.util.*;


public class ClientUDPChat extends JFrame {
    private JTextArea messageArea;
    private JTextField senderNameField;
    private JTextField subjectField;
    private JTextArea messageField;
    private JButton sendButton;
    private JButton attachFileButton;
    private JButton recallButton;
    private JButton editButton;
    private DatagramSocket socket;
    private InetAddress serverAddress;
    private int serverPort;
    private int messageId = 1;
    private DefaultListModel<String> groupListModel;
    private JList<String> groupList;
    private JButton createGroupButton;	

    public ClientUDPChat() {
        setTitle("UDP Chat Room Client");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 700);

        setLayout(new BorderLayout(10, 10));

        JPanel headerPanel = new JPanel();
        headerPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
        headerPanel.setLayout(new BorderLayout());
        JLabel headerLabel = new JLabel("UDP Chat Room Client", JLabel.CENTER);
        headerLabel.setFont(new Font("Arial", Font.BOLD, 18));
        headerPanel.add(headerLabel, BorderLayout.CENTER);
        add(headerPanel, BorderLayout.NORTH);

        messageArea = new JTextArea();
        messageArea.setEditable(false);
        messageArea.setFont(new Font("Monospaced", Font.PLAIN, 14));
        JScrollPane messageScrollPane = new JScrollPane(messageArea);
        add(messageScrollPane, BorderLayout.CENTER);

        JPanel inputPanel = new JPanel();
        inputPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
        inputPanel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0;
        gbc.gridy = 0;
        inputPanel.add(new JLabel("Họ tên:"), gbc);
        senderNameField = new JTextField(20);
        gbc.gridx = 1;
        gbc.gridy = 0;
        inputPanel.add(senderNameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        inputPanel.add(new JLabel("Tiêu đề:"), gbc);
        subjectField = new JTextField(20);
        gbc.gridx = 1;
        gbc.gridy = 1;
        inputPanel.add(subjectField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        inputPanel.add(new JLabel("Nội dung:"), gbc);
        messageField = new JTextArea(5, 20);
        JScrollPane messageInputScrollPane = new JScrollPane(messageField);
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        inputPanel.add(messageInputScrollPane, gbc);

        attachFileButton = new JButton("Đính kèm file");
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.CENTER;
        inputPanel.add(attachFileButton, gbc);

        sendButton = new JButton("Gửi");
        gbc.gridx = 1;
        gbc.gridy = 4;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.CENTER;
        inputPanel.add(sendButton, gbc);

        recallButton = new JButton("Thu hồi tin nhắn");
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.CENTER;
        inputPanel.add(recallButton, gbc);

        editButton = new JButton("Chỉnh sửa tin nhắn");
        gbc.gridx = 1;
        gbc.gridy = 5;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.CENTER;
        inputPanel.add(editButton, gbc);

        groupListModel = new DefaultListModel<>();
        groupList = new JList<>(groupListModel);
        groupList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        groupList.setLayoutOrientation(JList.VERTICAL);
        JScrollPane groupScrollPane = new JScrollPane(groupList);
        groupScrollPane.setPreferredSize(new Dimension(200, 150));

        createGroupButton = new JButton("Create Group");
        createGroupButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                createGroup();
            }
        });

        gbc.gridx = 0;
        gbc.gridy = 6;
        inputPanel.add(new JLabel("Groups:"), gbc);
        gbc.gridx = 1;
        gbc.gridy = 6;
        inputPanel.add(groupScrollPane, gbc);
        gbc.gridx = 1;
        gbc.gridy = 7;
        inputPanel.add(createGroupButton, gbc);

        attachFileButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                attachFile();
            }
        });
        sendButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                sendMessage();
            }
        });
        recallButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                recallMessage();
            }
        });
        editButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                editMessage();
            }
        });

        add(inputPanel, BorderLayout.SOUTH);

        setVisible(true);

        connectToServer();
        startListening();
    }


    private void connectToServer() {
        try {
            socket = new DatagramSocket();
            serverAddress = InetAddress.getByName("localhost");
            serverPort = 42349;
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    private void sendMessage() {
        String senderName = senderNameField.getText();
        String subject = subjectField.getText();
        String message = messageField.getText();
        if (!senderName.trim().isEmpty() && !subject.trim().isEmpty() && !message.trim().isEmpty()) {
            // Tạo tin nhắn với messageID
            String fullMessage = "MessageID " + messageId + ": " + senderName + ": " + subject + " - " + message;
            byte[] sendData = fullMessage.getBytes();
            DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, serverAddress, serverPort);
            try {
                socket.send(sendPacket);
                messageField.setText("");
                // Tăng messageID sau mỗi lần gửi tin nhắn
                messageId++;
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    private void attachFile() {
        JFileChooser fileChooser = new JFileChooser();
        int returnValue = fileChooser.showOpenDialog(this);
        if (returnValue == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            try {
                byte[] fileBytes = Files.readAllBytes(selectedFile.toPath());
                String fileContent = Base64.getEncoder().encodeToString(fileBytes);

                String fileName = selectedFile.getName();
                String senderName = senderNameField.getText();
                String subject = subjectField.getText();

                String fileMessage = "FILE\n" + fileName + "\n" + senderName + "\n" + subject + "\n" + fileContent;
                byte[] sendData = fileMessage.getBytes();
                DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, serverAddress, serverPort);
                socket.send(sendPacket);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void recallMessage() {
        String messageIdStr = JOptionPane.showInputDialog(this, "Nhập mã tin nhắn để thu hồi:");
        if (messageIdStr != null && !messageIdStr.trim().isEmpty()) {
            try {
                int messageId = Integer.parseInt(messageIdStr);
                String recallCommand = "Đã xóa tin nhắn " + messageId;
                byte[] buffer = recallCommand.getBytes();
                // Gửi gói tin recallCommand đến tất cả các client
                broadcastMessage(recallCommand, socket);
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }
    }

    private void editMessage() {
        String messageIdStr = JOptionPane.showInputDialog(this, "Nhập mã tin nhắn để chỉnh sửa:");
        if (messageIdStr != null && !messageIdStr.trim().isEmpty()) {
            String newMessage = JOptionPane.showInputDialog(this, "Nhập nội dung mới:");
            if (newMessage != null && !newMessage.trim().isEmpty()) {
                try {
                    int messageId = Integer.parseInt(messageIdStr);
                    String editCommand = "EDIT " + messageId + " " + newMessage;
                    byte[] buffer = editCommand.getBytes();
                    // Gửi gói tin editCommand đến tất cả các client
                    broadcastMessage(editCommand, socket);
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private void startListening() {
        new Thread(() -> {
            try {
                while (true) {
                    byte[] receiveData = new byte[1024];
                    DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
                    socket.receive(receivePacket);

                    String receivedMessage = new String(receivePacket.getData(), 0, receivePacket.getLength());
                    messageArea.append(receivedMessage + "\n");
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }).start();
    }
    private void createGroup() {
        String groupName = JOptionPane.showInputDialog(this, "Enter group name:");
        if (groupName != null && !groupName.trim().isEmpty()) {
            // Add the new group to the list
            groupListModel.addElement(groupName);
            // Additional logic to send the group creation message to the server
            // For example, you can send a message indicating the creation of a new group
            // and include the group name and any necessary information.
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(ClientUDPChat::new);
    }
}