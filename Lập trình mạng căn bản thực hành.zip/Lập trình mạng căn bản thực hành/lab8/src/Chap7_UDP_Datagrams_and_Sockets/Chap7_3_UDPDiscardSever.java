package Chap7_UDP_Datagrams_and_Sockets;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;

public class Chap7_3_UDPDiscardSever extends JFrame {
	private JPanel contentPane;
	private JTextField PortNo;
	private JTextField MaxPacketSize;
	private JTextArea textArea;
	private InetAddress server;
	private DatagramSocket theSocket;
	private int portNo;
	private int maxSize;

	/**
	* Launch the application.
	*/
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Chap7_3_UDPDiscardSever frame = new Chap7_3_UDPDiscardSever();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	/**
	* Create the frame.
	*/
	public Chap7_3_UDPDiscardSever() {
		setTitle("A UDP discard Server");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 579, 445);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		PortNo = new JTextField();
		PortNo.setText("2020");
		PortNo.setFont(new Font("Times New Roman", Font.BOLD, 20));
		PortNo.setBounds(122, 34, 129, 32);
		contentPane.add(PortNo);
		PortNo.setColumns(10);
		JLabel lblNewLabel = new JLabel("PortNo:");
		
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblNewLabel.setBounds(33, 34, 77, 32);
		contentPane.add(lblNewLabel);
		JLabel lblPortno = new JLabel("Max Packet Size:");
		lblPortno.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblPortno.setBounds(263, 34, 150, 32);
		contentPane.add(lblPortno);
		MaxPacketSize = new JTextField();
		MaxPacketSize.setText("56507");
		MaxPacketSize.setFont(new Font("Times New Roman", Font.BOLD, 20));
		MaxPacketSize.setColumns(10);
		MaxPacketSize.setBounds(416, 34, 85, 32);
		contentPane.add(MaxPacketSize);
		textArea = new JTextArea();
		textArea.setFont(new Font("Times New Roman", Font.BOLD, 20));
		textArea.setBounds(77, 151, 444, 223);
		contentPane.add(textArea);
		JScrollPane scrollPane = new JScrollPane(textArea);
		
		scrollPane.setBounds(77, 151, 444, 223);
		contentPane.add(scrollPane);
		
		JButton btnNewButton = new JButton("Click Me!");
		btnNewButton.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			portNo = Integer.parseInt(PortNo.getText());
			maxSize = Integer.parseInt(MaxPacketSize.getText());
			byte[] buffer = new byte[maxSize];
			try {
				DatagramSocket server = new DatagramSocket(portNo);
				DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
				Component fame = null;
				JOptionPane.showMessageDialog(fame, "Ready to reveive datat"," UDP Protocal",JOptionPane.WARNING_MESSAGE);
				String message ="";
				while(!message.equals("exit")) {
					server.receive(packet);
					message = new String(packet.getData(), 0,packet.getLength( ), "UTF-8");
					textArea.setText(textArea.getText().trim()+"\n" +packet.getAddress( ) + " at port " + packet.getPort( ) +" say: "+message);
					JOptionPane.showMessageDialog(fame, "New data is received");
				}
			} catch (SocketException e1) {
		
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
				}
			}
			//}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 24));
		btnNewButton.setBounds(241, 93, 142, 32);
		contentPane.add(btnNewButton);
	}
}