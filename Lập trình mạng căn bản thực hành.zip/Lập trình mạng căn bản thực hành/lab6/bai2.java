package lab6;

import java.net.Socket;

public class bai2 {
    public static void main(String[] args) {
        String host = "example.com"; // Thay đổi thành địa chỉ IP hoặc tên miền của máy chủ bạn muốn kiểm tra
        int startPort = 1025;
        int endPort = 65536;

        for (int port = startPort; port <= endPort; port++) {
            try {
                Socket socket = new Socket(host, port);
                System.out.println("Port " + port + " is open");
                socket.close();
            } catch (Exception e) {
                // Port is closed or not responding
            }
        }
    }
}

