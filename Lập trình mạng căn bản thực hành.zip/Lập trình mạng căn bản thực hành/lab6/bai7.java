package lab6;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import org.apache.commons.net.whois.WhoisClient;

public class bai7 {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Command-line Whois Client");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 200);

        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());

        JLabel label = new JLabel("Enter domain:");
        JTextField domainField = new JTextField();
        JButton queryButton = new JButton("Query");

        JTextArea resultArea = new JTextArea();
        resultArea.setEditable(false);

        queryButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String domain = domainField.getText();
                try {
                    WhoisClient whois = new WhoisClient();
                    whois.connect(WhoisClient.DEFAULT_HOST);
                    String whoisResult = whois.query(domain);
                    whois.disconnect();
                    resultArea.setText(whoisResult);
                } catch (IOException ex) {
                    resultArea.setText("Error querying WHOIS for " + domain);
                }
            }
        });

        panel.add(label, BorderLayout.NORTH);
        panel.add(domainField, BorderLayout.CENTER);
        panel.add(queryButton, BorderLayout.SOUTH);

        frame.add(panel, BorderLayout.NORTH);
        frame.add(new JScrollPane(resultArea), BorderLayout.CENTER);

        frame.setVisible(true);
    }
}
