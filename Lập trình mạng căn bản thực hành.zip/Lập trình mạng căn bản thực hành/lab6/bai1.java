package lab6;

public class bai1 {

}
