package lab6;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;

public class bai6 {
    public static void main(String[] args) {
        try {
            Socket http = new Socket("www.oreilly.com", 80);
            OutputStream raw = http.getOutputStream();
            OutputStream buffered = new BufferedOutputStream(raw);
            out = new OutputStreamWriter(buffered, "ASCII");
            out.write("GET / HTTP 1.0\r\n\r\n");
            // Đọc phản hồi từ máy chủ...
        } catch (Exception ex) {
            System.err.println(ex);
        } finally {
            try {
                out.close();
            } catch (Exception ex) {
                // Xử lý ngoại lệ khi đóng luồng
            }
        }
    }
}
