package lab6;

import java.io.IOException;
import java.net.*;

public class bai3 {
    public static void main(String[] args) throws IOException {
        // Tạo một socket
        Socket socket = new Socket();

        // Ràng buộc socket với một địa chỉ cục bộ và số hiệu cổng
        InetAddress inetAddress = InetAddress.getByName(null);
        int port = 1085; // Số hiệu cổng cần ràng buộc (lớn hơn hoặc bằng 0)
        SocketAddress socketAddress = new InetSocketAddress(inetAddress, port);
        socket.bind(socketAddress);

        // Lấy số hiệu cổng cục bộ của socket
        int localPort = socket.getLocalPort();
        System.out.println("Số hiệu cổng: " + localPort);
    }
}
