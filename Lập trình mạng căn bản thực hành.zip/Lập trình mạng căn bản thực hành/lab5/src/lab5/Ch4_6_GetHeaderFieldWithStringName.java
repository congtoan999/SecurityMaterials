package lab5;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.awt.event.ActionEvent;
public class Ch4_6_GetHeaderFieldWithStringName extends JFrame {
	private JPanel contentPane;
	private JTextField InputURL;
	/**
	* Launch the application.
	*/
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Ch4_6_GetHeaderFieldWithStringName frame = new Ch4_6_GetHeaderFieldWithStringName();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	/**
	* Create the frame.
	*/
	public Ch4_6_GetHeaderFieldWithStringName() {
		setTitle("Retrieving Arbitrary Header Fields");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 542, 383);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		InputURL = new JTextField();
		InputURL.setText("https://dantri.com.vn/the-gioi.htm");
		InputURL.setBounds(140, 25, 344, 33);
		contentPane.add(InputURL);
		InputURL.setColumns(10);
		JTextArea HeaderViewer = new JTextArea();
		HeaderViewer.setEditable(false);
		HeaderViewer.setFont(new Font("Times New Roman", Font.BOLD, 20));
		HeaderViewer.setBounds(36, 137, 451, 186);
		contentPane.add(HeaderViewer);
		
		JButton btnNewButton = new JButton("Click Me!");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String str = InputURL.getText();
				String heaterviewer="";
				try {
					URL u = new URL(str);
					java.net.URLConnection uc = u.openConnection( );
					heaterviewer += "* content-type: "+uc.getHeaderField("content-type") +"\n";
					heaterviewer += "* content-encoding: " + uc.getHeaderField("content-encoding") +"\n";
					heaterviewer += "* Date: " + uc.getHeaderField("date") +"\n";
					heaterviewer += "* Expires: " + uc.getHeaderField("expires")+"\n";
					heaterviewer += "* Content-length: " + uc.getHeaderField("Content-length")+"\n";
					HeaderViewer.setText(heaterviewer);
				} catch (MalformedURLException e) {
					HeaderViewer.setText("");
					Component fame = null;
					JOptionPane.showMessageDialog(fame, "Could not find URL: "+str,"MalformedURLException",JOptionPane.WARNING_MESSAGE);
				} catch (IOException e) {
					HeaderViewer.setText("");
					Component fame = null;
					JOptionPane.showMessageDialog(fame, "I/O devices disconnect","IOException",JOptionPane.WARNING_MESSAGE);
				}
			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnNewButton.setBounds(208, 77, 126, 36);
		contentPane.add(btnNewButton);
		JLabel lblNewLabel = new JLabel("Input URL:");
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblNewLabel.setBounds(30, 23, 104, 33);
		contentPane.add(lblNewLabel);
	}
}
