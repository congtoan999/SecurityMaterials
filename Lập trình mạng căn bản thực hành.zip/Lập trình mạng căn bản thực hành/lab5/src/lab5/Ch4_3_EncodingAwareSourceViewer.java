package lab5;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import sun.net.www.URLConnection;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.BufferedInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.net.MalformedURLException;
import java.net.URL;
import java.awt.event.ActionEvent;
public class Ch4_3_EncodingAwareSourceViewer extends JFrame {
	private JPanel contentPane;
	private JTextField InputURL;
	/**
	* Launch the application.
	*/
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Ch4_3_EncodingAwareSourceViewer frame = new Ch4_3_EncodingAwareSourceViewer();
	
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	/**
	* Create the frame.
	*/
	public Ch4_3_EncodingAwareSourceViewer() {
		setTitle(" Download a web page with the correct character set");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 683, 500);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		InputURL = new JTextField();
		InputURL.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		InputURL.setText("https://dantri.com.vn/the-gioi.htm");
		InputURL.setBounds(120, 35, 396, 30);
		contentPane.add(InputURL);
		InputURL.setColumns(10);
		JTextArea textArea = new JTextArea();
		textArea.setEditable(false);
		textArea.setBounds(1, 1, 542, 268);
		contentPane.add(textArea);
		JScrollPane scrollPane = new JScrollPane(textArea);
		scrollPane.setBounds(26, 170, 611, 270);
		contentPane.add(scrollPane);
		
		JLabel lblNewLabel = new JLabel("Input URL:");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel.setBounds(12, 34, 111, 30);
		contentPane.add(lblNewLabel);
		JButton btnNewButton = new JButton("Click Me!");
		btnNewButton.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent arg0) {
			String str = InputURL.getText();
			String getData="";
			try {
				// set default encoding
				String encoding = "ISO-8859-1";
				URL u = new URL(str);
				java.net.URLConnection uc = u.openConnection( );
				String contentType = uc.getContentType( );
				int encodingStart = contentType.indexOf("charset=");
				if (encodingStart != -1) {
					encoding = contentType.substring(encodingStart+8);
				}
				java.io.InputStream in = new BufferedInputStream(uc.getInputStream( ));
				Reader r = new InputStreamReader(in, encoding);
				int c;
				while ((c = r.read( )) != -1) {
					getData += (char) c;
				}
				textArea.setText(getData);
			} catch (MalformedURLException e) {
				textArea.setText("");
				Component fame = null;
				JOptionPane.showMessageDialog(fame, "Could not find the URL: "+str,"MalformedURLException",JOptionPane.WARNING_MESSAGE);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				textArea.setText("");
				Component fame = null;
				JOptionPane.showMessageDialog(fame, "I/O devices disconnect","IOException",JOptionPane.WARNING_MESSAGE);
			}
		
		}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnNewButton.setBounds(245, 105, 132, 39);
		contentPane.add(btnNewButton);
		JButton btnNewButton_1 = new JButton("Back");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Chap4 frame = new Chap4();
				frame.setVisible(true);
				dispose();
			}
			});
		btnNewButton_1.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnNewButton_1.setBounds(561, 31, 92, 36);
		contentPane.add(btnNewButton_1);
	}
}