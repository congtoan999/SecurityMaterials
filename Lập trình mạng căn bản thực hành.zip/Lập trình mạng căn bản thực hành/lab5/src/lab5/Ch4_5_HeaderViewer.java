package lab5;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import sun.net.www.URLConnection;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Date;
import java.awt.event.ActionEvent;

public class Ch4_5_HeaderViewer extends JFrame {
	private JPanel contentPane;
	private JTextField InputURL;
	/**
	* Launch the application.
	*/
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Ch4_5_HeaderViewer frame = new Ch4_5_HeaderViewer();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	/**
	* Create the frame.
	*/
	public Ch4_5_HeaderViewer() {
		setTitle("Return the header");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 661, 449);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		InputURL = new JTextField();
		InputURL.setText("https://dantri.com.vn/the-gioi.htm");
		InputURL.setFont(new Font("Tahoma", Font.PLAIN, 18));
		InputURL.setBounds(132, 36, 393, 33);
		contentPane.add(InputURL);
		InputURL.setColumns(10);
		JTextArea textArea = new JTextArea();
		textArea.setFont(new Font("Times New Roman", Font.BOLD, 20));
		textArea.setBounds(26, 179, 564, 205);
		contentPane.add(textArea);
		JScrollPane scrollPane = new JScrollPane(textArea);
		scrollPane.setBounds(26, 179, 564, 205);
		contentPane.add(scrollPane);
		
		JButton btnNewButton = new JButton("Click Me!");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String str = InputURL.getText();
				String headerViewer ="";
				try {
					textArea.setText("");
					URL u = new URL(str);
					java.net.URLConnection uc = u.openConnection( );
					headerViewer += "* Content-type: "+uc.getContentType() + "\n";
					headerViewer += "* Content-encoding: " + uc.getContentEncoding()+"\n";
					headerViewer += "* Date: " + new Date(uc.getDate( )) +"\n";
					headerViewer += "* Last modified: "+ new Date(uc.getLastModified( ))+"\n";
					headerViewer += "* Expiration date: " + new Date(uc.getExpiration( ))+"\n";
					headerViewer += "* Content-length: " + uc.getContentLength( )+"\n";
					//headerViewer += "* HeaderFieldDate: " +uc.getHeaderField("content-type");
					//headerViewer +="Six key of the header view:"+uc.getHeaderFieldKey(3);
		
					textArea.setText(headerViewer);
				} catch (MalformedURLException e) {
					textArea.setText("");
					Component fame = null;
					JOptionPane.showMessageDialog(fame, "Could not find URL: "+str,"MalformedURLException",JOptionPane.WARNING_MESSAGE);
				} catch (IOException e) {
					textArea.setText("");
					Component fame = null;
					JOptionPane.showMessageDialog(fame, "I/O devices disconnect","IOException",JOptionPane.WARNING_MESSAGE);
				}
			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnNewButton.setBounds(246, 99, 129, 44);
		contentPane.add(btnNewButton);
		JLabel lblNewLabel = new JLabel("Input URL:");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 19));
		lblNewLabel.setBounds(26, 34, 105, 35);
		contentPane.add(lblNewLabel);
		JButton btnNewButton_1 = new JButton("Back");
		btnNewButton_1.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			Chap4 frame = new Chap4();
			frame.setVisible(true);
			dispose();
			}
		});
		btnNewButton_1.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnNewButton_1.setBounds(537, 34, 92, 36);
		contentPane.add(btnNewButton_1);
	}
}
