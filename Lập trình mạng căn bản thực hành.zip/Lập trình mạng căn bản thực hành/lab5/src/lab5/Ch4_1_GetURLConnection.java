package lab5;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import sun.net.www.URLConnection;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import java.awt.Color;
import java.awt.SystemColor;
import javax.swing.UIManager;
public class Ch4_1_GetURLConnection extends JFrame {
private JPanel contentPane;
private JTextField textField;
/**
* Launch the application.
*/
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Ch4_1_GetURLConnection frame = new Ch4_1_GetURLConnection();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	/**
	* Create the frame.
	*/
	public Ch4_1_GetURLConnection() {
		setFont(new Font("Dialog", Font.PLAIN, 20));
		setTitle("M\u1EDF m\u1ED9t URLConnection");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 729, 309);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		textField = new JTextField();
		textField.setText("http://www.microsoft.com");
		textField.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		textField.setBounds(124, 42, 416, 22);
		contentPane.add(textField);
		textField.setColumns(10);
		JTextArea textArea = new JTextArea();
		textArea.setBackground(SystemColor.text);
		textArea.setFont(new Font("Monospaced", Font.PLAIN, 13));
		textArea.setEditable(false);
		textArea.setBounds(96, 163, 603, 22);
		contentPane.add(textArea);
		JLabel lblNewLabel = new JLabel("Input URL:");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel.setBounds(10, 35, 102, 36);
		contentPane.add(lblNewLabel);
		JButton btnNewButton = new JButton("Clieck Me!");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String getURL = textField.getText();
				try{
					URL u= new URL(getURL);
					try{
						//textArea.setText("");
						java.net.URLConnection uc= u.openConnection();
						textArea.setText(""+uc);
						Component fame = null;
						JOptionPane.showMessageDialog(fame, "successful connection","URLConnection",JOptionPane.WARNING_MESSAGE);
					}
					catch(IOException e){
						textArea.setText("");
						Component fame = null;
						JOptionPane.showMessageDialog(fame, "I/O devices disconnect","IOException",JOptionPane.WARNING_MESSAGE);	
					}
				}
				catch(MalformedURLException e){
					textArea.setText("");
					Component fame = null;
					JOptionPane.showMessageDialog(fame, "Could not find URL: "+getURL,"MalformedURLException",JOptionPane.WARNING_MESSAGE);
				}
			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 18));
		btnNewButton.setBounds(268, 88, 117, 36);
		contentPane.add(btnNewButton);
		JLabel lblResult = new JLabel("Result:");
		lblResult.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblResult.setBounds(22, 159, 74, 33);
		contentPane.add(lblResult);
	}
}
