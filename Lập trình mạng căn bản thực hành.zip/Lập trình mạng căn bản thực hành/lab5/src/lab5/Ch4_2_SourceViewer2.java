package lab5;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import org.omg.CORBA.portable.InputStream;
import sun.net.www.URLConnection;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.BufferedInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.net.MalformedURLException;
import java.net.URL;
import java.awt.event.ActionEvent;
import javax.swing.UIManager;
import javax.swing.border.CompoundBorder;
import java.awt.Color;
import javax.swing.border.LineBorder;
import java.awt.SystemColor;

public class Ch4_2_SourceViewer2 extends JFrame {
	private JPanel contentPane;
	private JTextField TFInputURL;
	private JLabel lblNewLabel;
	private JButton btnNewButton;
	/**
	* Launch the application.
	*/
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Ch4_2_SourceViewer2 frame = new Ch4_2_SourceViewer2();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	/**
	* Create the frame.
	*/
	public Ch4_2_SourceViewer2() {
		setTitle("Opening URLConnections");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 680, 534);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(0, 0, 0, 0));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		TFInputURL = new JTextField();
		TFInputURL.setText("https://dantri.com.vn/the-gioi.htm");
		TFInputURL.setBounds(120, 43, 413, 22);
		contentPane.add(TFInputURL);
		TFInputURL.setColumns(10);
		JTextArea TAResult = new JTextArea();
		TAResult.setToolTipText("");
		TAResult.setBackground(SystemColor.text);
		TAResult.setEditable(false);
		TAResult.setBounds(21, 162, 629, 312);
		contentPane.add(TAResult);
		JScrollPane scrollPane = new JScrollPane(TAResult);
		scrollPane.setBounds(21, 162, 629, 312);
		contentPane.add(scrollPane);
		
		lblNewLabel = new JLabel("Input URL:");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel.setBounds(21, 38, 87, 29);
		contentPane.add(lblNewLabel);
		btnNewButton = new JButton("Click Me!");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String str = TFInputURL.getText();
				String sourceViewer="";
				try {
					//Open the URLConnection for reading
					URL u = new URL(str);
					java.net.URLConnection uc = u.openConnection( );
					java.io.InputStream raw = uc.getInputStream( );
					BufferedInputStream buffer = new BufferedInputStream(raw);
					// chain the InputStream to a Reader
					Reader r = new InputStreamReader(buffer);
					int c;
					OutputStream os = new FileOutputStream("output.htm");
					while ((c = r.read( )) != -1) {
						sourceViewer +=(char) c;
						os.write((char) c);
					}
					os.close();
					TAResult.setText(sourceViewer);
				}catch (MalformedURLException ex) {
					TAResult.setText("");
					Component fame = null;
					JOptionPane.showMessageDialog(fame, "Could not find URL: "+str,"MalformedURLException",JOptionPane.WARNING_MESSAGE);
				}catch (IOException ex) {
					TAResult.setText("");
					Component fame = null;
					JOptionPane.showMessageDialog(fame, "I/O devices disconnect","IOException",JOptionPane.WARNING_MESSAGE);
				}
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnNewButton.setBounds(237, 100, 128, 35);
		contentPane.add(btnNewButton);
	}
}
