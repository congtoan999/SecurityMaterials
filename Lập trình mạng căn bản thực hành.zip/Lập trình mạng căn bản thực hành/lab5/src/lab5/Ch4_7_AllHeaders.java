package lab5;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import sun.net.www.URLConnection;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JTextArea;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.awt.event.ActionEvent;
public class Ch4_7_AllHeaders extends JFrame {
	private JPanel contentPane;
	private JTextField InputURL;
	/**
	* Launch the application.
	*/
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Ch4_7_AllHeaders frame = new Ch4_7_AllHeaders();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	/**
	* Create the frame.
	*/
	public Ch4_7_AllHeaders() {
		setTitle("Print the entire HTTP header");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		setBounds(100, 100, 624, 551);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		InputURL = new JTextField();
		InputURL.setText("https://dantri.com.vn/the-gioi.htm");
		InputURL.setFont(new Font("Times New Roman", Font.BOLD, 20));
		InputURL.setBounds(139, 32, 376, 36);
		contentPane.add(InputURL);
		InputURL.setColumns(10);
		JTextArea textArea = new JTextArea();
		textArea.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		textArea.setEditable(false);
		textArea.setBounds(58, 175, 508, 288);
		contentPane.add(textArea);
		JScrollPane scrollPane = new JScrollPane(textArea);
		scrollPane.setBounds(58, 175, 508, 288);
		contentPane.add(scrollPane);
		
		JButton btnNewButton = new JButton("Click Me!");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String str = InputURL.getText();
				String headerViewer="";
				try {
					URL u = new URL(str);
					java.net.URLConnection uc = u.openConnection( );
					for (int j = 1; ; j++) {
						String header = uc.getHeaderField(j);
						if (header == null) break;
						headerViewer +=" * "+ uc.getHeaderFieldKey(j) + ": " + header+"\n";
					} // end for
					textArea.setText(headerViewer);
				} catch (MalformedURLException e) {
					textArea.setText("");
					Component fame = null;
					JOptionPane.showMessageDialog(fame, "Could not find URL: "+str,"MalformedURLException",JOptionPane.WARNING_MESSAGE);
				} catch (IOException e) {
					textArea.setText("");
					Component fame = null;
					JOptionPane.showMessageDialog(fame, "I/O devices
							disconnect","IOException",JOptionPane.WARNING_MESSAGE);
				}
			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnNewButton.setBounds(213, 94, 174, 44);
		contentPane.add(btnNewButton);
		JLabel lblNewLabel = new JLabel("Input URL:");
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblNewLabel.setBounds(12, 32, 112, 36);
		contentPane.add(lblNewLabel);
	}
}
