package lab5;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import org.omg.CORBA.portable.InputStream;
import sun.net.www.URLConnection;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.net.MalformedURLException;
import java.net.URL;
import java.awt.event.ActionEvent;
import javax.swing.UIManager;
import javax.swing.border.CompoundBorder;
import java.awt.Color;
import javax.swing.border.LineBorder;
import java.awt.SystemColor;
public class Ch4_2_OutputStream_SourceViewer extends JFrame {
private JPanel contentPane;
private JTextField TFInputURL;
private JLabel lblNewLabel;
private JButton btnNewButton;
private JButton btnNewButton_1;
private JTextField textField;
/**

* Launch the application.
*/
public static void main(String[] args) {
	EventQueue.invokeLater(new Runnable() {
		public void run() {
			try {
				Ch4_2_OutputStream_SourceViewer frame = new Ch4_2_OutputStream_SourceViewer();
				frame.setVisible(true);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	});
	}
	/**
	* Create the frame.
	*/
	public Ch4_2_OutputStream_SourceViewer() {
		setTitle("OutputStream");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 656, 291);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(0, 0, 0, 0));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		TFInputURL = new JTextField();
		TFInputURL.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		TFInputURL.setText("https://dantri.com.vn/the-gioi.htm");
		TFInputURL.setBounds(120, 43, 350, 29);
		contentPane.add(TFInputURL);
		TFInputURL.setColumns(10);
		lblNewLabel = new JLabel("Input URL:");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel.setBounds(21, 38, 87, 29);
		contentPane.add(lblNewLabel);
		btnNewButton = new JButton("Click Me!");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String str = TFInputURL.getText();
				try {
					//Open the URLConnection for reading
					URL u = new URL(str);
					java.net.URLConnection uc = u.openConnection( );
					java.io.InputStream raw = uc.getInputStream( );
					BufferedInputStream buffer = new BufferedInputStream(raw);
					// chain the InputStream to a Reader
					Reader r = new InputStreamReader(buffer);
					OutputStream os = new FileOutputStream("OutputStream.htm");
					int c;
					while ((c = r.read( )) != -1) {
						os.write((char) c);
					}
					os.close();
					Component fame = null;
		
					JOptionPane.showMessageDialog(fame, "Tạo thành công tệp OutputStream.htm ","MalformedURLException",JOptionPane.WARNING_MESSAGE);
					textField.setText("D:\\Giao An\\Basic Network Programming\\Software\\Hoc Java\\ComputerNetworkProgrammingVersion2\\OutputStream.htm");
				}catch (MalformedURLException ex) {
					Component fame = null;
					JOptionPane.showMessageDialog(fame, "Could not find URL: "+str,"MalformedURLException",JOptionPane.WARNING_MESSAGE);
				}catch (IOException ex) {
					Component fame = null;
					JOptionPane.showMessageDialog(fame, "I/O devices disconnect","IOException",JOptionPane.WARNING_MESSAGE);
					}
				}
			});
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnNewButton.setBounds(242, 85, 128, 35);
		contentPane.add(btnNewButton);
		btnNewButton_1 = new JButton("Back");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Chap4 frame = new Chap4();
				frame.setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnNewButton_1.setBounds(511, 38, 100, 36);
		contentPane.add(btnNewButton_1);
		textField = new JTextField();
		textField.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		textField.setColumns(10);
		textField.setBounds(21, 187, 590, 29);
		contentPane.add(textField);
		JLabel lblLinking = new JLabel("Linking");
		lblLinking.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		lblLinking.setBounds(284, 145, 62, 29);
		contentPane.add(lblLinking);
	}
}