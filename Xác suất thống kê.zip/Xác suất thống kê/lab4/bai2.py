import random

def ball_probability(n):
    same_color = 0
    different_colors = 0
    two_same_one_different = 0
    two_red_one_white = 0
    all_white_cases = []

    for i in range(n):
        urn = ['blue', 'blue', 'red', 'red', 'red', 'white', 'white', 'white', 'white', 'white']
        balls = random.sample(urn, 3)

        if len(set(balls)) == 1:
            same_color += 1

        if len(set(balls)) == 3:
            different_colors += 1

        if len(set(balls)) == 2:
            two_same_one_different += 1

            if balls.count('red') == 2 and balls.count('white') == 1:
                two_red_one_white += 1

        if balls.count('white') == 3:
            all_white_cases.append(balls)

    print(f"Xác suất cả ba viên cùng màu: {same_color/n}")
    print(f"Xác suất cả ba viên khác màu nhau: {different_colors/n}")
    print(f"Xác suất chỉ có hai viên cùng màu: {two_same_one_different/n}")
    print(f"Xác suất có hai viên đỏ và một viên trắng: {two_red_one_white/n}")
    print("Các trường hợp có cả ba viên trắng:")
    for case in all_white_cases:
        print(case)
        
n = 100
ball_probability(n)