import random

def dice_probability(n):
    same = 0
    different = 0
    both_even = 0
    both_odd = 0
    one_even_one_odd = 0
    both_six = 0
    sum_greater_than_10 = 0

    for i in range(n):
        dice1 = random.randint(1, 6)
        dice2 = random.randint(1, 6)

        if dice1 == dice2:
            same += 1

        if dice1 != dice2:
            different += 1

        if dice1 % 2 == 0 and dice2 % 2 == 0:
            both_even += 1

        if dice1 % 2 != 0 and dice2 % 2 != 0:
            both_odd += 1

        if (dice1 % 2 == 0 and dice2 % 2 != 0) or (dice1 % 2 != 0 and dice2 % 2 == 0):
            one_even_one_odd += 1

        if dice1 == dice2 == 6:
            both_six += 1

        if dice1 + dice2 > 10:
            sum_greater_than_10 += 1

    print(f"Xác suất hai viên giống nhau: {same/n}")
    print(f"Xác suất hai viên khác nhau: {different/n}")
    print(f"Xác suất hai viên cùng chẵn: {both_even/n}")
    print(f"Xác suất hai viên cùng lẻ: {both_odd/n}")
    print(f"Xác suất một viên chẵn và một viên lẻ: {one_even_one_odd/n}")
    print(f"Xác suất hai viên cùng ra số sáu: {both_six/n}")
    print(f"Xác suất tổng số nút lớn hơn mười: {sum_greater_than_10/n}")

n = 10  
dice_probability(n)
