import random

def experiment(n):
    deck = [i for i in range(52)]
    same_suit = 0
    diff_suit = 0
    same_color = 0
    same_value = 0
    all_numbers = 0
    all_faces = 0

    for i in range(n):
        random.shuffle(deck)
        hand = deck[:4]
        suits = [card // 13 for card in hand]
        values = [card % 13 for card in hand]

        if len(set(suits)) == 1:
            same_suit += 1

        if len(set(suits)) == 4:
            diff_suit += 1

        if len(set([suit % 2 for suit in suits])) == 1:
            same_color += 1

        if len(set(values)) == 1:
            same_value += 1

        if len(set([value for value in values if value < 10])) == 4:
            all_numbers += 1

        if len(set([value for value in values if value >= 10])) == 4:
            all_faces += 1

    print(f"Xác suất thực nghiệm của các sự kiện sau với {n} lần thí nghiệm:")
    print(f"a/ Bốn lá cùng chất: {same_suit / n:.4f}")
    print(f"b/ Bốn lá đôi một khác chất: {diff_suit / n:.4f}")
    print(f"c/ Bốn lá cùng màu: {same_color / n:.4f}")
    print(f"d/ Bốn lá cùng chỉ số (tứ quý): {same_value / n:.4f}")
    print(f"e/ Bốn lá cùng là loại số: {all_numbers / n:.4f}")
    print(f"f/ Bốn lá cùng là loại hình: {all_faces / n:.4f}")
    
n = 100
experiment(n)