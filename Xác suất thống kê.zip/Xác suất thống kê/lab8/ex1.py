import pandas as pd
import numpy as np

iris_data = pd.read_csv('iris.csv')

print("First 5 data points:")
print(iris_data.head())

statistics = iris_data.describe()

result_df = pd.DataFrame({
    "Feature": ["Count", "Mean", "Standard Deviation", "Min", "Max"],
    "Sepal Length (cm)": [statistics.loc['count', 'sepal_length'], statistics.loc['mean', 'sepal_length'], statistics.loc['std', 'sepal_length'], statistics.loc['min', 'sepal_length'], statistics.loc['max', 'sepal_length']],
    "Sepal Width (cm)": [statistics.loc['count', 'sepal_width'], statistics.loc['mean', 'sepal_width'], statistics.loc['std', 'sepal_width'], statistics.loc['min', 'sepal_width'], statistics.loc['max', 'sepal_width']],
    "Petal Length (cm)": [statistics.loc['count', 'petal_length'], statistics.loc['mean', 'petal_length'], statistics.loc['std', 'petal_length'], statistics.loc['min', 'petal_length'], statistics.loc['max', 'petal_length']],
    "Petal Width (cm)": [statistics.loc['count', 'petal_width'], statistics.loc['mean', 'petal_width'], statistics.loc['std', 'petal_width'], statistics.loc['min', 'petal_width'], statistics.loc['max', 'petal_width']]
})
print("Summary Statistics:")
print(result_df)
