import pandas as pd
df = pd.DataFrame({'numbes' : [1,2,3],'colors': ['red','white','blue']})

df = pd.DataFrame({'numbers': [1,2,3],'colors': ['red','while','blue']})
print(df)

import numpy as np
import pandas as pd

df = pd.DataFrame(np.random.randn(5,3), columns=['N1','N2','N3'])
print(df)

import pandas as pd
df = pd.DataFrame({'N1' : [1,2,3,4],'N2' : [4,3,2,1]})
print(df)

import pandas as pd
L= [{'Name' : 'John','Last Name' : 'Smith'},{'Name' : 'Marry','Last Name' : 'Wood'}]
df = pd.DataFrame(L)
print(df)

data = np.loadtxt("sample.txt", delimiter=',')
print(data)

data = pd.read_csv('sample1.txt',delimiter=',')
print(data)
print("Print column Score")
print(data.Score)


df = pd.DataFrame(np.random.randn(10,3),columns=['N1','N2','N3'])
print(df)
print()
print(df.head(5))
print()
print(df.tail(5))
N2 = df['N2']
print(N2)

df[['N1','N2']]
print(df[1:-2])
