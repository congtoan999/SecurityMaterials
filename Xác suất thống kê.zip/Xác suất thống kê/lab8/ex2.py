import pandas as pd

population_data = pd.read_csv('population.csv')

print("5 dòng đầu tiên:")
print(population_data.head())

result_df = pd.DataFrame(columns=["Year", "Count", "Mean", "Standard Deviation", "Min", "Max"])

unique_years = population_data['Year'].unique()

for year in unique_years:
    year_data = population_data[population_data['Year'] == year]
    count = len(year_data)
    mean = year_data['Value'].mean()
    std = year_data['Value'].std()
    minimum = year_data['Value'].min()
    maximum = year_data['Value'].max()
    result_df = pd.concat([result_df, pd.DataFrame({"Year": [year], "Count": [count], "Mean": [mean], "Standard Deviation": [std], "Min": [minimum], "Max": [maximum]})], ignore_index=True)
    
print("Thống kê theo năm:")
print(result_df)
