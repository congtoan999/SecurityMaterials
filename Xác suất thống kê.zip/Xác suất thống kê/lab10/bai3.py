import pandas as pd
import matplotlib.pyplot as plt


file_path = "company-sales_data.csv" 
df = pd.read_csv(file_path)


toothpaste_data = df['toothpaste']
shampoo_data = df['shampoo']
facecream_data = df['facecream']

# Vẽ biểu đồ 
months = df['month_number']

plt.figure(figsize=(10, 6))

plt.plot(months, toothpaste_data, label='Toothpaste', marker='o')
plt.plot(months, shampoo_data, label='Shampoo', marker='o')
plt.plot(months, facecream_data, label='Face Cream', marker='o')

plt.xlabel('Month')
plt.ylabel('Sales')
plt.title('Monthly Sales of Toothpaste, Shampoo, and Face Cream')
plt.legend()
plt.grid(True)
plt.show()
