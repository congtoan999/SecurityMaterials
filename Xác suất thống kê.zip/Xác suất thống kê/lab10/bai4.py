import nltk
from nltk.tokenize import word_tokenize
import matplotlib.pyplot as plt
from nltk.probability import FreqDist

# Bạn có thể thay đổi đoạn văn bản ở đây hoặc đọc từ tệp tin
text = """Your text goes here. It should contain at least 300 words. ..."""

# Tokenize văn bản thành các từ
words = word_tokenize(text)

# Tính tần suất xuất hiện của các từ
freq_dist = FreqDist(words)

# Vẽ biểu đồ histogram với số bin là 30
plt.figure(figsize=(10, 6))
freq_dist.plot(30, cumulative=False)
plt.title('Word Frequency Histogram')
plt.xlabel('Word')
plt.ylabel('Frequency')
plt.show()
