import random
import matplotlib.pyplot as plt

def flip_dice(n):
    results = []
    for _ in range(n):
        dice1 = random.randint(1, 6)
        dice2 = random.randint(1, 6)
        results.append(dice1 + dice2)
    return results

# (a) 
x = flip_dice(10000)

# (b) 
X = set(x)

# (c) 
P = [x.count(value) / 10000 for value in X]

# (d) 
expectation = sum(value * probability for value, probability in zip(X, P))
variance = sum((value - expectation) ** 2 * probability for value, probability in zip(X, P))
standard_deviation = variance ** 0.5

# Display the results
print("Results of flipping two fair dice 10,000 times:")
print("X values:", sorted(list(X)))
print("Probability distribution function (P):", P)
print("Expectation:", expectation)
print("Variance:", variance)
print("Standard Deviation:", standard_deviation)

# Plotting the probability distribution function
plt.bar(sorted(list(X)), P)
plt.xlabel('X values')
plt.ylabel('Probability')
plt.title('Probability Distribution Function')
plt.show()
