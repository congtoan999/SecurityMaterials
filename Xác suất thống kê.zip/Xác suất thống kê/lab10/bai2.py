import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import norm
from scipy.special import erf  # Import the erf function from scipy.special

def pmf_normal(x, mean, std_dev):
    return (1 / (std_dev * np.sqrt(2 * np.pi))) * np.exp(-(x - mean)**2 / (2 * std_dev**2))

def cdf_normal(x, mean, std_dev):
    return 0.5 * (1 + erf((x - mean) / (std_dev * np.sqrt(2)))) 


mean = 3
std_dev = np.sqrt(16)

# (a) 
x_values = np.linspace(-10, 16, 1000)
pdf_values = pmf_normal(x_values, mean, std_dev)

plt.plot(x_values, pdf_values, label='pdf_normal')
plt.xlabel('X')
plt.ylabel('Probability Density')
plt.title('Probability Density Function of Normal Distribution')
plt.legend()
plt.show()

# (b)
cdf_values = cdf_normal(x_values, mean, std_dev)

plt.plot(x_values, cdf_values, label='cdf_normal')
plt.xlabel('X')
plt.ylabel('Cumulative Probability')
plt.title('Cumulative Distribution Function of Normal Distribution')
plt.legend()
plt.show()

# (c) 
probability_between_2_and_7 = cdf_normal(7, mean, std_dev) - cdf_normal(2, mean, std_dev)
print("Probability P(2 < X < 7): {:.4f}".format(probability_between_2_and_7))
