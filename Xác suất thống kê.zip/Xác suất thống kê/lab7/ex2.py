import matplotlib.pyplot as plt
from math import *

def pmf_normal (x,mu,sigma):
    return exp(-(x-mu)**2/(2*sigma**2))/(sigma*sqrt(2*pi))
def cdf_normal(x,mu,sigma):
    return (1+erf((x-mu)/(sigma*sqrt(2))))/2
def solve(mu,sigma,a,b):
    return cdf_normal(b,mu,sigma) - cdf_normal(a,mu,sigma)
print(solve(10,1,9,22))
print(cdf_normal(1.51,0,1))     #1
print(cdf_normal(2.13,0,1))     #2
print(cdf_normal(-0.87,0,1))    #3
print(cdf_normal(1.11,0,1))     #4
print(cdf_normal(-0.66,0,1))    #5
print(solve(0,1,0.28,1.31))     #6
print(solve(0,1,-0.86,0.12))    #7
print(solve(0,1,-2.2,-0.16))    #8
