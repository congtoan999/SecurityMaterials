import matplotlib.pyplot as plt
import math

def generator_data(a,b,size):
    n = (b - a) / (size -1)
    result = []
    s = a
    while s<b:
        result.append(s)
        s = s+n
    if len(result)<size:
        result.append(b)
    return result
X = generator_data(4,6,100)
print(X)