def cross(A,B):
    return {a + b  for a  in A for b in B }
urn  = cross('W','12345678') | cross('B','123456') | cross('R','123456789')

import itertools
U3 = list(itertools.combinations(urn,3))

print("cau a: " ,len(U3))

for i in U3:
    if i[0][0] =='W' and i[1][0] == 'B' and i[2][0] == 'R':
        print("cau b : ",i)
for s in U3:
    if s[0][0] =='R' and s[2][0] == 'R':
        print("cau c : ",s)