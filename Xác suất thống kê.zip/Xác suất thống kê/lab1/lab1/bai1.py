import itertools

A = {'1','2','3','4','5'}
num_3_digit = 3
num_length = len(A)
choose_num_3_digit = list(itertools.permutations(A,num_3_digit))
print("%i-combinations of %s" %(num_3_digit,A))
for i in choose_num_3_digit:
    print(i)
print("Number of combinations = %i!/(%i!(%i-%i)!) = %i" %(num_length,num_3_digit,num_length,num_3_digit,len(choose_num_3_digit)))
