for i in permute_k:
    #     print(i)