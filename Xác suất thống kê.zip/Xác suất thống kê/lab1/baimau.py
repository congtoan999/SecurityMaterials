def mau1():
    import itertools
    
    E = {'a','b','c','d','e'}
    k = 3
    n = len(E)
    permute_k = list(itertools.permutations(E,k))
    print("%i-permutation of %s: "%(k,E) )
    for i in permute_k:
        print(i)
    print("Size = ","%i!/(%i-%i)! = " %(n,n,k), len(permute_k))
# mau1()

def mau2():
    import itertools
    
    E = {'a','b','c','d'}
    k = 3
    n = len(E)
    choose_k = list(itertools.combinations(E,k))
    print("%i-combination of %s: " %(k,E))
    for i in choose_k:
        print(i)
    print("Number of combinations = %i!/(%i!(%i-%i)!) = %i" %(n,k,n,k,len(choose_k)))
# mau2()   

def cross(A,B):
    return {a+b for a in A for b in B}

urn = cross ("W" , '12345678') | cross('B','123456') | cross ('R','123456789')

# print(urn)



import itertools
U6 = list(itertools.combinations(urn,6))
# Solution for (a):
print(len(U6))

# # Solution for (b):
# for s in U6:
#     print(s)

# # Solution for (c):
# for s in U6:
#     if s[0][0] == 'R' and s[-1][0] == 'R':
#         print(s)
        