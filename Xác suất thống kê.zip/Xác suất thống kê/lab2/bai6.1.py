def simualtor_dice1(n):
    import random
    count = 0
    for i in range(n):
        c1 = random.randint(1,6)
        c2 = random.randint(1,6)
        if c1 %2 == 0 and c2 %2 ==0:
            count += 1
    print(count/n)

# simualtor_dice1(1000)

def simualtor_dice2(n):
    import random
    count = 0
    for i in range(n):
        c1 = random.randint(1,6)
        c2 = random.randint(1,6)
        if (c1 %2 == 0 and c2 %2 !=0) or(c1%2 != 0 and c2%2 == 0 ):
           count += 1
    print(count/n)
# simualtor_dice2(100) 

def simualtor_dice3(n):
    import random
    count = 0
    for i in range(n):
        c1 = random.randint(1,6)
        c2 = random.randint(1,6)
        if (c1 == c2):
           count += 1
    print(count/n)
# simualtor_dice3(10000) 

def simualtor_dice4(n):
    import random
    count = 0
    for i in range(n):
        c1 = random.randint(1,6)
        c2 = random.randint(1,6)
        if (c1 == 1 and c2==6)or(c1==6 and c2 == 1):
           count += 1
    print(count/n)
# simualtor_dice4(1000000) 

def simualtor_dice5(n):
    import random
    count = 0
    for i in range(n):
        c1 = random.randint(1,6)
        c2 = random.randint(1,6)
        if (c1 + c2 >6):
           count += 1
    print(count/n)
# simualtor_dice5(1000000) 

import random
import itertools
from itertools import product
def sumualtor_poker1(n):
    ranks = {1,2,3,4,5,6,7,8,9,10,'J','Q','K'}
    suits = {'♡', '♢', '♣', '♠'}
    card = list(product(ranks,suits))
    # print(card)
    poker_5 = list(itertools.combinations(card,5))
    random.shuffle(poker_5)   # hoan doi vi tri cac gia tri trong poker_5

    sum = 0 
    for s in poker_5:
        count = 0
        for i in range(0,len(s)):
            if(s[i].count('♡')):
                count = count + 1
        if(count == 5):
            sum = sum + 1
    return sum/len(poker_5)
print(sumualtor_poker1(10))

def simultor_poker2(n):
    ranks = {1,2,3,4,5,6,7,8,9,10,'J','Q','K'}
    suits = {'♡', '♢', '♣', '♠'}
    card = list(product(ranks,suits))
    count = 0
    for i in range(n):
        index = random.randint(0,51)
        if card[index][1] == '♡' and card[index][1] == '♢' and card[index][1] == '♣' and card[index][1] =='♠' :
            count += 1
            print(count)
    return count/n
print(simultor_poker2(10))



    
    
    