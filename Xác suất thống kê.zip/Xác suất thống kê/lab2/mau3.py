import random
n = 10
count = 0 
for s in range(n):
    t = random.randint(0,1)
    if t == 1 :
        count +=1
print(count/n)
