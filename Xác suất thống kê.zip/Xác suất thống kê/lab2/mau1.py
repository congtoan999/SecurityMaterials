from fractions import  Fraction 

def P(event, space):
    return Fraction(len(event and space), len(space))

D = {1,2,3,4,5,6}
even = { 1,2,4,6}

# print(P(even,D))

def cross(A,B):
    return {a+b for a in A for b in B}
urn = cross('W','12345678') | cross('B','123456') | cross('R','123456789')
# print(urn)

import itertools
import random 

def combos(items,n ):
    return {' '.join(combo) for combo in itertools.
    combinations(items,n)}

U6 = combos(urn,6)
print(len(U6))
U6_list = list(U6)

print(random.sample(U6_list,10))

red6 = {s for s in U6 if s.count('R') == 6}
t = P(red6,U6)
print(t)

# b3w2r1 = {s for s in U6 if s.count('B') == 3 and s.count('W'
# ) == 2 and s.count('R') == 1}
# print(P(b3w2r1 , U6))

