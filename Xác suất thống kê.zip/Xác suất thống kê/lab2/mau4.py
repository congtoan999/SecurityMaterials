import random 
count = 0
n = 1000000
for i in range(n):
    d1 = random.randint(1,6)
    d2 = random.randint(1,6)
    if d1 == 1 and d2 == 6:
        count +=1
print(count/n)