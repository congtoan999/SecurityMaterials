from itertools import product 
import random

ranks = {1,2,3,4,5,6,7,8,9,10,'J','Q','K'}
suits = {'♡', '♢', '♣', '♠'}
card = list(product(ranks,suits))
# print(len(card))
print(card[:10])   

def simulartor(n):
    count = 0
    for i in range(n):
        index = random.randint(0,51)
        if card[index][1] == '♡' or card[index][1] == '♢':
            count += 1
            print(count)
    return count/n
print(simulartor(5))
