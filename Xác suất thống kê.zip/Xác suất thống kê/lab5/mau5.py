import random

x = [random.randint(1,6) for i in range(8)]
X = set(x)

P = [x.count(i)/len(x) for i in X]
# print(P)
# FX = sum(P[:3])
# print(FX)

EX = 0
for x in X:
    EX = EX + (x*P[x-1])
# print(EX)

VarX = 0
for x in X:
    VarX = VarX+ (x-EX)*(x-EX)*P[x-1]
print(VarX) # chay duoc 