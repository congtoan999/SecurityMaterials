import random

x = [random.randint(1,6) for i in range(8)]
X = set(x)

P = [x.count(i)/len(x) for i in X]
print(P)