import numpy as np
import random
import math
# cau a
x = np.random.choice(0,1,2,3,4,5,3650,p = [0.1,0.2,0.3,0.2,0.15,0.05])
x.list(x)
X = set(x)
print(x)
# cau b
P = [x.count(i)/len(x) for i in X]

# cau c 
EX = 0
for x in X:
    EX = EX + (x*P[x-1])

VarX = 0
for x in X:
    VarX = VarX+ (x-EX)*(x-EX)*P[x-1] 
SD = math.sqrt(VarX)
print(SD)

FX = np.sum(P[-3:])
def d():
    print(FX)
