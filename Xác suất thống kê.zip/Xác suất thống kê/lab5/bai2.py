import random
import math
import numpy as np


# cau a
x1 = [random.randint(0,1) for i in range(10000)]
x2 = [random.randint(0,1) for i in range(10000)]
x = x1+x2
X = set(x)

# cau b
P = [x.count(i)/len(x) for i in X]

# cau c 
EX = 0
for x in X:
    EX = EX + (x*P[x-1])

VarX = 0
for x in X:
    VarX = VarX+ (x-EX)*(x-EX)*P[x-1] 
SD = math.sqrt(VarX)
print(SD)

