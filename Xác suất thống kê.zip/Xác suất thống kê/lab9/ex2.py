import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# Tạo dữ liệu giả định
months = np.arange(1, 13)
total_profit = np.random.randint(50000, 100000, size=12)
toothpaste_sales = np.random.randint(1000, 5000, size=12)
facecream_sales = np.random.randint(500, 2000, size=12)
facewash_sales = np.random.randint(800, 3000, size=12)

# Tạo DataFrame từ dữ liệu giả định
sales_data = pd.DataFrame({
    'month_number': months,
    'total_profit': total_profit,
    'toothpaste': toothpaste_sales,
    'facecream': facecream_sales,
    'facewash': facewash_sales
})

# Lưu dữ liệu vào tệp CSV
sales_data.to_csv('company_sales_data.csv', index=False)

# Hiển thị dữ liệu giả định
print("Dữ liệu giả định:")
print(sales_data)

# Tiếp tục với phần còn lại của đoạn mã như trước đó...

# Task 1: Read total profit of all months and use a line plot to show it
plt.plot(sales_data['month_number'], sales_data['total_profit'], marker='o')
plt.title('Total Profit Over Months')
plt.xlabel('Month Number')
plt.ylabel('Total Profit')
plt.grid(True)
plt.show()

# Task 2: Read all month of toothpaste sales data and show it using a scatter plot
plt.scatter(sales_data['month_number'], sales_data['toothpaste'], marker='o', color='orange')
plt.title('Toothpaste Sales Over Months')
plt.xlabel('Month Number')
plt.ylabel('Toothpaste Sales')
plt.grid(True)
plt.show()

# Task 3: Read facecream and facewash product and use a bar chart to show them
bar_width = 0.4
plt.bar(sales_data['month_number'] - bar_width / 2, sales_data['facecream'], label='Face Cream', width=bar_width)
plt.bar(sales_data['month_number'] + bar_width / 2, sales_data['facewash'], label='Face Wash', width=bar_width)

plt.title('Face Cream and Face Wash Sales Over Months')
plt.xlabel('Month Number')
plt.ylabel('Sales')
plt.legend()
plt.grid(True)
plt.show()
