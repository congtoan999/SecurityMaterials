import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.datasets import load_iris

# Load the Iris dataset
iris = load_iris()
iris_data = iris.data
iris_feature_names = iris.feature_names

# Create a DataFrame for easy plotting
import pandas as pd
iris_df = pd.DataFrame(iris_data, columns=iris_feature_names)

# Scatter plot
sns.scatterplot(x='sepal length (cm)', y='sepal width (cm)', data=iris_df)
plt.xlabel('Sepal Length (cm)')
plt.ylabel('Sepal Width (cm)')
plt.title('Scatter Plot of Sepal Length vs Sepal Width')
plt.show()

# Histogram for Sepal Length
sns.histplot(iris_df['sepal length (cm)'], bins=20, kde=False)
plt.xlabel('Sepal Length (cm)')
plt.ylabel('Frequency')
plt.title('Histogram of Sepal Length')
plt.show()
