import matplotlib.pyplot as plt
import numpy as np

samples = [0.895,0.91,0.919,0.926,0.929,0.931]
plt.plot(samples)

years = [2010,2011,2012,2013,2014,2015]
samples = [0.895,0.91,0.919,0.926,0.929,0.931]
plt.show()


plt.xlabel('Year')
plt.ylabel('Yield')
plt.plot(years,samples)

girl_grades = np.random.randint(100,size = 30)
boys_grades = np.random.randint(100, size = 30)
grades_range = np.random.randint(100,size = 30)
fig = plt.figure(figsize=(3,3))
ax = fig.add_axes([0,0,1,1])
ax.scatter(grades_range,girl_grades,color = 'r')
ax.scatter(grades_range,boys_grades,color = 'b')
ax.set_xlabel('Grades Range')
ax.set_ylabel('Grades Scored')
ax.set_title('scatter plot')
plt.show()

years = range(2000,2006)
oranges = [0.4,0.8,0.9,0.7,0.6,0.8]

plt.xlabel('Year')
plt.ylabel('Yield')
plt.bar(years,oranges)
plt.show()

apples = [0.35,0.6,0.9,0.8,0.65,0.8]
plt.bar(years,apples)
plt.bar(years,oranges,bottom= apples)
plt.show()

data = [[30,25,50,20],[40,23,51,17]]
X= np.arange(4)
fig = plt.figure()
ax = fig.add_axes([0,0,1,1])
ax.bar(X + 0.00,data[0],color = 'b', width=0.25)
ax.bar(X + 0.25,data[1],color = 'g',width=0.25)
ax.set_xticks([0.25,1.25,2.25,3.25])
ax.set_xticklabels([2015,1026,2017,2018])
ax.legend(labels = ['Oranges','Apples'])
plt.show()

fig,ax = plt.subplots(1,1)
a = np.array([72,87,5,73,56,73,55,54,11,20,51,5,79,31,27])
ax.hist(a,bins = [0,25,50,75,100])
ax.set_xticks([0,25,50,75,100])
ax.set_xlabel('marks')
ax.set_ylabel('no. of students')
plt.show()
