import nltk
from nltk.tokenize import word_tokenize
from nltk.probability import FreqDist
import matplotlib.pyplot as plt

# Download the punkt tokenizer if not already installed
nltk.download('punkt')

# Your text (replace this with your actual text)
your_text = """
Enter your text here. It should be at least 300 words long. 
Make sure to include enough diverse words for meaningful analysis.
"""

# Tokenize the text into words
words = word_tokenize(your_text)

# Calculate word frequencies
freq_dist = FreqDist(words)

# Select the 30 most common words
top_words = freq_dist.most_common(30)

# Extract words and frequencies for plotting
words, frequencies = zip(*top_words)

# Plot the frequencies using a line plot
plt.figure(figsize=(10, 6))
plt.plot(words, frequencies, marker='o', linestyle='-', color='b')
plt.title('30 Most Common Words')
plt.xlabel('Words')
plt.ylabel('Frequency')
plt.xticks(rotation=45, ha='right')
plt.tight_layout()
plt.show()
