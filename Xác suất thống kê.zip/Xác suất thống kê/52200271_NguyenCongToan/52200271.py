import random

numbers = [27, 61, 52, 69, 88, 85, 79, 99, 77, 165, 41, 83, 144, 74, 143, 131, 34, 59, 46, 105, 61, 118, 114, 138, 24, 67, 130, 56, 99, 125, 87, 30, 119, 40, 25, 44,
           123, 45, 25, 94, 86, 128, 69, 102, 91, 106, 119, 139, 67, 47, 62, 92, 124, 31, 49, 68, 109, 138, 105, 84, 86, 66, 128, 146, 59]

# Chọn 30 số ngẫu nhiên
random_30 = random.sample(numbers, 30)
random_15 = random.sample(numbers, 15)

print("30 số được chọn ngẫu nhiên:", random_30)
print("15 số được chọn ngẫu nhiên:", random_15)