import matplotlib.pyplot as plt
import numpy as np
from IPython.display import display, Math, Latex
from PIL import Image

# duong dan den anh can tim
link_anh = 'tranh1.jpg'

img = Image.open(link_anh)
img = img.convert('L')

# chuyen anh thanh mang numpy
img_ar = np.array(img)
fl = img_ar.flatten()

plt.hist(fl, bins=50)
plt.show()
display(Math(r'P_x(j) = \sum_{i=0}^{j} P_x(i)'))

def get_histogram(image, bins):
    histo = np.zeros(bins)
    
    for pi in image:
        histo[pi] += 1
    
    return histo

hist = get_histogram(fl, 256)

plt.plot(hist)
plt.show()

def cumsum(a):
    a = iter(a)
    b = [next(a)]
    for i in a:
        b.append(b[-1] + i)
    return np.array(b)

csum = cumsum(hist)

plt.plot(csum)
plt.show()

j = (csum - csum.min()) * 255
N = csum.max() - csum.min()

csum = j / N

csum = csum.astype('uint8')

plt.plot(csum)
plt.show()

new = csum[fl]
plt.hist(new, bins=50)

new = np.reshape(new, img_ar.shape)

f = plt.figure()
f.set_figheight(15)
f.set_figwidth(15)

f.add_subplot(1, 2, 1)
plt.imshow(img_ar, cmap='gray')

f.add_subplot(1, 2, 2)
plt.imshow(new, cmap='gray')

plt.show(block=True)


import cv2
import numpy as np

m = cv2.imread('tranh1.jpg')
s = cv2.imread('tranh2.jpeg')


def CDF(image):
    tong = image.shape[0] * image.shape[1]
    dem = np.zeros(256, dtype=int)
    xacsuat = np.zeros(256, dtype=float)
    CDF = np.zeros(256, dtype=float)

    for hang in range(image.shape[0]):
        for cot in range(image.shape[1]):
            dem[image[hang, cot, 2]] += 1

    for i in range(256):
        xacsuat[i] = dem[i] * 1.0 / tong

    CDF[0] = xacsuat[0]
    for i in range(1, 256):
        CDF[i] = CDF[i - 1] + xacsuat[i]
    return CDF

def histogram_matching(m, s):
    t = s.copy()
    f2 = CDF(m)
    f1 = CDF(s)
 

    M = [0] * 256
    for i in range(256):
        M[i] = i
        for j in range(256):
            if abs(f1[i] - f2[j]) < 0.001:
                M[i] = j
                break

    for hang in range(t.shape[0]):
        for cot in range(t.shape[1]):
            t[hang, cot, 0] = t[hang, cot, 1] = t[hang, cot, 2] = M[t[hang, cot, 2]]
    return t


# so co khop histo khong
kq = histogram_matching(m, s)

# kq
cv2.imshow('Result', kq)
cv2.waitKey(0)
cv2.destroyAllWindows()
