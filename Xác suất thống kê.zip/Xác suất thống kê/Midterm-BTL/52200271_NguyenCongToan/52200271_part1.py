
# mean
from statistics import mean
d = [6,4,2,5]
print("Mean:", mean(d))

# fmean
from statistics import fmean
a=[1.0,2.0,3.0,4.0]
b=[1.6,3.2,3.0,4.0]
print('fmean: ',fmean(a,b))

# geometric_mean
from statistics import geometric_mean
a=[54,4,26]
print('geometric_mean: ',round(geometric_mean(a),1))

# harmonic_mean
from statistics import harmonic_mean
a=[40,50]
print('harmonic_mean: ',harmonic_mean(a))   

# median
from statistics import median
a=[1,4,7]
b=[1,5,10,12]

print('median: ',median(a))
print('median: ',median(b))

# median_low
from statistics import median_low
a=[1.0,4.0,7.0]
b=[1.0,4.0,7.0,10.0]
print('median_low: ',median_low(a))
print('median_low: ',median_low(b))

# median_high
from statistics import median_high
a=[1.0,4.0,7.0]
b=[1.0,4.0,7.0,10.0]
print('median_high: ',median_high(a))
print('median_high: ',median_high(b))

# median_grouped
from statistics import median_grouped
a=[52, 52, 53, 54]
b=[1,2,2,3,3,3,5]
print('median_grouped: ',median_grouped(a))
print('median_grouped: ',median_grouped(b))

# mode
from statistics import mode
a=[1,1,1,1,2,3,4,4,5,5]
print('mode: ',mode(a))

# multimode
from statistics import multimode
a=[1,2,3,5,5,5,7,6,6,6]
print('multimode: ',multimode(a))

# pstdev
from statistics import pstdev
a=[3.4,6.7,8.9,10,8]
print('pstdev: ',pstdev(a))

# pvariance
from statistics import pvariance
a=[0.1, 0.5, 0.25, 1.25]
print('pvariance: ',pvariance(a))

# stdev
from statistics import stdev
a=[1.5, 3.5, 1.15, 5.75, 3.25]
print('stdev: ',stdev(a))

# variance
from statistics import variance
a=[2.7, 1.5, 0.259, 0.25]
print('variance: ',variance(a))

# quantiles
from statistics import quantiles
a=[14, 19, 37, 83, 211, 411, 89, 81, 108, 92, 110,
        100, 73, 106, 104, 109, 77, 89, 98, 101, 102, 139]
print('quantiles: ',[round(q, 1) for q in quantiles(a, n=10)])

# covariance
from statistics import covariance
a = [1, 9, 3, 3, 1, 2, 8, 6, 0]
b = [1, 1, 2, 5, 3, 2, 8, 5, 0]
print('covariance and b: ',covariance(a,b))

# correlation
from statistics import correlation
a = [89, 25, 65, 10_76, 2_67, 60_190]   
b = [28, 18, 50, 1_40, 2_90, 4_50]
print('correlation and a: ',correlation(a,a))
print('correlation and b: ',correlation(a,b))

# linear_regression
from statistics import linear_regression
a=[191,1975,1999,1182,2983]
b=[5,2,4,3,1]
print('linear_regression: ',linear_regression(a,b))