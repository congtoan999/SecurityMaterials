from fractions import Fraction

def P(event , space):
    event_set = set(event)
    space_set = set(space)
    return Fraction(len(event_set & space_set), len(space))

S = [('Thanh', 'Nữ'), ('Hồng', 'Nữ'), ('Thương', 'Nữ'), 
    ('Đào', 'Nữ'), ('My', 'Nữ'), ('Yến', 'Nữ'), ('Hạnh', 'Nữ'),
    ('My', 'Nữ'), ('Vy', 'Nữ'), ('Tiên', 'Nữ'), ('Thanh', 
    'Nam'), ('Thanh', 'Nam'), ('Bình', 'Nam'), ('Nhật', 'Nam')
    , ('Hào', 'Nam'), ('Đạt', 'Nam'), ('Minh', 'Nam')]



A = [s for s  in S if 'Thanh' in s[0]]
B = [s for s  in S if 'Nữ' in s[1]]
A_B = [s for s in B if s[0]== 'Thanh']

P_A = P(A,S)
P_B = P(B,S)
P_A_B = P(A_B,S)

P_A_with_B = P_A_B/P_B
print(P_A_with_B)










