import math

def binomial_probability(n, k, p):
    binomial_coefficient = math.comb(n, k)
    probability = binomial_coefficient * (p**k) * ((1 - p)**(n - k))
    return probability

n = 5
k = 2
p = 0.1

probability = binomial_probability(n, k, p)

print(f"Xác suất có 2 máy hỏng trong 1 buổi làm việc là khoảng {probability:.3f}")
import matplotlib.pyplot as plt

n = 5
p = 0.1

x_values = list(range(n + 1))
y_values = [binomial_probability(n, k, p) for k in x_values]

plt.bar(x_values, y_values)
plt.xlabel('Số máy hỏng (X)')
plt.ylabel('Xác suất')
plt.title('Biểu đồ phân phối xác suất của số máy hỏng trong 1 buổi làm việc')
plt.show()
