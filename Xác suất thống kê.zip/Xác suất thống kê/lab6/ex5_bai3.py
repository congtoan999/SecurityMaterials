p = 0.4
k = 3

probability = (1 - p) ** (k - 1) * p

print(f"Xác suất trúng mục tiêu trong lần thử thứ ba là khoảng {probability:.3f}")
import matplotlib.pyplot as plt

p = 0.4

x_values = list(range(1, 11))  # X = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10}
y_values = [(1 - p) ** (k - 1) * p for k in x_values]

plt.bar(x_values, y_values)
plt.xlabel('Số lần thử (X)')
plt.ylabel('Xác suất')
plt.title('Biểu đồ phân phối xác suất trúng mục tiêu trong lần thử')
plt.show()
