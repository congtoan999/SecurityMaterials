import math
import matplotlib.pyplot as plt

def pmf_poisson(k, lam):
    return (math.exp(-lam) * lam**k) / math.factorial(k)

k = 10  
lam = 5  
xác_suất = pmf_poisson(k, lam)

print(f"Xác suất có {k} cuộc gọi đến trong 1 phút là khoảng {xác_suất:.4f}")

def plot_pmf_poisson(n,lam):
    K = list(range(0,n+1))
    P_poisson = [pmf_poisson(k,lam) for k in K]
    plt.plot(K,P_poisson,'-o')
    plt.title('PMF of Poisson(%i)' %lam)
    plt.xlabel('Number of Events')
    plt.ylabel('Probability of Number of Events')
    plt.show()
plot_pmf_poisson(25,5)