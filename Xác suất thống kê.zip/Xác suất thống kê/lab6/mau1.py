import matplotlib.pyplot as plt
import math

def pmf_bernoulli(p, x):
    if x == 1:
        return p
    elif x == 0:
        return 1 - p
    else:
        return 0

p = 0.5
x1 = 1
x0 = 0

pmf_x1 = pmf_bernoulli(p,x1)
pmf_x0 = pmf_bernoulli(p,x0)

print(f"P(X = 1) = {pmf_x1}")
print(f"P(X = 0) = {pmf_x0}")
def plot_pmf_bernoulli(p):
    X = [0,1]
    P_bernoulli = [pmf_bernoulli(p,x) for x in X]
    plt.plot(X, P_bernoulli, 'o')
    
    plt.title('PMF of Bernoulli(p=%.2f)' %(p))
    plt.xlabel('Value')
    plt.ylabel('Probability')
    plt.show()
plot_pmf_bernoulli(0.5)