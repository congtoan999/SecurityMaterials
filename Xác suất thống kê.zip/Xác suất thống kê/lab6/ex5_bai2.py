import math

def poisson_probability(k, lam):
    return (math.exp(-lam) * lam**k) / math.factorial(k)

lam = 3
k = 2

probability = poisson_probability(k, lam)

print(f"Xác suất trung tâm nhận được 2 cuộc gọi trong 1 phút là khoảng {probability:.3f}")
import matplotlib.pyplot as plt

lam = 3

x_values = list(range(1, 6))  # X = {1, 2, 3, 4, 5}
y_values = [poisson_probability(k, lam) for k in x_values]

plt.bar(x_values, y_values)
plt.xlabel('Số cuộc gọi (X)')
plt.ylabel('Xác suất')
plt.title('Biểu đồ phân phối xác suất của số cuộc gọi trong 1 phút')
plt.show()
